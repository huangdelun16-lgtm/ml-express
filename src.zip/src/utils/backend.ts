import { createClient } from '@supabase/supabase-js';

// 读取环境变量（在 Netlify 上配置）：
// SUPABASE_URL, SUPABASE_ANON_KEY
const supabaseUrl = process.env.REACT_APP_SUPABASE_URL || process.env.SUPABASE_URL || '';
const supabaseAnonKey = process.env.REACT_APP_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY || '';

export const supabase = supabaseUrl && supabaseAnonKey
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: { persistSession: false },
    })
  : null;

export function isBackendReady(): boolean {
  return !!supabase;
}

export async function fetchWithRetry(input: RequestInfo, init?: RequestInit, retries = 2, timeoutMs = 8000): Promise<Response> {
  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const resp = await fetch(input, { credentials: 'include', ...(init || {}), signal: controller.signal });
      clearTimeout(timer);
      if (resp.ok) return resp;
      if (attempt === retries) return resp;
    } catch (e) {
      clearTimeout(timer);
      if (attempt === retries) throw e;
      await new Promise(r => setTimeout(r, 500 * (attempt + 1)));
    }
  }
  throw new Error('fetchWithRetry unreachable');
}


