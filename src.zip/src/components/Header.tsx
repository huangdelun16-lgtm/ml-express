import React, { useState } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemText,
  useTheme,
  useMediaQuery,
  Container,
  Select,
  MenuItem,
} from '@mui/material';
import {
  Menu as MenuIcon,
} from '@mui/icons-material';
import { useNavigate, useLocation } from 'react-router-dom';
import { useI18n } from '../i18n';

const Header: React.FC = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  // Logo 加载顺序：/logo.png -> /ML LOGO.png -> /ml-logo.png
  const logoCandidates = ['/logo.png', '/ML LOGO.png', '/ml-logo.png'];
  const [logoIdx, setLogoIdx] = useState(0);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const navigate = useNavigate();
  const location = useLocation();
  const { lang, setLang, t } = useI18n();

  const navItems = [
    { name: t('nav.home'), path: '/' },
    { name: t('nav.services'), path: '/services' },
    { name: t('nav.pricing'), path: '/pricing' },
    { name: t('nav.tracking'), path: '/tracking' },
    { name: t('nav.contact'), path: '/contact' },
  ];

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleNavClick = (path: string) => {
    navigate(path);
    if (isMobile) {
      setMobileOpen(false);
    }
  };

  const prefetchRoute = (path: string) => {
    // 轻量预取：触发动态 import
    switch (path) {
      case '/services': import('../pages/ServicesPage'); break;
      case '/pricing': import('../pages/PricingPage'); break;
      case '/tracking': import('../pages/TrackingPage'); break;
      case '/contact': import('../pages/ContactPage'); break;
      case '/admin/login': import('../pages/AdminLogin'); break;
      default: break;
    }
  };

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const drawer = (
    <Box onClick={handleDrawerToggle} sx={{ textAlign: 'center' }}>
      <Typography variant="h6" sx={{ my: 2 }}>
        MARKETLINK EXPRESS
      </Typography>
      <List>
        {navItems.map((item) => (
          <ListItem key={item.name} onClick={() => handleNavClick(item.path)}>
            <ListItemText 
              primary={item.name} 
              sx={{ 
                textAlign: 'center',
                color: isActive(item.path) ? 'primary.main' : 'text.primary',
                fontWeight: isActive(item.path) ? 600 : 400,
              }}
            />
          </ListItem>
        ))}
        <ListItem onClick={() => handleNavClick('/admin/mobile')}>
          <ListItemText primary="移动后台" sx={{ textAlign: 'center' }} />
        </ListItem>
        <ListItem onClick={() => handleNavClick('/admin/login')}>
          <ListItemText 
            primary={t('nav.admin')} 
            sx={{ 
              textAlign: 'center',
              color: isActive('/admin/login') ? 'primary.main' : 'text.primary',
              fontWeight: isActive('/admin/login') ? 600 : 400,
            }}
          />
        </ListItem>
      </List>
    </Box>
  );

  return (
    <>
      <AppBar 
        position="static" 
        sx={{ 
          backgroundColor: 'white', 
          color: 'text.primary',
          boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
        }}
      >
        <Container maxWidth="lg">
          <Toolbar sx={{ px: { xs: 0 } }}>
            {/* Logo */}
            <Box 
              sx={{ 
                display: 'flex', 
                alignItems: 'center', 
                cursor: 'pointer',
                mr: 4,
              }}
              onClick={() => handleNavClick('/')}
            >
              {logoIdx < logoCandidates.length ? (
                <Box
                  component="img"
                  src={encodeURI(logoCandidates[logoIdx])}
                  alt="MARKET LINK"
                  onError={() => setLogoIdx((i) => i + 1)}
                  sx={{ height: 36, width: 'auto', mr: 2, display: 'block' }}
                />
              ) : (
                <Box
                  sx={{
                    position: 'relative',
                    width: 40,
                    height: 40,
                    borderRadius: '50%',
                    background: 'linear-gradient(135deg, #1976d2 0%, #42a5f5 100%)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    mr: 2,
                    boxShadow: '0 4px 20px rgba(25, 118, 210, 0.3)'
                  }}
                >
                  <svg width="26" height="26" viewBox="0 0 26 26" xmlns="http://www.w3.org/2000/svg" aria-label="MARKETLINK EXPRESS">
                    <defs>
                      <linearGradient id="mlg" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#fff" stopOpacity="0.95" />
                        <stop offset="100%" stopColor="#e3f2ff" stopOpacity="0.95" />
                      </linearGradient>
                    </defs>
                    <g fill="url(#mlg)">
                      <path d="M3 20 L3 6 L5.8 6 L10.2 14 L14.6 6 L17.4 6 L17.4 20 L14.9 20 L14.9 11.4 L10.9 18.6 L9.5 18.6 L5.5 11.4 L5.5 20 Z"/>
                      <rect x="18.6" y="6" width="2.8" height="14" rx="1.2" />
                    </g>
                  </svg>
                </Box>
              )}
              <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                <Typography 
                  variant="h6" 
                  component="div" 
                  sx={{ 
                    fontWeight: 800, 
                    color: 'primary.main',
                    display: { xs: 'none', sm: 'block' },
                    lineHeight: 1,
                    mb: 0.5,
                  }}
                >
                  MARKET-LINK EXPRESS
                </Typography>
                <Typography 
                  variant="caption" 
                  sx={{ 
                    color: 'text.secondary',
                    display: { xs: 'none', sm: 'block' },
                    fontWeight: 500,
                    letterSpacing: 1,
                  }}
                >
                  专业快递服务
                </Typography>
              </Box>
            </Box>

            {/* Desktop Navigation */}
            {!isMobile && (
              <Box sx={{ display: 'flex', gap: 2, flexGrow: 1 }}>
                {navItems.map((item) => (
                  <Button
                    key={item.name}
                    onClick={() => handleNavClick(item.path)}
                    onMouseEnter={() => prefetchRoute(item.path)}
                    sx={{
                      color: isActive(item.path) ? 'primary.main' : 'text.primary',
                      fontWeight: isActive(item.path) ? 600 : 400,
                      '&:hover': {
                        backgroundColor: 'rgba(25, 118, 210, 0.08)',
                      },
                    }}
                  >
                    {item.name}
                  </Button>
                ))}
              </Box>
            )}

            {/* Right Actions: Language + Admin */}
            {!isMobile && (
              <Box sx={{ display: 'flex', gap: 1 }}>
                <Box>
                  <Select size="small" value={lang} onChange={(e)=>setLang(e.target.value as any)} sx={{ mr: 1 }}>
                    <MenuItem value="zh">ZH</MenuItem>
                    <MenuItem value="en">EN</MenuItem>
                    <MenuItem value="my">MY</MenuItem>
                  </Select>
                </Box>
                <Button
                  variant="outlined"
                  onClick={() => handleNavClick('/admin/login')}
                  sx={{
                    borderColor: 'primary.main',
                    color: 'primary.main',
                    '&:hover': {
                      borderColor: 'primary.dark',
                      backgroundColor: 'rgba(25, 118, 210, 0.08)',
                    },
                  }}
                >
                  {t('nav.admin')}
                </Button>
              </Box>
            )}

            {/* Mobile Menu Button */}
            {isMobile && (
              <IconButton
                color="inherit"
                aria-label="open drawer"
                edge="start"
                onClick={handleDrawerToggle}
                sx={{ ml: 'auto' }}
              >
                <MenuIcon />
              </IconButton>
            )}
          </Toolbar>
        </Container>
      </AppBar>

      {/* Mobile Drawer */}
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={handleDrawerToggle}
        ModalProps={{
          keepMounted: true,
        }}
        sx={{
          display: { xs: 'block', md: 'none' },
          '& .MuiDrawer-paper': { 
            boxSizing: 'border-box', 
            width: 240,
          },
        }}
      >
        {drawer}
      </Drawer>
    </>
  );
};

export default Header;
