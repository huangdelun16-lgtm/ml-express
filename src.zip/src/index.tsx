import React, { useEffect, useState } from 'react';
import '@fontsource/noto-sans-sc/300.css';
import '@fontsource/noto-sans-sc/400.css';
import '@fontsource/noto-sans-sc/500.css';
import '@fontsource/noto-sans-sc/600.css';
import '@fontsource/noto-sans-sc/700.css';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { Box, Button } from '@mui/material';
import App from './App';
import CookieBanner from './components/CookieBanner';
import { sendTelemetry, installGlobalErrorHandlers } from './utils/telemetry';
import { I18nProvider } from './i18n';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
      light: '#42a5f5',
      dark: '#1565c0',
    },
    secondary: {
      main: '#dc004e',
      light: '#ff5983',
      dark: '#9a0036',
    },
    background: {
      default: '#f5f5f5',
    },
  },
  typography: {
    fontFamily: '"Noto Sans SC", "Roboto", "Helvetica", "Arial", sans-serif',
    h1: {
      fontWeight: 700,
    },
    h2: {
      fontWeight: 600,
    },
    h3: {
      fontWeight: 600,
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          textTransform: 'none',
          fontWeight: 500,
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
        },
      },
    },
  },
});

const VersionWatcher: React.FC = () => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    let timer: any;
    const check = async () => {
      try {
        const res = await fetch('/asset-manifest.json', { cache: 'no-store' });
        if (!res.ok) return;
        const json = await res.json();
        const main = (json.files && (json.files['main.js'] || json.files['main'])) || json['main.js'] || '';
        const css = (json.files && (json.files['main.css'] || json.files['main'])) || json['main.css'] || '';
        const fingerprint = `${main}|${css}`;
        const prev = localStorage.getItem('__ML_ASSET_MAIN__');
        if (prev && prev !== fingerprint) setShow(true);
        localStorage.setItem('__ML_ASSET_MAIN__', fingerprint);
      } catch {}
    };
    check();
    timer = setInterval(check, 60000);
    return () => clearInterval(timer);
  }, []);

  const hardReload = async () => {
    try {
      if ('caches' in window) {
        const keys = await (window as any).caches.keys();
        await Promise.all(keys.map((k: string) => (window as any).caches.delete(k)));
      }
    } catch {}
    const url = window.location.pathname + '?v=' + Date.now();
    window.location.replace(url);
  };

  if (!show) return null;
  return (
    <Box sx={{ position: 'fixed', top: 0, left: 0, right: 0, zIndex: 1500, bgcolor: 'primary.main', color: 'primary.contrastText', display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1 }}>
      <Box sx={{ fontSize: 14 }}>检测到新版本，点击更新以获取最新功能与修复。</Box>
      <Box>
        <Button variant="contained" size="small" color="inherit" onClick={hardReload} sx={{ color: 'primary.main' }}>立即更新</Button>
      </Box>
    </Box>
  );
};

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

// 监控：安装全局错误处理 & 首次访问事件
installGlobalErrorHandlers();
try { sendTelemetry('event', { type: 'app_start' }); } catch {}

root.render(
  <React.StrictMode>
    <BrowserRouter>
      <ThemeProvider theme={theme}>
        <I18nProvider>
          <CssBaseline />
          <VersionWatcher />
          <CookieBanner />
          <App />
        </I18nProvider>
      </ThemeProvider>
    </BrowserRouter>
  </React.StrictMode>
);
