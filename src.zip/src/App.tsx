import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Box } from '@mui/material';
import Header from './components/Header';
import Footer from './components/Footer';
import './App.css';
const HomePage = React.lazy(() => import('./pages/HomePage'));
const TrackingPage = React.lazy(() => import('./pages/TrackingPage'));
const ServicesPage = React.lazy(() => import('./pages/ServicesPage'));
const PricingPage = React.lazy(() => import('./pages/PricingPage'));
const ContactPage = React.lazy(() => import('./pages/ContactPage'));
const AdminLogin = React.lazy(() => import('./pages/AdminLogin'));
const AdminDashboard = React.lazy(() => import('./pages/AdminDashboard'));
const AdminFinance = React.lazy(() => import('./pages/AdminFinance'));
const AdminInventory = React.lazy(() => import('./pages/AdminInventory'));
const AdminTransport = React.lazy(() => import('./pages/AdminTransport'));
const AdminScan = React.lazy(() => import('./pages/AdminScan'));
const AdminMobile = React.lazy(() => import('./pages/AdminMobile'));
const SuccessPage = React.lazy(() => import('./pages/SuccessPage'));
const PrivacyPolicy = React.lazy(() => import('./pages/PrivacyPolicy'));
const TermsOfService = React.lazy(() => import('./pages/TermsOfService'));
// lazy imports defined after static imports to satisfy lint rules

function App() {
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <Header />
      <Box component="main" sx={{ flexGrow: 1 }}>
        <React.Suspense fallback={<Box sx={{ p: 3 }}>加载中…</Box>}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/tracking" element={<TrackingPage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/pricing" element={<PricingPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/finance" element={<AdminFinance />} />
          <Route path="/admin/inventory" element={<AdminInventory />} />
          <Route path="/admin/transport" element={<AdminTransport />} />
          <Route path="/admin/scan" element={<AdminScan />} />
          <Route path="/admin/mobile" element={<AdminMobile />} />
          <Route path="/success" element={<SuccessPage />} />
          <Route path="/privacy" element={<PrivacyPolicy />} />
          <Route path="/terms" element={<TermsOfService />} />
        </Routes>
        </React.Suspense>
      </Box>
      <Footer />
    </Box>
  );
}

export default App;
