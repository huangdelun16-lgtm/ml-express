import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Box,
  Container,
  Typography,
  Grid,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  Alert,
  Snackbar,
  AppBar,
  Toolbar,
  Avatar,
  Menu,
  MenuItem,
  Divider,
} from '@mui/material';
import {
  LocalShipping,
  Logout,
  Person,
  Settings,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { getAdminSession, clearAdminSession, hashPassword, isStrongPassword } from '../utils/auth';
import { fetchWithRetry } from '../utils/backend';

interface User {
  username: string;
  role: string;
  loginTime: string;
}

interface FinanceTxn {
  id: string;
  type: '收入' | '支出';
  amount: number;
  note: string;
  date: string;
  category?: string;
}

const AdminDashboard: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [allUsers, setAllUsers] = useState<Array<{ username: string; role: string; password?: string; passwordHash?: string }>>([]);
  const [openUserDialog, setOpenUserDialog] = useState(false);
  const [newUser, setNewUser] = useState<{ username: string; password: string; role: string }>({ username: '', password: '', role: 'staff' });
  const [editUser, setEditUser] = useState<{ username: string; role: string } | null>(null);
  const [resetUser, setResetUser] = useState<{ username: string; newPassword: string } | null>(null);
  const [deleteUser, setDeleteUser] = useState<{ username: string } | null>(null);
  const [finance, setFinance] = useState<FinanceTxn[]>([]);
  const [openFinanceDialog, setOpenFinanceDialog] = useState(false);
  const [newTxn, setNewTxn] = useState<FinanceTxn>({ id: '', type: '收入', amount: 0, note: '', date: new Date().toISOString().slice(0,10) });
  const [newAmountInput, setNewAmountInput] = useState<string>('');
  const [toast, setToast] = useState<{ open: boolean; text: string; severity: 'success' | 'error' | 'info' | 'warning' }>({ open: false, text: '', severity: 'success' });
  const [capsOn, setCapsOn] = useState(false);
  const usersLoadedRef = useRef(false);
  const [audit, setAudit] = useState<Array<{ id: string; actor: string; action: string; ts: string; detail?: any }>>([]);
  const [auditLoading, setAuditLoading] = useState(false);
  const [auditFilters, setAuditFilters] = useState<{ start: string; end: string; actor: string; action: string; search: string }>({
    start: '',
    end: '',
    actor: '',
    action: '',
    search: '',
  });
  
  // 指标卡片已移除，无需 metrics 状态

  const navigate = useNavigate();

  const api = useMemo(() => ({
    async list() {
      const r = await fetchWithRetry('/.netlify/functions/users-manage', undefined, 0);
      const j = await r.json();
      return j.users || [];
    },
    async loadAudit(params: { start?: string; end?: string; actor?: string; action?: string; search?: string; page?: number; pageSize?: number }) {
      const usp = new URLSearchParams();
      if (params.start) usp.set('start', params.start);
      if (params.end) usp.set('end', params.end);
      if (params.actor) usp.set('actor', params.actor);
      if (params.action) usp.set('action', params.action);
      if (params.search) usp.set('search', params.search);
      if (params.page) usp.set('page', String(params.page));
      if (params.pageSize) usp.set('pageSize', String(params.pageSize));
      const r = await fetchWithRetry('/.netlify/functions/audit-logs?' + usp.toString(), { headers: { 'x-ml-actor': user?.username || '' } }, 0);
      const j = await r.json();
      return j.items || [];
    },
    async create(username: string, passwordHash: string, role: string) {
      await fetchWithRetry('/.netlify/functions/users-manage', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user?.username || '' }, body: JSON.stringify({ username, passwordHash, role }) }, 0);
    },
    async update(username: string, role?: string, passwordHash?: string) {
      await fetchWithRetry('/.netlify/functions/users-manage', { method: 'PATCH', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user?.username || '' }, body: JSON.stringify({ username, role, passwordHash }) }, 0);
    },
    async remove(username: string) {
      await fetchWithRetry('/.netlify/functions/users-manage', { method: 'DELETE', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user?.username || '' }, body: JSON.stringify({ username }) }, 0);
    }
  // 依赖 user，仅当登录用户变化时重建
  }), [user]);

  useEffect(() => {
    const sess = getAdminSession();
    if (!sess) { navigate('/admin/login'); return; }
    setUser({ username: sess.username, role: sess.role, loginTime: sess.loginTime });
    (async () => {
      // 初始化只读本地财务缓存，不自动请求用户列表（手动按钮加载）
      const role = (sess.role || '').trim().toLowerCase();
      if (!['manager','master'].includes(role)) setAllUsers([]);
      try {
        const rawFinance = localStorage.getItem('finance');
        setFinance(rawFinance ? JSON.parse(rawFinance) : []);
      } catch {
        setFinance([]);
      }
    })();
  }, [navigate, api]);

  const handleLoadUsers = async () => {
    if (usersLoadedRef.current) return;
    usersLoadedRef.current = true;
    try {
      setAllUsers(await api.list());
    } catch {
      setToast({ open: true, text: '用户列表加载失败', severity: 'warning' });
    }
  };

  const handleLogout = () => {
    clearAdminSession();
    navigate('/admin/login');
  };

  const canManageUsers = user && ['manager', 'master'].includes(user.role);

  const handleCreateUser = async () => {
    if (!newUser.username.trim() || !newUser.password.trim()) return;
    if (!isStrongPassword(newUser.password)) { alert('密码需至少8位，且包含大小写字母、数字和符号'); return; }
    const exists = allUsers.some(u => u.username === newUser.username);
    if (exists) { alert('用户名已存在'); return; }
    const passwordHash = await hashPassword(newUser.password);
    await api.create(newUser.username, passwordHash, newUser.role);
    setAllUsers(await api.list());
    setOpenUserDialog(false);
    setNewUser({ username: '', password: '', role: 'staff' });
  };

  const handleOpenEditUser = (u: { username: string; role: string }) => {
    setEditUser({ username: u.username, role: u.role });
  };

  const handleSaveEditUser = async () => {
    if (!editUser) return;
    await api.update(editUser.username, editUser.role);
    setAllUsers(await api.list());
    setEditUser(null);
  };

  const handleOpenResetPwd = (u: { username: string }) => {
    setResetUser({ username: u.username, newPassword: '' });
  };

  const handleSaveResetPwd = async () => {
    if (!resetUser) return;
    if (!isStrongPassword(resetUser.newPassword)) { alert('新密码需至少8位，且包含大小写字母、数字和符号'); return; }
    const passwordHash = await hashPassword(resetUser.newPassword);
    await api.update(resetUser.username, undefined, passwordHash);
    setAllUsers(await api.list());
    setResetUser(null);
  };

  const handleOpenDeleteUser = (u: { username: string }) => {
    setDeleteUser({ username: u.username });
  };

  const handleConfirmDeleteUser = async () => {
    if (!deleteUser) return;
    if (deleteUser.username === 'master') { alert('禁止删除 master 账户'); setDeleteUser(null); return; }
    if (user && deleteUser.username === user.username) { alert('不能删除当前登录账户'); setDeleteUser(null); return; }
    await api.remove(deleteUser.username);
    setAllUsers(await api.list());
    setDeleteUser(null);
  };

  const handleAddTxn = () => {
    const amountNum = Number(newAmountInput);
    if (!newAmountInput || Number.isNaN(amountNum) || amountNum <= 0) return;
    const entry = { ...newTxn, id: Date.now().toString(), amount: amountNum };
    const updated = [entry, ...finance];
    setFinance(updated);
    localStorage.setItem('finance', JSON.stringify(updated));
    setOpenFinanceDialog(false);
    setNewTxn({ id: '', type: '收入', amount: 0, note: '', date: new Date().toISOString().slice(0,10) });
    setNewAmountInput('');
  };

  // 已移除操作记录模块，不再请求审计日志

  if (!user) return null;
  const role = (user.role || '').trim().toLowerCase();

  return (
    <Box sx={{ minHeight: '100vh', backgroundColor: 'grey.50' }}>
      <AppBar position="static" sx={{ backgroundColor: 'white', color: 'text.primary' }}>
        <Toolbar>
          <Box sx={{ flexGrow: 1 }} />
          <Box sx={{ display: 'flex', gap: 1, mr: 2 }}>
            <Button size="small" onClick={() => navigate('/admin/inventory')}>包裹管理</Button>
            <Button size="small" onClick={() => navigate('/admin/transport')}>运输系统</Button>
            {['accountant','manager','master'].includes(role) && <Button size="small" onClick={() => navigate('/admin/finance')}>财务系统</Button>}
            <Button size="small" variant="contained" onClick={() => navigate('/admin/dashboard')}>控制台</Button>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Typography variant="body2" color="text.secondary">欢迎，{user.username} ({user.role})</Typography>
            <IconButton onClick={(e) => setAnchorEl(e.currentTarget)}>
              <Avatar sx={{ width: 32, height: 32, bgcolor: 'primary.main' }}><Person /></Avatar>
            </IconButton>
          </Box>
        </Toolbar>
      </AppBar>

      <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={() => setAnchorEl(null)}>
        <MenuItem><Person sx={{ mr: 1 }} />个人信息</MenuItem>
        <MenuItem><Settings sx={{ mr: 1 }} />设置</MenuItem>
        <Divider />
        <MenuItem onClick={handleLogout}><Logout sx={{ mr: 1 }} />退出登录</MenuItem>
      </Menu>

      <Container maxWidth="lg" sx={{ py: 4 }}>
        {/* 应用户要求：移除控制台卡片，仅保留用户管理与监督日志等模块入口（如有） */}
        {canManageUsers && (
          <Box sx={{ mb: 4 }}>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>用户管理</Typography>
            <Paper sx={{ p: 2, mb: 2, display: 'flex', gap: 1 }}>
              <Button variant="outlined" onClick={handleLoadUsers}>加载用户列表</Button>
              <Button variant="contained" onClick={() => setOpenUserDialog(true)}>新增用户</Button>
            </Paper>
            <Paper>
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow sx={{ backgroundColor: 'grey.50' }}>
                      <TableCell>用户名</TableCell>
                      <TableCell>角色</TableCell>
                      <TableCell align="right">操作</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {allUsers.map((u, i) => (
                      <TableRow key={i}>
                        <TableCell>{u.username}</TableCell>
                        <TableCell>{u.role}</TableCell>
                        <TableCell align="right">
                          <Button size="small" onClick={() => handleOpenEditUser(u)}>修改角色</Button>
                          <Button size="small" onClick={() => handleOpenResetPwd(u)}>重置密码</Button>
                          <Button size="small" color="error" onClick={() => handleOpenDeleteUser(u)}>删除</Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Paper>
          </Box>
        )}

        {canManageUsers && (
          <Box sx={{ mb: 4 }}>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>监督员工工作日志</Typography>
            <Paper sx={{ p: 2, mb: 2, display: 'flex', gap: 1, flexWrap: 'wrap' }}>
              <TextField size="small" type="date" label="开始日期" InputLabelProps={{ shrink: true }} value={auditFilters.start} onChange={(e) => setAuditFilters(prev => ({ ...prev, start: e.target.value }))} />
              <TextField size="small" type="date" label="结束日期" InputLabelProps={{ shrink: true }} value={auditFilters.end} onChange={(e) => setAuditFilters(prev => ({ ...prev, end: e.target.value }))} />
              <TextField size="small" label="员工账号" value={auditFilters.actor} onChange={(e) => setAuditFilters(prev => ({ ...prev, actor: e.target.value }))} />
              <TextField size="small" label="动作(如 packages.update / finances.update)" value={auditFilters.action} onChange={(e) => setAuditFilters(prev => ({ ...prev, action: e.target.value }))} sx={{ minWidth: 320 }} />
              <TextField size="small" label="搜索(单号/备注)" value={auditFilters.search} onChange={(e) => setAuditFilters(prev => ({ ...prev, search: e.target.value }))} />
              <Button variant="outlined" disabled={auditLoading} onClick={async () => {
                setAuditLoading(true);
                try {
                  const items = await api.loadAudit({ ...auditFilters, page: 1, pageSize: 50 });
                  // 过滤掉 login 与 event 行
                  setAudit((items as any[]).filter((x: any) => x && x.action !== 'login' && x.action !== 'event'));
                } catch {
                  setToast({ open: true, text: '日志加载失败', severity: 'warning' });
                } finally {
                  setAuditLoading(false);
                }
              }}>加载日志</Button>
            </Paper>
            <Paper>
              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow sx={{ backgroundColor: 'grey.50' }}>
                      <TableCell>时间</TableCell>
                      <TableCell>账号</TableCell>
                      <TableCell>动作</TableCell>
                      <TableCell>单号</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {audit.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={4} align="center" sx={{ color: 'text.secondary' }}>暂无日志</TableCell>
                      </TableRow>
                    )}
                    {audit.map((r) => {
                      let trackingStr = '';
                      try {
                        const d: any = r.detail || {};
                        const cand = d.tracking_no || d.trackingNumber || d.trackingNo || d.tracking;
                        if (cand) {
                          trackingStr = String(cand);
                        } else if (Array.isArray(d.trackingNumbers) && d.trackingNumbers.length) {
                          trackingStr = d.trackingNumbers.join(',');
                        } else if (Array.isArray(d.tracking_nos) && d.tracking_nos.length) {
                          trackingStr = d.tracking_nos.join(',');
                        } else if (Array.isArray(d.packages) && d.packages.length) {
                          trackingStr = d.packages.map((x: any) => (x?.tracking_no || x?.trackingNumber || x)).join(',');
                        } else if (typeof d.note === 'string') {
                          const m = d.note.match(/单号[:：]?\s*([^\s，,]+)/);
                          if (m) trackingStr = m[1];
                        }
                      } catch {}
                      return (
                        <TableRow key={r.id}>
                          <TableCell>{new Date(r.ts).toLocaleString()}</TableCell>
                          <TableCell>{r.actor}</TableCell>
                          <TableCell>{r.action}</TableCell>
                          <TableCell>{trackingStr}</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            </Paper>
          </Box>
        )}

        <Dialog open={openUserDialog} onClose={() => setOpenUserDialog(false)} maxWidth="sm" fullWidth>
          <DialogTitle>新增用户</DialogTitle>
          <DialogContent>
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12}>
                <TextField fullWidth label="用户名" value={newUser.username} onChange={(e) => setNewUser({ ...newUser, username: e.target.value })} />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="密码"
                  type="password"
                  value={newUser.password}
                  onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                  onKeyUp={(e:any) => { try { setCapsOn(Boolean(e.getModifierState && e.getModifierState('CapsLock'))); } catch {} }}
                  helperText={capsOn ? '注意：键盘 Caps Lock（大写锁定）已开启' : ' '}
                  FormHelperTextProps={{ sx: { color: capsOn ? 'warning.main' : 'text.disabled', m: 0 } }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField select fullWidth label="角色" value={newUser.role} onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}>
                  <MenuItem value="staff">员工</MenuItem>
                  <MenuItem value="accountant">会计</MenuItem>
                  <MenuItem value="manager">经理</MenuItem>
                </TextField>
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenUserDialog(false)}>取消</Button>
            <Button variant="contained" onClick={handleCreateUser}>创建</Button>
          </DialogActions>
        </Dialog>

        {/* 按要求移除了操作记录区块 */}

        {/* 编辑角色 */}
        <Dialog open={Boolean(editUser)} onClose={() => setEditUser(null)} maxWidth="xs" fullWidth>
          <DialogTitle>修改角色</DialogTitle>
          <DialogContent>
            <TextField select fullWidth label="角色" value={editUser?.role || 'staff'} onChange={(e) => setEditUser(prev => prev ? ({ ...prev, role: e.target.value }) : prev)} sx={{ mt: 2 }}>
              <MenuItem value="staff">员工</MenuItem>
              <MenuItem value="accountant">会计</MenuItem>
              <MenuItem value="manager">经理</MenuItem>
              <MenuItem value="master">master</MenuItem>
            </TextField>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setEditUser(null)}>取消</Button>
            <Button variant="contained" onClick={handleSaveEditUser}>保存</Button>
          </DialogActions>
        </Dialog>

        {/* 重置密码 */}
        <Dialog open={Boolean(resetUser)} onClose={() => setResetUser(null)} maxWidth="xs" fullWidth>
          <DialogTitle>重置密码 - {resetUser?.username}</DialogTitle>
          <DialogContent>
            <Alert severity="info" sx={{ mb: 2 }}>密码需至少8位，且包含大小写字母、数字和符号。</Alert>
            <TextField
              fullWidth
              label="新密码"
              type="password"
              value={resetUser?.newPassword || ''}
              onChange={(e) => setResetUser(prev => prev ? ({ ...prev, newPassword: e.target.value }) : prev)}
              onKeyUp={(e:any) => { try { setCapsOn(Boolean(e.getModifierState && e.getModifierState('CapsLock'))); } catch {} }}
              helperText={capsOn ? '注意：键盘 Caps Lock（大写锁定）已开启' : ' '}
              FormHelperTextProps={{ sx: { color: capsOn ? 'warning.main' : 'text.disabled', m: 0 } }}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setResetUser(null)}>取消</Button>
            <Button variant="contained" onClick={handleSaveResetPwd}>保存</Button>
          </DialogActions>
        </Dialog>

        {/* 删除确认 */}
        <Dialog open={Boolean(deleteUser)} onClose={() => setDeleteUser(null)} maxWidth="xs" fullWidth>
          <DialogTitle>确认删除</DialogTitle>
          <DialogContent>
            <Alert severity="warning">确定要删除用户“{deleteUser?.username}”吗？此操作不可撤销。</Alert>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setDeleteUser(null)}>取消</Button>
            <Button color="error" variant="contained" onClick={handleConfirmDeleteUser}>删除</Button>
          </DialogActions>
        </Dialog>

        <Dialog open={openFinanceDialog} onClose={() => setOpenFinanceDialog(false)} maxWidth="sm" fullWidth>
          <DialogTitle>新增财务记录</DialogTitle>
          <DialogContent>
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12} sm={6}>
                <TextField select fullWidth label="类型" value={newTxn.type} onChange={(e) => setNewTxn({ ...newTxn, type: e.target.value as any })}>
                  <MenuItem value="收入">收入</MenuItem>
                  <MenuItem value="支出">支出</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField fullWidth label="金额" type="number" placeholder="0" value={newAmountInput} onChange={(e) => setNewAmountInput(e.target.value)} />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField fullWidth label="日期" type="date" value={newTxn.date} onChange={(e) => setNewTxn({ ...newTxn, date: e.target.value })} InputLabelProps={{ shrink: true }} />
              </Grid>
              <Grid item xs={12}>
                <TextField fullWidth label="备注" value={newTxn.note} onChange={(e) => setNewTxn({ ...newTxn, note: e.target.value })} />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenFinanceDialog(false)}>取消</Button>
            <Button variant="contained" onClick={handleAddTxn}>保存</Button>
          </DialogActions>
        </Dialog>
      </Container>

      <Snackbar open={toast.open} autoHideDuration={2500} onClose={() => setToast(prev => ({ ...prev, open: false }))} anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}>
        <Alert onClose={() => setToast(prev => ({ ...prev, open: false }))} severity={toast.severity} sx={{ width: '100%' }}>
          {toast.text}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default AdminDashboard;
