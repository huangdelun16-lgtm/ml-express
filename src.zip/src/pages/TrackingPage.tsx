import React, { useMemo, useState } from 'react';
import {
  Box,
  Container,
  Typography,
  TextField,
  Button,
  Paper,
  Grid,
  Stepper,
  Step,
  StepLabel,
  StepContent,
  Card,
  CardContent,
  Chip,
  Alert,
  useTheme,
  useMediaQuery,
} from '@mui/material';
import {
  Search,
  LocalShipping,
  CheckCircle,
  Schedule,
  LocationOn,
  AccessTime,
} from '@mui/icons-material';
import { useSearchParams } from 'react-router-dom';
import { fetchWithRetry } from '../utils/backend';
import { useI18n } from '../i18n';

interface TrackingInfo {
  trackingNumber: string;
  status: string;
  sender: string;
  receiver: string;
  packageType: string;
  weight: string;
  createdAt: string;
  estimatedDelivery: string;
  steps: TrackingStep[];
}

interface TrackingStep {
  status: string;
  description: string;
  location: string;
  timestamp: string;
  completed: boolean;
}

const TrackingPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const [trackingNumber, setTrackingNumber] = useState(searchParams.get('number') || '');
  const [trackingResult, setTrackingResult] = useState<TrackingInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const { t } = useI18n();

  // 模拟快递数据（保留示例）
  const mockTrackingData: { [key: string]: TrackingInfo } = {
    'ML123456789': {
      trackingNumber: 'ML123456789',
      status: '运输中',
      sender: '张三 - 仰光市',
      receiver: '李四 - 曼德勒市',
      packageType: '文件包裹',
      weight: '0.5kg',
      createdAt: '2024-01-14',
      estimatedDelivery: '2024-01-15',
      steps: [
        {
          status: '已下单',
          description: '包裹已成功下单',
          location: '仰光市',
          timestamp: '2024-01-14 09:00',
          completed: true,
        },
        {
          status: '已揽收',
          description: '快递员已上门揽收包裹',
          location: '仰光市',
          timestamp: '2024-01-14 14:30',
          completed: true,
        },
        {
          status: '运输中',
          description: '包裹正在运输途中',
          location: '曼德勒市',
          timestamp: '2024-01-15 08:00',
          completed: false,
        },
        {
          status: '派送中',
          description: '快递员正在派送包裹',
          location: '曼德勒市',
          timestamp: '',
          completed: false,
        },
        {
          status: '已签收',
          description: '包裹已成功签收',
          location: '曼德勒市',
          timestamp: '',
          completed: false,
        },
      ],
    },
    'ML987654321': {
      trackingNumber: 'ML987654321',
      status: '已签收',
      sender: '王五 - 仰光市',
      receiver: '赵六 - 内比都市',
      packageType: '电子产品',
      weight: '2.0kg',
      createdAt: '2024-01-12',
      estimatedDelivery: '2024-01-14',
      steps: [
        {
          status: '已下单',
          description: '包裹已成功下单',
          location: '仰光市',
          timestamp: '2024-01-12 10:00',
          completed: true,
        },
        {
          status: '已揽收',
          description: '快递员已上门揽收包裹',
          location: '仰光市',
          timestamp: '2024-01-12 15:00',
          completed: true,
        },
        {
          status: '运输中',
          description: '包裹正在运输途中',
          location: '内比都市',
          timestamp: '2024-01-13 09:00',
          completed: true,
        },
        {
          status: '派送中',
          description: '快递员正在派送包裹',
          location: '内比都市',
          timestamp: '2024-01-14 10:00',
          completed: true,
        },
        {
          status: '已签收',
          description: '包裹已成功签收',
          location: '内比都市',
          timestamp: '2024-01-14 14:30',
          completed: true,
        },
      ],
    },
  };

  // 将本地后台保存的包裹数据映射为查询可用的数据结构
  const localPackages: TrackingInfo[] = useMemo(() => {
    try {
      const raw = localStorage.getItem('packages');
      const list: any[] = raw ? JSON.parse(raw) : [];
      return (list || []).map((p) => ({
        trackingNumber: p.trackingNumber,
        status: p.status || '已下单',
        sender: p.sender,
        receiver: p.receiver,
        packageType: p.packageType || '—',
        weight: (p.weightKg ? `${p.weightKg}kg` : (p.weight || '—')),
        createdAt: p.createdAt,
        estimatedDelivery: p.estimatedDelivery || '—',
        steps: [
          { status: '已下单', description: '包裹已创建', location: p.origin || '—', timestamp: `${p.createdAt} 09:00`, completed: true },
          { status: '已入库', description: '包裹已入库', location: p.origin || '—', timestamp: '', completed: p.status==='已入库' || p.status==='运输中' || p.status==='已签收' },
          { status: '运输中', description: '干线运输', location: p.destination || '—', timestamp: '', completed: p.status==='运输中' || p.status==='已签收' },
          { status: '已签收', description: '收件人已签收', location: p.destination || '—', timestamp: '', completed: p.status==='已签收' },
        ],
      }));
    } catch {
      return [];
    }
  }, []);

  const localIndex: Record<string, TrackingInfo> = useMemo(() => {
    const map: Record<string, TrackingInfo> = {};
    localPackages.forEach((t) => { if (t.trackingNumber) map[t.trackingNumber] = t; });
    return map;
  }, [localPackages]);

  const handleSearch = async () => {
    if (!trackingNumber.trim()) {
      setError(t('tracking.inputError') || '请输入快递单号');
      return;
    }

    setLoading(true);
    setError('');
    setTrackingResult(null);

    try {
      // 方案B：优先请求后端按单号精确查询
      const qs = new URLSearchParams({ page: '1', pageSize: '1', search: trackingNumber });
      const resp = await fetchWithRetry('/.netlify/functions/packages-manage?' + qs.toString());
      let json: any = {};
      try { json = await resp.json(); } catch { json = {}; }
      const hit = (json.items || []).find((p: any) => String(p.trackingNumber || p.tracking_no || p.tracking) === trackingNumber);
      if (hit) {
        const mapped: TrackingInfo = {
          trackingNumber: hit.trackingNumber || hit.tracking_no || trackingNumber,
          status: hit.status || '已下单',
          sender: hit.sender || '—',
          receiver: hit.receiver || '—',
          packageType: hit.packageType || '—',
          weight: (hit.weightKg ? `${hit.weightKg}kg` : (hit.weight || '—')),
          createdAt: hit.createdAt || '—',
          estimatedDelivery: hit.estimatedDelivery || '—',
          steps: [
            { status: '已下单', description: '包裹已创建', location: hit.origin || '—', timestamp: `${hit.createdAt || ''} 09:00`, completed: true },
            { status: '已入库', description: '包裹已入库', location: hit.origin || '—', timestamp: '', completed: hit.status==='已入库' || hit.status==='运输中' || hit.status==='已签收' },
            { status: '运输中', description: '干线运输', location: hit.destination || '—', timestamp: '', completed: hit.status==='运输中' || hit.status==='已签收' },
            { status: '已签收', description: '收件人已签收', location: hit.destination || '—', timestamp: '', completed: hit.status==='已签收' },
          ],
        };
        setTrackingResult(mapped);
        // 更新本地缓存（用于下一次离线展示）
        try {
          const raw = localStorage.getItem('packages');
          const list: any[] = raw ? JSON.parse(raw) : [];
          const filtered = list.filter(p => (p.trackingNumber || p.tracking_no) !== mapped.trackingNumber);
          localStorage.setItem('packages', JSON.stringify([{ ...hit, trackingNumber: mapped.trackingNumber }, ...filtered].slice(0, 500)));
        } catch {}
        setLoading(false);
        return;
      }
    } catch {}

    // 后端未命中或网络失败 → 回退到本地缓存与示例单号
    const fromLocal = localIndex[trackingNumber];
    const result = fromLocal || mockTrackingData[trackingNumber];
    if (result) {
      setTrackingResult(result);
    } else {
      setError(t('tracking.notFound') || '未找到该快递单号，请检查后重试');
    }
    setLoading(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case '已签收':
        return 'success';
      case '运输中':
        return 'warning';
      case '已揽收':
        return 'info';
      case '派送中':
        return 'primary';
      default:
        return 'default';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case '已签收':
        return <CheckCircle />;
      case '运输中':
        return <LocalShipping />;
      case '已揽收':
        return <Schedule />;
      case '派送中':
        return <LocationOn />;
      default:
        return <AccessTime />;
    }
  };

  return (
    <Box>
      {/* Hero Section */}
      <Box
        sx={{
          background: 'linear-gradient(135deg, #1976d2 0%, #42a5f5 100%)',
          color: 'white',
          py: { xs: 6, md: 8 },
          textAlign: 'center',
        }}
      >
        <Container maxWidth="lg">
          <Typography
            variant={isMobile ? 'h3' : 'h2'}
            component="h1"
            sx={{ fontWeight: 700, mb: 3 }}
          >
            {t('tracking.title') || '快递查询'}
          </Typography>
          <Typography variant="h6" sx={{ opacity: 0.9, maxWidth: 600, mx: 'auto' }}>
            {t('tracking.subtitle') || '输入快递单号，实时跟踪您的包裹状态'}
          </Typography>
        </Container>
      </Box>

      <Container maxWidth="lg" sx={{ py: 6 }}>
        {/* 查询表单 */}
        <Paper sx={{ p: 4, mb: 4 }}>
          <Typography variant="h5" component="h2" sx={{ mb: 3, fontWeight: 600, textAlign: 'center' }}>
            {t('tracking.formTitle') || '查询快递状态'}
          </Typography>
          
          <Grid container spacing={3} alignItems="center" justifyContent="center">
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                placeholder={t('tracking.placeholder') || '请输入快递单号'}
                value={trackingNumber}
                onChange={(e) => setTrackingNumber(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                variant="outlined"
                size="medium"
                sx={{ mb: { xs: 2, md: 0 } }}
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Button
                fullWidth
                variant="contained"
                onClick={handleSearch}
                disabled={loading}
                startIcon={loading ? null : <Search />}
                sx={{ py: 1.5, fontSize: '1.1rem' }}
              >
                {loading ? (t('tracking.searching') || '查询中...') : (t('tracking.search') || '查询')}
              </Button>
            </Grid>
          </Grid>

          {error && (
            <Alert severity="error" sx={{ mt: 3 }}>
              {error}
            </Alert>
          )}
        </Paper>

        {/* 查询结果 */}
        {trackingResult && (
          <Grid container spacing={4}>
            {/* 包裹信息 */}
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Typography variant="h6" component="h3" sx={{ mb: 3, fontWeight: 600 }}>
                    {t('tracking.packageInfo') || '包裹信息'}
                  </Typography>
                  
                  <Box sx={{ mb: 2 }}>
                    <Typography variant="body2" color="text.secondary">
                      {t('tracking.number') || '快递单号'}
                    </Typography>
                    <Typography variant="body1" sx={{ fontWeight: 600, fontFamily: 'monospace' }}>
                      {trackingResult.trackingNumber}
                    </Typography>
                  </Box>

                  <Box sx={{ mb: 2 }}>
                    <Typography variant="body2" color="text.secondary">
                      {t('tracking.currentStatus') || '当前状态'}
                    </Typography>
                    <Chip
                      label={trackingResult.status}
                      color={getStatusColor(trackingResult.status) as any}
                      icon={getStatusIcon(trackingResult.status)}
                      sx={{ mt: 1 }}
                    />
                  </Box>

                  <Box sx={{ mb: 2 }}>
                    <Typography variant="body2" color="text.secondary">
                      {t('tracking.sender') || '寄件人'}
                    </Typography>
                    <Typography variant="body1">
                      {trackingResult.sender}
                    </Typography>
                  </Box>

                  <Box sx={{ mb: 2 }}>
                    <Typography variant="body2" color="text.secondary">
                      {t('tracking.receiver') || '收件人'}
                    </Typography>
                    <Typography variant="body1">
                      {trackingResult.receiver}
                    </Typography>
                  </Box>

                  <Box sx={{ mb: 2 }}>
                    <Typography variant="body2" color="text.secondary">
                      {t('tracking.type') || '包裹类型'}
                    </Typography>
                    <Typography variant="body1">
                      {trackingResult.packageType}
                    </Typography>
                  </Box>

                  <Box sx={{ mb: 2 }}>
                    <Typography variant="body2" color="text.secondary">
                      {t('tracking.weight') || '重量'}
                    </Typography>
                    <Typography variant="body1">
                      {trackingResult.weight}
                    </Typography>
                  </Box>

                  <Box sx={{ mb: 2 }}>
                    <Typography variant="body2" color="text.secondary">
                      {t('tracking.createdAt') || '创建时间'}
                    </Typography>
                    <Typography variant="body1">
                      {trackingResult.createdAt}
                    </Typography>
                  </Box>

                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      {t('tracking.eta') || '预计送达'}
                    </Typography>
                    <Typography variant="body1" sx={{ fontWeight: 600, color: 'primary.main' }}>
                      {trackingResult.estimatedDelivery}
                    </Typography>
                  </Box>
                </CardContent>
              </Card>
            </Grid>

            {/* 物流轨迹 */}
            <Grid item xs={12} md={8}>
              <Card>
                <CardContent>
                  <Typography variant="h6" component="h3" sx={{ mb: 3, fontWeight: 600 }}>
                    {t('tracking.timeline') || '物流轨迹'}
                  </Typography>
                  
                  <Stepper orientation="vertical">
                    {trackingResult.steps.map((step, index) => (
                      <Step key={index} active={step.completed} completed={step.completed}>
                        <StepLabel
                          icon={step.completed ? <CheckCircle color="success" /> : <Schedule />}
                          sx={{
                            '& .MuiStepLabel-label': {
                              color: step.completed ? 'text.primary' : 'text.secondary',
                              fontWeight: step.completed ? 600 : 400,
                            },
                          }}
                        >
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <Typography variant="body1" sx={{ fontWeight: 600 }}>
                              {step.status}
                            </Typography>
                            {step.timestamp && (
                              <Typography variant="body2" color="text.secondary">
                                {step.timestamp}
                              </Typography>
                            )}
                          </Box>
                        </StepLabel>
                        <StepContent>
                          <Box sx={{ mb: 2 }}>
                            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                              {step.description}
                            </Typography>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                              <LocationOn sx={{ fontSize: 16, color: 'text.secondary' }} />
                              <Typography variant="body2" color="text.secondary">
                                {step.location}
                              </Typography>
                            </Box>
                          </Box>
                        </StepContent>
                      </Step>
                    ))}
                  </Stepper>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        )}

        {/* 示例单号已移除 */}
      </Container>
    </Box>
  );
};

export default TrackingPage;
