import React from 'react';
import {
  Box,
  Container,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  TextField,
  Paper,
  useTheme,
  useMediaQuery,
} from '@mui/material';
import {
  Phone,
  Email,
  LocationOn,
  AccessTime,
  Send,
  WhatsApp,
  Facebook,
  Instagram,
  QrCode2,
  ContentCopy,
} from '@mui/icons-material';
import { useState } from 'react';
import { useI18n } from '../i18n';

const ContactPage: React.FC = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const { t } = useI18n();

  const contactInfo = [
    {
      icon: <Phone sx={{ fontSize: 40, color: 'primary.main' }} />,
      title: t('contact.hotline'),
      content: '09-259369349 / 09-678363134',
      subtitle: t('contact.service24h'),
      action: 'tel:09259369349',
      actionText: t('contact.callNow'),
    },
    {
      icon: <WhatsApp sx={{ fontSize: 40, color: 'success.main' }} />,
      title: t('contact.whatsapp'),
      content: '09-259369349 / 09-678363134',
      subtitle: t('contact.online'),
      action: 'https://wa.me/959259369349',
      actionText: t('contact.sendMsg'),
    },
    {
      icon: <QrCode2 sx={{ fontSize: 40, color: 'success.main' }} />,
      title: t('contact.wechat'),
      content: 'ID：AMT349',
      subtitle: t('contact.online'),
      action: '#wechat',
      actionText: t('contact.copyWechat'),
    },
    {
      icon: <Email sx={{ fontSize: 40, color: 'secondary.main' }} />,
      title: t('contact.email'),
      content: 'marketlink982@gmail.com',
      subtitle: t('contact.business'),
      action: 'mailto:marketlink982@gmail.com',
      actionText: t('contact.sendMsg'),
    },
    {
      icon: <LocationOn sx={{ fontSize: 40, color: 'warning.main' }} />,
      title: t('contact.address'),
      content: 'Chan Mya Tha Zi ，Mandalay',
      subtitle: t('contact.countryCity'),
      action: '#',
      actionText: t('contact.viewMap'),
    },
  ];

  const businessHours = [
    { day: t('contact.hours.monfri'), time: '08:00 - 20:00' },
    { day: t('contact.hours.sat'), time: '09:00 - 18:00' },
    { day: t('contact.hours.sun'), time: '10:00 - 16:00' },
    { day: t('contact.hours.holiday'), time: '10:00 - 16:00' },
  ];

  const socialMedia = [
    { name: 'Facebook', icon: <Facebook />, color: '#1877f2', url: 'https://facebook.com/' },
    { name: 'Instagram', icon: <Instagram />, color: '#e4405f', url: 'https://instagram.com/' },
    { name: 'WhatsApp', icon: <WhatsApp />, color: '#25d366', url: 'https://wa.me/959259369349' },
  ];

  const [wechatImgVisible, setWechatImgVisible] = useState(true);
  const copyWechatId = () => {
    navigator.clipboard?.writeText('AMT349');
  };

  return (
    <Box>
      {/* Hero Section */}
      <Box
        sx={{
          background: 'linear-gradient(135deg, #1976d2 0%, #42a5f5 100%)',
          color: 'white',
          py: { xs: 6, md: 8 },
          textAlign: 'center',
        }}
      >
        <Container maxWidth="lg">
          <Typography
            variant={isMobile ? 'h3' : 'h2'}
            component="h1"
            sx={{ fontWeight: 700, mb: 3 }}
          >
            {t('contact.title')}
          </Typography>
          <Typography variant="h6" sx={{ opacity: 0.9, maxWidth: 600, mx: 'auto' }}>
            {t('contact.subtitle')}
          </Typography>
        </Container>
      </Box>

      <Container maxWidth="lg" sx={{ py: 6 }}>
        {/* 联系信息卡片 */}
        <Box sx={{ mb: 6 }}>
          <Typography variant="h4" component="h2" sx={{ mb: 4, fontWeight: 600, textAlign: 'center' }}>
            {t('contact.methods')}
          </Typography>
          <Grid container spacing={4}>
            {contactInfo.map((info, index) => (
              <Grid item xs={12} sm={6} lg={3} key={index}>
                <Card sx={{ height: '100%', textAlign: 'center' }}>
                  <CardContent sx={{ py: 4 }}>
                    <Box sx={{ mb: 2 }}>
                      {info.icon}
                    </Box>
                    <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>
                      {info.title}
                    </Typography>
                    <Typography variant="body1" sx={{ mb: 1, fontWeight: 500 }}>
                      {info.content}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                      {info.subtitle}
                    </Typography>
                    {info.title.toLowerCase().includes('wechat') ? (
                      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }}>
                        {wechatImgVisible && (
                          <Box sx={{ width: 160, height: 160, mb: 1 }}>
                            <img
                              src="/wechat-qr.png"
                              alt="wechat-qr"
                              loading="lazy"
                              style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 8 }}
                              onError={() => setWechatImgVisible(false)}
                            />
                          </Box>
                        )}
                        <Button variant="outlined" size="small" startIcon={<ContentCopy />} onClick={copyWechatId} sx={{ textTransform: 'none' }}>
                          {t('contact.copyWechat')}
                        </Button>
                      </Box>
                    ) : (
                      <Button
                        variant="outlined"
                        size="small"
                        href={info.action}
                        target={info.action.startsWith('http') ? '_blank' : undefined}
                        sx={{ textTransform: 'none' }}
                      >
                        {info.actionText}
                      </Button>
                    )}
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Box>

        <Grid container spacing={6}>
          {/* 营业时间 */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent sx={{ p: 4 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                  <AccessTime sx={{ fontSize: 32, color: 'primary.main', mr: 2 }} />
                  <Typography variant="h5" sx={{ fontWeight: 600 }}>
                    {t('contact.hours.title')}
                  </Typography>
                </Box>
                <Box>
                  {businessHours.map((schedule, index) => (
                    <Box
                      key={index}
                      sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        py: 1,
                        borderBottom: index < businessHours.length - 1 ? '1px solid #f0f0f0' : 'none',
                      }}
                    >
                      <Typography variant="body1">{schedule.day}</Typography>
                      <Typography variant="body1" sx={{ fontWeight: 500 }}>
                        {schedule.time}
                      </Typography>
                    </Box>
                  ))}
                </Box>
              </CardContent>
            </Card>
          </Grid>

          {/* 社交媒体 */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent sx={{ p: 4 }}>
                <Typography variant="h5" sx={{ fontWeight: 600, mb: 3 }}>
                  {t('contact.follow.title')}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                  {t('contact.follow.desc')}
                </Typography>
                <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                  {socialMedia.map((social, index) => (
                    <Button
                      key={index}
                      variant="outlined"
                      startIcon={social.icon}
                      href={social.url}
                      target="_blank"
                      sx={{
                        borderColor: social.color,
                        color: social.color,
                        '&:hover': {
                          borderColor: social.color,
                          backgroundColor: `${social.color}10`,
                        },
                        textTransform: 'none',
                      }}
                    >
                      {social.name}
                    </Button>
                  ))}
                </Box>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* 在线留言表单 */}
        <Box sx={{ mt: 6 }}>
          <Paper sx={{ p: 4 }}>
            <Typography variant="h4" component="h2" sx={{ mb: 3, fontWeight: 600, textAlign: 'center' }}>
              {t('contact.form.title')}
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ mb: 4, textAlign: 'center' }}>
              {t('contact.form.desc')}
            </Typography>
            <Box component="form" name="contact-message" method="POST" action="/success?type=contact" data-netlify="true" data-netlify-honeypot="bot-field">
              <input type="hidden" name="form-name" value="contact-message" />
              <TextField name="bot-field" sx={{ display: 'none' }} />
              <Grid container spacing={3}>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label={t('contact.form.name')}
                    name="name"
                    placeholder={t('contact.form.name.ph')}
                    required
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label={t('contact.form.phone')}
                    name="phone"
                    placeholder={t('contact.form.phone.ph')}
                    required
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label={t('contact.form.email')}
                    name="email"
                    type="email"
                    placeholder={t('contact.form.email.ph')}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label={t('contact.form.message')}
                    name="message"
                    multiline
                    rows={4}
                    placeholder={t('contact.form.message.ph')}
                    required
                  />
                </Grid>
                <Grid item xs={12} sx={{ textAlign: 'center' }}>
                  <Button
                    type="submit"
                    variant="contained"
                    size="large"
                    startIcon={<Send />}
                    sx={{ py: 1.5, px: 4, fontSize: '1.1rem' }}
                  >
                    {t('contact.form.submit')}
                  </Button>
                </Grid>
              </Grid>
            </Box>
          </Paper>
        </Box>

        {/* 服务承诺 */}
        <Box sx={{ mt: 6 }}>
          <Typography variant="h4" component="h2" sx={{ mb: 4, fontWeight: 600, textAlign: 'center' }}>
            {t('contact.promise.title')}
          </Typography>
          <Grid container spacing={4}>
            <Grid item xs={12} md={4}>
              <Card sx={{ textAlign: 'center', height: '100%' }}>
                <CardContent sx={{ py: 4 }}>
                  <Box
                    sx={{
                      width: 80,
                      height: 80,
                      borderRadius: '50%',
                      background: 'linear-gradient(135deg, #4caf50 0%, #66bb6a 100%)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      mx: 'auto',
                      mb: 3,
                    }}
                  >
                    <Typography variant="h4" sx={{ color: 'white', fontWeight: 700 }}>
                      24h
                    </Typography>
                  </Box>
                  <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                    {t('contact.promise.24h')}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {t('contact.promise.24h.desc')}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card sx={{ textAlign: 'center', height: '100%' }}>
                <CardContent sx={{ py: 4 }}>
                  <Box
                    sx={{
                      width: 80,
                      height: 80,
                      borderRadius: '50%',
                      background: 'linear-gradient(135deg, #ff9800 0%, #ffb74d 100%)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      mx: 'auto',
                      mb: 3,
                    }}
                  >
                    <Typography variant="h4" sx={{ color: 'white', fontWeight: 700 }}>
                      2h
                    </Typography>
                  </Box>
                  <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                    {t('contact.promise.2h')}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {t('contact.promise.2h.desc')}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card sx={{ textAlign: 'center', height: '100%' }}>
                <CardContent sx={{ py: 4 }}>
                  <Box
                    sx={{
                      width: 80,
                      height: 80,
                      borderRadius: '50%',
                      background: 'linear-gradient(135deg, #f44336 0%, #ef5350 100%)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      mx: 'auto',
                      mb: 3,
                    }}
                  >
                    <Typography variant="h4" sx={{ color: 'white', fontWeight: 700 }}>
                      100%
                    </Typography>
                  </Box>
                  <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                    {t('contact.promise.secure')}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {t('contact.promise.secure.desc')}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Box>
      </Container>
    </Box>
  );
};

export default ContactPage;
