import React, { useEffect, useState } from 'react';
import {
  Box,
  Container,
  Paper,
  TextField,
  Button,
  Typography,
  Alert,
  CircularProgress,
  InputAdornment,
  IconButton,
} from '@mui/material';
import {
  Visibility,
  VisibilityOff,
  Lock,
  Person,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { setAdminSession, getRemainingLockMs, recordFailedLogin, resetFailedLogin, getAdminSession } from '../utils/auth';
import { Box as ImgBox } from '@mui/material';

const AdminLogin: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [capsOn, setCapsOn] = useState(false);
  const navigate = useNavigate();
  // 移除未使用的 theme，避免构建告警

  // 默认主账号（请妥善保管）
  // 该常量已移至 useEffect 内部以避免依赖告警

  // 登录改为走云端函数 + 已有会话自动按角色跳转
  useEffect(() => {
    try {
      const sess = getAdminSession();
      if (sess) {
        const r = (sess.role || '').trim().toLowerCase();
        if (r === 'staff') navigate('/admin/inventory');
        else if (r === 'accountant') navigate('/admin/finance');
        else if (r === 'manager') navigate('/admin/dashboard');
        else if (r === 'master') navigate('/admin/dashboard');
        else navigate('/admin/dashboard');
      }
    } catch {}
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username.trim() || !password.trim()) {
      setError('请输入用户名和密码');
      return;
    }

    // 检查是否被锁定
    const remaining = getRemainingLockMs();
    if (remaining > 0) {
      const secs = Math.ceil(remaining / 1000);
      setError(`多次失败，账户已临时锁定。请 ${secs} 秒后再试`);
      return;
    }

    setLoading(true);
    setError('');

    try {
      const endpoint = `${window.location.origin}/.netlify/functions/auth-login`;
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
        credentials: 'include',
      });
      const data = await res.json().catch(() => ({}));

      if (res.ok) {
        const roleRaw = (data.role || 'staff');
        const r = (roleRaw || '').trim().toLowerCase();
        setAdminSession(data.username || username, r);
        resetFailedLogin();
        if (r === 'staff') navigate('/admin/inventory');
        else if (r === 'accountant') navigate('/admin/finance');
        else if (r === 'manager') navigate('/admin/dashboard');
        else if (r === 'master') navigate('/admin/dashboard');
        else navigate('/admin/dashboard');
      } else if (res.status === 400) {
        const { locked, remainingMs } = recordFailedLogin();
        setError(data.message || (locked ? `多次失败，账户已锁定 ${Math.ceil(remainingMs / 60000)} 分钟` : '用户名或密码错误'));
      } else {
        setError(data.message ? `服务器错误：${data.message}` : '服务器错误，请稍后重试');
      }
    } catch (e) {
      setError('网络异常，请检查连接后重试');
    }
    setLoading(false);
  };

  // 取消演示账号按钮，不再提供

  return (
    <Box
      sx={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        display: 'flex',
        alignItems: 'center',
        py: 4,
      }}
    >
      <Container maxWidth="sm">
        <Paper
          elevation={24}
          sx={{
            p: 4,
            borderRadius: 3,
            backgroundColor: 'rgba(255, 255, 255, 0.95)',
            backdropFilter: 'blur(10px)',
          }}
        >
          {/* 头部：公司 LOGO + 名称 */}
          <Box sx={{ textAlign: 'center', mb: 4 }}>
            <Box sx={{ display: 'flex', justifyContent: 'center', mb: 2 }}>
              {/* logo 加载顺序：/ml-logo.png → /ML LOGO.png → /logo.png，均不存在则显示占位 */}
              <LoginLogo />
            </Box>
            <Typography variant="h4" component="h1" sx={{ fontWeight: 700, mb: 1 }}>
              MARKET-LINK EXPRESS
            </Typography>
            <Typography variant="h6" component="h2" color="text.secondary">
              员工登录系统
            </Typography>
          </Box>

          {/* 登录表单 */}
          <form onSubmit={handleSubmit}>
            <TextField
              fullWidth
              label="用户名"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              variant="outlined"
              margin="normal"
              required
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Person color="action" />
                  </InputAdornment>
                ),
              }}
              sx={{ mb: 3 }}
            />

            <TextField
              fullWidth
              label="密码"
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyUp={(e:any) => {
                try { setCapsOn(Boolean(e.getModifierState && e.getModifierState('CapsLock'))); } catch {}
              }}
              variant="outlined"
              margin="normal"
              required
              helperText={capsOn ? '注意：键盘 Caps Lock（大写锁定）已开启' : ' '}
              FormHelperTextProps={{ sx: { color: capsOn ? 'warning.main' : 'text.disabled', m: 0 } }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Lock color="action" />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => setShowPassword(!showPassword)}
                      edge="end"
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
              sx={{ mb: 3 }}
            />

            {error && (
              <Alert severity="error" sx={{ mb: 3 }}>
                {error}
              </Alert>
            )}

            <Button
              type="submit"
              fullWidth
              variant="contained"
              size="large"
              disabled={loading}
              sx={{
                py: 1.5,
                fontSize: '1.1rem',
                fontWeight: 600,
                borderRadius: 2,
                background: 'linear-gradient(45deg, #1976d2, #42a5f5)',
                '&:hover': {
                  background: 'linear-gradient(45deg, #1565c0, #1976d2)',
                },
              }}
            >
              {loading ? (
                <CircularProgress size={24} color="inherit" />
              ) : (
                '登录'
              )}
            </Button>
          </form>

          {/* 提示与安全卡片按需已移除 */}
        </Paper>
      </Container>
    </Box>
  );
};

export default AdminLogin;

// 内联小组件：登录页 LOGO（带回退）
const LoginLogo: React.FC = () => {
  const [idx, setIdx] = useState(0);
  const sources = ['/ml-logo.png', '/ML LOGO.png', '/logo.png'];
  if (idx < sources.length) {
    return (
      <ImgBox
        component="img"
        src={encodeURI(sources[idx])}
        alt="MARKET-LINK EXPRESS"
        onError={() => setIdx(i => i + 1)}
        sx={{ height: 56, width: 'auto' }}
      />
    );
  }
  return <ImgBox sx={{ width: 56, height: 56, borderRadius: '50%', background: 'linear-gradient(135deg, #1976d2, #42a5f5)' }} />;
};
