import React, { useEffect, useState } from 'react';
import {
  Box,
  Container,
  Typography,
  Button,
  Grid,
  Card,
  useTheme,
  useMediaQuery,
  CardContent,
} from '@mui/material';
import {
  Speed,
  Security,
  Support,
  TrendingUp,
  ArrowForward,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useI18n } from '../i18n';
import NewsCarousel from '../components/NewsCarousel';
import { fetchWithRetry } from '../utils/backend';

const HomePage: React.FC = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const navigate = useNavigate();
  const { t } = useI18n();

  // 首页指标卡片已移除，不再请求 metrics

  const features = [
    {
      icon: <Speed sx={{ fontSize: 48, color: 'primary.main' }} />,
      title: t('home.feature.speed.title'),
      description: t('home.feature.speed.desc'),
    },
    {
      icon: <Security sx={{ fontSize: 48, color: 'primary.main' }} />,
      title: t('home.feature.sec.title'),
      description: t('home.feature.sec.desc'),
    },
    {
      icon: <Support sx={{ fontSize: 48, color: 'primary.main' }} />,
      title: t('home.feature.cs.title'),
      description: t('home.feature.cs.desc'),
    },
    {
      icon: <TrendingUp sx={{ fontSize: 48, color: 'primary.main' }} />,
      title: t('home.feature.track.title'),
      description: t('home.feature.track.desc'),
    },
  ];

  const stats = [
    { number: '100+', label: t('home.stats.cities') },
    { number: '50万+', label: t('home.stats.clients') },
    { number: '99.9%', label: t('home.stats.onTime') },
    { number: '24h', label: t('home.stats.hours') },
  ];

  return (
    <Box>
      {/* Hero Section */}
      <Box
        sx={{
          background: 'linear-gradient(135deg, #1976d2 0%, #42a5f5 100%)',
          color: 'white',
          py: { xs: 8, md: 12 },
          textAlign: 'center',
        }}
      >
        <Container maxWidth="lg">
          <Typography
            variant={isMobile ? 'h4' : 'h2'}
            component="h1"
            sx={{ fontWeight: 800, mb: 2, letterSpacing: 1 }}
          >
            {t('home.hero.title')}
          </Typography>
          <Typography variant="subtitle1" sx={{ opacity: 0.9, mb: 3 }}>
            {t('home.hero.subtitle')}
          </Typography>
          <Typography variant="body1" sx={{ opacity: 0.9, mb: 4, maxWidth: 600, mx: 'auto' }}>
            {t('home.hero.desc')}
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Button
              variant="contained"
              size="large"
              onClick={() => navigate('/tracking')}
              sx={{
                backgroundColor: 'white',
                color: 'primary.main',
                px: 4,
                py: 1.5,
                fontSize: '1.1rem',
                fontWeight: 600,
                '&:hover': {
                  backgroundColor: 'grey.100',
                },
              }}
            >
              {t('home.hero.track')}
            </Button>
            <Button
              variant="outlined"
              size="large"
              onClick={() => navigate('/services')}
              sx={{
                borderColor: 'white',
                color: 'white',
                px: 4,
                py: 1.5,
                fontSize: '1.1rem',
                fontWeight: 600,
                '&:hover': {
                  borderColor: 'white',
                  backgroundColor: 'rgba(255,255,255,0.1)',
                },
              }}
            >
              {t('home.hero.learn')}
            </Button>
          </Box>
        </Container>
      </Box>

      {/* 服务特色 */}
      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Typography
          variant="h3"
          component="h2"
          align="center"
          sx={{ mb: 6, fontWeight: 600 }}
        >
          {t('home.why.title')}
        </Typography>
        
        <Grid container spacing={4}>
          {features.map((feature, index) => (
            <Grid item xs={12} sm={6} md={3} key={index}>
              <Card
                sx={{
                  height: '100%',
                  textAlign: 'center',
                  p: 3,
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    transform: 'translateY(-8px)',
                    boxShadow: '0 8px 30px rgba(0,0,0,0.15)',
                  },
                }}
              >
                <Box sx={{ mb: 3 }}>{feature.icon}</Box>
                <Typography variant="h6" component="h3" sx={{ mb: 2, fontWeight: 600 }}>
                  {feature.title}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {feature.description}
                </Typography>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* 新闻/广告轮播位 */}
      <Box sx={{ backgroundColor: 'grey.50', py: 6 }}>
        <Container maxWidth="lg">
          <Typography variant="h4" component="h2" align="center" sx={{ mb: 1.5, fontWeight: 700 }}>
            每日物流快讯 · 有趣更有用
          </Typography>
          <Typography align="center" color="text.secondary" sx={{ mb: 3 }}>行业热点 / 新政策 / 限时活动，每天自动更新</Typography>
          <NewsCarousel />
        </Container>
      </Box>

      {/* 服务流程 */}
      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Typography
          variant="h3"
          component="h2"
          align="center"
          sx={{ mb: 6, fontWeight: 600 }}
        >
          {t('home.flow.title')}
        </Typography>
        
        <Grid container spacing={4}>
          {[
            { step: '1', title: t('home.flow.1'), description: t('home.flow.1.desc') },
            { step: '2', title: t('home.flow.2'), description: t('home.flow.2.desc') },
            { step: '3', title: t('home.flow.3'), description: t('home.flow.3.desc') },
            { step: '4', title: t('home.flow.4'), description: t('home.flow.4.desc') },
            { step: '5', title: t('home.flow.5'), description: t('home.flow.5.desc') },
          ].map((item, index) => (
            <Grid item xs={12} sm={6} md={2.4} key={index}>
              <Box sx={{ textAlign: 'center' }}>
                <Box
                  sx={{
                    width: 60,
                    height: 60,
                    borderRadius: '50%',
                    backgroundColor: 'primary.main',
                    color: 'white',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '1.5rem',
                    fontWeight: 'bold',
                    mx: 'auto',
                    mb: 2,
                  }}
                >
                  {item.step}
                </Box>
                <Typography variant="h6" component="h3" sx={{ mb: 1, fontWeight: 600 }}>
                  {item.title}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {item.description}
                </Typography>
              </Box>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* 快速查询和价格咨询 */}
      <Box sx={{ backgroundColor: 'primary.main', color: 'white', py: 8 }}>
        <Container maxWidth="lg">
          <Grid container spacing={6}>
            <Grid item xs={12} md={6}>
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="h3" component="h2" sx={{ mb: 3, fontWeight: 600 }}>
                  {t('home.cta.track.title')}
                </Typography>
                <Typography variant="h6" sx={{ mb: 4, opacity: 0.9 }}>
                  {t('home.cta.track.desc')}
                </Typography>
                <Button
                  variant="outlined"
                  size="large"
                  onClick={() => navigate('/tracking')}
                  sx={{
                    color: 'white',
                    borderColor: 'white',
                    px: 4,
                    py: 1.5,
                    fontSize: '1.1rem',
                    fontWeight: 600,
                    '&:hover': {
                      borderColor: 'white',
                      backgroundColor: 'rgba(255,255,255,0.1)',
                    },
                  }}
                  endIcon={<ArrowForward />}
                >
                  {t('home.cta.track.btn')}
                </Button>
              </Box>
            </Grid>
            <Grid item xs={12} md={6}>
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="h3" component="h2" sx={{ mb: 3, fontWeight: 600 }}>
                  {t('home.cta.price.title')}
                </Typography>
                <Typography variant="h6" sx={{ mb: 4, opacity: 0.9 }}>
                  {t('home.cta.price.desc')}
                </Typography>
                <Button
                  variant="outlined"
                  size="large"
                  onClick={() => navigate('/pricing')}
                  sx={{
                    color: 'white',
                    borderColor: 'white',
                    px: 4,
                    py: 1.5,
                    fontSize: '1.1rem',
                    fontWeight: 600,
                    '&:hover': {
                      borderColor: 'white',
                      backgroundColor: 'rgba(255,255,255,0.1)',
                    },
                  }}
                  endIcon={<ArrowForward />}
                >
                  {t('home.cta.price.btn')}
                </Button>
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </Box>
  );
};

export default HomePage;
