import React, { useState } from 'react';
import {
  Box,
  Container,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  TextField,
  Paper,
  Chip,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Stepper,
  Step,
  StepLabel,
  useTheme,
  useMediaQuery,
} from '@mui/material';
import {
  LocalShipping,
  Flight,
  DirectionsCar,
  Calculate,
  Send,
  CheckCircle,
  Info,
} from '@mui/icons-material';
import { useI18n } from '../i18n';

interface PricingForm {
  serviceType: string;
  fromLocation: string;
  toLocation: string;
  packageType: string;
  weight: string;
  dimensions: string;
  customerName: string;
  phone: string;
  email: string;
  additionalNotes: string;
}

const PricingPage: React.FC = () => {
  const [pricingForm, setPricingForm] = useState<PricingForm>({
    serviceType: '',
    fromLocation: '',
    toLocation: '',
    packageType: '',
    weight: '',
    dimensions: '',
    customerName: '',
    phone: '',
    email: '',
    additionalNotes: '',
  });
  const [showForm, setShowForm] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const { t } = useI18n();

  const encode = (data: Record<string, string>) =>
    Object.keys(data)
      .map((key) => encodeURIComponent(key) + '=' + encodeURIComponent(data[key]))
      .join('&');

  const submitNetlifyForm = async () => {
    const payload: Record<string, string> = {
      'form-name': 'pricing-inquiry',
      serviceType: pricingForm.serviceType,
      fromLocation: pricingForm.fromLocation,
      toLocation: pricingForm.toLocation,
      packageType: pricingForm.packageType,
      weight: pricingForm.weight,
      dimensions: pricingForm.dimensions,
      customerName: pricingForm.customerName,
      phone: pricingForm.phone,
      email: pricingForm.email,
      additionalNotes: pricingForm.additionalNotes,
    };
    await fetch('/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      },
      body: encode(payload),
    });
    // 跳转到成功页
    window.location.assign('/success?type=pricing');
  };

  const serviceTypes = [
    { id: 'domestic', name: t('pricing.service.domestic'), icon: <LocalShipping />, color: 'primary' as const },
    { id: 'international', name: t('pricing.service.international'), icon: <Flight />, color: 'secondary' as const },
    { id: 'city', name: t('pricing.service.city'), icon: <DirectionsCar />, color: 'success' as const },
  ];

  const packageTypes = [
    t('pricing.pkg.documents'),
    t('pricing.pkg.electronics'),
    t('pricing.pkg.apparel'),
    t('pricing.pkg.food'),
    t('pricing.pkg.fragile'),
    t('pricing.pkg.oversize'),
    t('pricing.pkg.other'),
  ];

  const handleInputChange = (field: keyof PricingForm, value: string) => {
    setPricingForm(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    await submitNetlifyForm();
    setSubmitted(true);
    setShowForm(false);
    setActiveStep(0);
    setPricingForm({
      serviceType: '',
      fromLocation: '',
      toLocation: '',
      packageType: '',
      weight: '',
      dimensions: '',
      customerName: '',
      phone: '',
      email: '',
      additionalNotes: '',
    });
  };

  const handleNext = () => {
    setActiveStep(prev => prev + 1);
  };

  const handleBack = () => {
    setActiveStep(prev => prev - 1);
  };

  const steps = [t('pricing.step.service'), t('pricing.step.package'), t('pricing.step.contact')];

  const renderStepContent = (step: number) => {
    switch (step) {
      case 0:
        return (
          <Grid container spacing={3}>
            {serviceTypes.map((service) => (
              <Grid item xs={12} sm={6} key={service.id}>
                <Card
                  sx={{
                    cursor: 'pointer',
                    border: pricingForm.serviceType === service.id ? `2px solid ${(theme.palette as any)[service.color]?.main || theme.palette.primary.main}` : '2px solid transparent',
                    '&:hover': {
                      transform: 'translateY(-4px)',
                      boxShadow: '0 8px 25px rgba(0,0,0,0.15)',
                    },
                    transition: 'all 0.3s ease',
                  }}
                  onClick={() => handleInputChange('serviceType', service.id)}
                >
                  <CardContent sx={{ textAlign: 'center', py: 3 }}>
                    <Box sx={{ color: `${service.color}.main`, mb: 2 }}>
                      {service.icon}
                    </Box>
                    <Typography variant="h6" sx={{ fontWeight: 600 }}>{service.name}</Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        );
      case 1:
        return (
          <Grid container spacing={3}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label={t('pricing.form.from')}
                value={pricingForm.fromLocation}
                onChange={(e) => handleInputChange('fromLocation', e.target.value)}
                placeholder={t('pricing.form.from.ph')}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label={t('pricing.form.to')}
                value={pricingForm.toLocation}
                onChange={(e) => handleInputChange('toLocation', e.target.value)}
                placeholder={t('pricing.form.to.ph')}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth required>
                <InputLabel>{t('pricing.form.packageType')}</InputLabel>
                <Select
                  value={pricingForm.packageType}
                  label={t('pricing.form.packageType')}
                  onChange={(e) => handleInputChange('packageType', e.target.value)}
                >
                  {packageTypes.map((type) => (
                    <MenuItem key={type} value={type}>{type}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label={t('pricing.form.weight')}
                value={pricingForm.weight}
                onChange={(e) => handleInputChange('weight', e.target.value)}
                placeholder={t('pricing.form.weight.ph')}
                type="number"
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label={t('pricing.form.dimensions')}
                value={pricingForm.dimensions}
                onChange={(e) => handleInputChange('dimensions', e.target.value)}
                placeholder="L×W×H"
                helperText={t('pricing.form.dimensions.help')}
              />
            </Grid>
          </Grid>
        );
      case 2:
        return (
          <Grid container spacing={3}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label={t('pricing.form.name')}
                value={pricingForm.customerName}
                onChange={(e) => handleInputChange('customerName', e.target.value)}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label={t('pricing.form.phone')}
                value={pricingForm.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label={t('pricing.form.email')}
                value={pricingForm.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                type="email"
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label={t('pricing.form.note')}
                value={pricingForm.additionalNotes}
                onChange={(e) => handleInputChange('additionalNotes', e.target.value)}
                multiline
                rows={3}
                placeholder={t('pricing.form.note.ph')}
              />
            </Grid>
          </Grid>
        );
      default:
        return null;
    }
  };

  return (
    <Box>
      {/* Hero Section */}
      <Box
        sx={{
          background: 'linear-gradient(135deg, #1976d2 0%, #42a5f5 100%)',
          color: 'white',
          py: { xs: 6, md: 8 },
          textAlign: 'center',
        }}
      >
        <Container maxWidth="lg">
          <Typography
            variant={isMobile ? 'h3' : 'h2'}
            component="h1"
            sx={{ fontWeight: 700, mb: 3 }}
          >
            {t('pricing.title')}
          </Typography>
          <Typography variant="h6" sx={{ opacity: 0.9, maxWidth: 600, mx: 'auto' }}>
            {t('pricing.subtitle')}
          </Typography>
        </Container>
      </Box>

      <Container maxWidth="lg" sx={{ py: 6 }}>
        {/* 服务价格概览 */}
        <Box sx={{ mb: 6 }}>
          <Typography variant="h4" component="h2" sx={{ mb: 4, fontWeight: 600, textAlign: 'center' }}>
            {t('pricing.overview')}
          </Typography>
          <Grid container spacing={4} justifyContent="center">
            {serviceTypes.map((service) => (
              <Grid item xs={12} sm={6} md={4} key={service.id}>
                <Card sx={{ height: '100%', textAlign: 'center' }}>
                  <CardContent sx={{ py: 4 }}>
                    <Box sx={{ color: `${service.color}.main`, mb: 2 }}>
                      {service.icon}
                    </Box>
                    <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                      {service.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                      {service.id === 'domestic' && t('pricing.service.domestic.desc')}
                      {service.id === 'international' && t('pricing.service.international.desc')}
                      {service.id === 'city' && t('pricing.service.city.desc')}
                    </Typography>
                    <Chip
                      label={t('pricing.inquiryLabel')}
                      color={service.color as any}
                      variant="outlined"
                      icon={<Calculate />}
                    />
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Box>

        {/* 在线询价 */}
        <Box sx={{ mb: 6 }}>
          <Paper sx={{ p: 4, textAlign: 'center' }}>
            <Typography variant="h4" component="h2" sx={{ mb: 3, fontWeight: 600 }}>
              {t('pricing.online')}
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ mb: 4, maxWidth: 600, mx: 'auto' }}>
              {t('pricing.online.desc')}
            </Typography>
            <Button
              variant="contained"
              size="large"
              startIcon={<Calculate />}
              onClick={() => setShowForm(true)}
              sx={{ py: 1.5, px: 4, fontSize: '1.1rem' }}
            >
              {t('pricing.start')}
            </Button>
          </Paper>
        </Box>

        {/* 价格优势 */}
        <Box sx={{ mb: 6 }}>
          <Typography variant="h4" component="h2" sx={{ mb: 4, fontWeight: 600, textAlign: 'center' }}>
            {t('pricing.advantages')}
          </Typography>
          <Grid container spacing={4}>
            <Grid item xs={12} md={4}>
              <Card sx={{ textAlign: 'center', height: '100%' }}>
                <CardContent sx={{ py: 4 }}>
                  <CheckCircle sx={{ color: 'success.main', fontSize: 48, mb: 2 }} />
                  <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                    {t('pricing.adv.transparent')}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {t('pricing.adv.transparent.desc')}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card sx={{ textAlign: 'center', height: '100%' }}>
                <CardContent sx={{ py: 4 }}>
                  <Calculate sx={{ color: 'primary.main', fontSize: 48, mb: 2 }} />
                  <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                    {t('pricing.adv.bulk')}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {t('pricing.adv.bulk.desc')}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card sx={{ textAlign: 'center', height: '100%' }}>
                <CardContent sx={{ py: 4 }}>
                  <Info sx={{ color: 'info.main', fontSize: 48, mb: 2 }} />
                  <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                    {t('pricing.adv.flexible')}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {t('pricing.adv.flexible.desc')}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Box>

        {/* 询价表单对话框 */}
        <Dialog
          open={showForm}
          onClose={() => setShowForm(false)}
          maxWidth="md"
          fullWidth
        >
          <DialogTitle sx={{ textAlign: 'center', pb: 1 }}>
            <Typography variant="h5" sx={{ fontWeight: 600 }}>
              {t('pricing.online')}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {t('pricing.online.desc')}
            </Typography>
          </DialogTitle>
          <DialogContent>
            <Stepper activeStep={activeStep} sx={{ mb: 4, mt: 2 }}>
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>
            {renderStepContent(activeStep)}
          </DialogContent>
          <DialogActions sx={{ px: 3, pb: 3 }}>
            <Button
              disabled={activeStep === 0}
              onClick={handleBack}
              sx={{ mr: 1 }}
            >
              {t('pricing.btn.prev')}
            </Button>
            <Button
              variant="contained"
              onClick={activeStep === steps.length - 1 ? handleSubmit : handleNext}
              startIcon={activeStep === steps.length - 1 ? <Send /> : null}
            >
              {activeStep === steps.length - 1 ? t('pricing.btn.submit') : t('pricing.btn.next')}
            </Button>
          </DialogActions>
        </Dialog>

        {/* 提交成功提示 */}
        {submitted && (
          <Alert
            severity="success"
            sx={{ mt: 3 }}
            onClose={() => setSubmitted(false)}
          >
            {t('pricing.success')}
          </Alert>
        )}
      </Container>
    </Box>
  );
};

export default PricingPage;
