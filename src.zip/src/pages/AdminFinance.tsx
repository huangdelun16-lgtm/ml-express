import React, { useEffect, useState } from 'react';
import {
	AppBar,
	Toolbar,
	Typography,
	Box,
	Container,
	Grid,
	Card,
	CardContent,
	Paper,
	Table,
	TableHead,
	TableRow,
	TableCell,
	TableContainer,
	TableBody,
	Button,
	TextField,
	Dialog,
	DialogTitle,
	DialogContent,
	DialogActions,
	Chip,
	MenuItem,
	Pagination,
	IconButton,
	CircularProgress,
	Divider,
} from '@mui/material';
import { LocalShipping, Person, Delete } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { getAdminSession } from '../utils/auth';
import { fetchWithRetry } from '../utils/backend';

interface User {
	username: string;
	role: string;
	loginTime: string;
}

interface FinanceTxn {
	id: string;
	type: '收入' | '支出';
	category?: string;
	amount: number;
	note: string;
	date: string; // YYYY-MM-DD
	status?: '已入账' | '作废' | '运输中' | '待签收';
	tracking_no?: string;
	destination?: string; // Added for destination
}

const AdminFinance: React.FC = () => {
	const navigate = useNavigate();
	const [user, setUser] = useState<User | null>(null);
	const [finance, setFinance] = useState<FinanceTxn[]>([]);
	const [openFinanceDialog, setOpenFinanceDialog] = useState(false);
	const [newTxn, setNewTxn] = useState<FinanceTxn>({ id: '', type: '收入', category: '运费', amount: 0, note: '', date: new Date().toISOString().slice(0,10) });
	const [amountInput, setAmountInput] = useState<string>('');
	const [startDate, setStartDate] = useState<string>('');
	const [endDate, setEndDate] = useState<string>('');
	const [typeFilter, setTypeFilter] = useState<'all' | '收入' | '支出'>('all');
	const [financePage, setFinancePage] = useState<number>(1);
	const [financePageSize] = useState<number>(8);
	const [financeTotal, setFinanceTotal] = useState<number>(0);
	const [summaryAll, setSummaryAll] = useState<{ income: number; expense: number; net: number }>({ income: 0, expense: 0, net: 0 });
	const [summaryFiltered, setSummaryFiltered] = useState<{ income: number; expense: number; net: number }>({ income: 0, expense: 0, net: 0 });
	const [editTxn, setEditTxn] = useState<FinanceTxn | null>(null);
  // 对齐/差异检查
  const [diffOpen, setDiffOpen] = useState(false);
  const [diffLoading, setDiffLoading] = useState(false);
  const [diffMissing, setDiffMissing] = useState<string[]>([]);
  const [diffExtra, setDiffExtra] = useState<string[]>([]);

	const handleReconcile = async () => {
		try {
			await fetchWithRetry('/.netlify/functions/reconcile', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json', 'x-ml-actor': user!.username },
				body: JSON.stringify({ fixAmounts: true, markTransit: true, deleteVoided: true })
			});
			const qs = new URLSearchParams({ page: String(financePage), pageSize: String(financePageSize), start: startDate || '', end: endDate || '', type: (typeFilter==='all'?'':typeFilter) });
			const res = await fetchWithRetry('/.netlify/functions/finances-manage?' + qs.toString(), { headers: { 'x-ml-actor': user!.username, 'x-ml-role': user!.role } });
			const j = await res.json();
			setFinance(j.items || []);
			setFinanceTotal(j.total || 0);
			if (j.summaryAll) setSummaryAll(j.summaryAll);
			if (j.summaryFiltered) setSummaryFiltered(j.summaryFiltered);
		} catch {}
	};

  const handleCheckDiff = async () => {
    if (!user) return;
    setDiffOpen(true);
    setDiffLoading(true);
    try {
      const r = await fetchWithRetry('/.netlify/functions/reconcile', { headers: { 'x-ml-actor': user.username } });
      const j = await r.json();
      setDiffMissing(Array.isArray(j.missingFinance) ? j.missingFinance : []);
      setDiffExtra(Array.isArray(j.extraFinance) ? j.extraFinance : []);
    } catch {
      setDiffMissing([]); setDiffExtra([]);
    } finally {
      setDiffLoading(false);
    }
  };

	useEffect(() => {
		const sess = getAdminSession();
		if (!sess) { navigate('/admin/login'); return; }
		const u = { username: sess.username, role: sess.role, loginTime: sess.loginTime };
		setUser(u);
		// 允许 accountant/manager/master 访问财务（去除空格/大小写差异）
		const r = (u.role || '').trim().toLowerCase();
		if (!['accountant','manager','master'].includes(r)) { navigate('/admin/dashboard'); return; }
		(async () => {
			try {
				const qs = new URLSearchParams({ page: String(financePage), pageSize: String(financePageSize), start: startDate || '', end: endDate || '', type: (typeFilter==='all'?'':typeFilter) });
				const res = await fetchWithRetry('/.netlify/functions/finances-manage?' + qs.toString(), { headers: { 'x-ml-actor': u.username, 'x-ml-role': u.role } });
				const j = await res.json();
				setFinance(j.items || []);
				setFinanceTotal(j.total || 0);
				if (j.summaryAll) setSummaryAll(j.summaryAll);
				if (j.summaryFiltered) setSummaryFiltered(j.summaryFiltered);
			} catch {
				// 保留会话，避免闪退；显示空数据即可
			}
		})();
	}, [navigate, financePage, financePageSize, startDate, endDate, typeFilter]);

	const inRange = (d: string) => {
		if (startDate && d < startDate) return false;
		if (endDate && d > endDate) return false;
		return true;
	};

	const filteredFinance = finance.filter(t => inRange(t.date) && (typeFilter === 'all' || t.type === typeFilter));
	const totalFinancePages = Math.max(1, Math.ceil((financeTotal || 0) / financePageSize));
	const financePageData = filteredFinance; // 已服务端分页

	useEffect(() => { setFinancePage(1); }, [startDate, endDate, typeFilter]);

	const useFiltered = Boolean(startDate || endDate || typeFilter !== 'all');
	const displayIncome = useFiltered ? summaryFiltered.income : summaryAll.income;
	const displayExpense = useFiltered ? summaryFiltered.expense : summaryAll.expense;
	const financeSummary = { income: displayIncome, expense: displayExpense };

	useEffect(() => {
		if (openFinanceDialog) {
			setAmountInput('');
		}
	}, [openFinanceDialog]);

	// 仅 accountant/master 可编辑（manager 监督但不改动）
	const role = (user?.role || '').trim().toLowerCase();
	const canEditFinance = !!(user && ['accountant','master'].includes(role));

	const handleAddTxn = async () => {
		const amountNum = Number(amountInput);
		if (!amountInput || Number.isNaN(amountNum) || amountNum <= 0) return;
		const resp = await fetchWithRetry('/.netlify/functions/finances-manage', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json', 'x-ml-actor': user!.username, 'x-ml-role': user!.role },
			body: JSON.stringify({ type: newTxn.type, category: newTxn.category, amount: amountNum, note: newTxn.note, date: newTxn.date })
		});
		if (!resp.ok) {
			try { const j = await resp.json(); alert(j.message || '新增失败'); } catch { alert('新增失败'); }
			return;
		}
		const qs = new URLSearchParams({ page: String(financePage), pageSize: String(financePageSize), start: startDate || '', end: endDate || '', type: (typeFilter==='all'?'':typeFilter) });
		const res = await fetchWithRetry('/.netlify/functions/finances-manage?' + qs.toString(), { headers: { 'x-ml-actor': user!.username, 'x-ml-role': user!.role } });
		const j = await res.json();
		setFinance(j.items || []);
		setFinanceTotal(j.total || 0);
		if (j.summaryAll) setSummaryAll(j.summaryAll);
		if (j.summaryFiltered) setSummaryFiltered(j.summaryFiltered);
		setOpenFinanceDialog(false);
		setNewTxn({ id: '', type: '收入', category: '运费', amount: 0, note: '', date: new Date().toISOString().slice(0,10) });
		setAmountInput('');
	};

	const handleDelete = async (id: string) => {
		if (!user) return;
		if (!(window as any).confirm('确定删除该记录吗？')) return;
		try {
			const r = await fetchWithRetry('/.netlify/functions/finances-manage', {
				method: 'DELETE',
				headers: { 'Content-Type': 'application/json', 'x-ml-actor': user!.username, 'x-ml-role': user!.role },
				body: JSON.stringify({ id })
			});
			if (!r.ok) { try { const j = await r.json(); alert(j.message || '删除失败'); } catch { alert('删除失败'); } return; }
			const qs = new URLSearchParams({ page: String(financePage), pageSize: String(financePageSize), start: startDate || '', end: endDate || '', type: (typeFilter==='all'?'':typeFilter) });
			const res = await fetchWithRetry('/.netlify/functions/finances-manage?' + qs.toString(), { headers: { 'x-ml-actor': user!.username, 'x-ml-role': user!.role } });
			const j = await res.json();
			setFinance(j.items || []);
			setFinanceTotal(j.total || 0);
			if (j.summaryAll) setSummaryAll(j.summaryAll);
			if (j.summaryFiltered) setSummaryFiltered(j.summaryFiltered);
		} catch {
			alert('删除失败');
		}
	};

	if (!user) return null;

	return (
		<Box sx={{ minHeight: '100vh', backgroundColor: 'grey.50' }}>
			<AppBar position="static" sx={{ backgroundColor: 'white', color: 'text.primary' }}>
				<Toolbar>
					<Box sx={{ flexGrow: 1 }} />
					{/* 后台顶部导航 */}
					<Box sx={{ display: 'flex', gap: 1, mr: 2 }}>
						<Button size="small" onClick={() => navigate('/admin/inventory')}>包裹管理</Button>
						<Button size="small" onClick={() => navigate('/admin/transport')}>运输系统</Button>
						<Button size="small" variant="contained" onClick={() => navigate('/admin/finance')}>财务系统</Button>
						<Button size="small" onClick={() => navigate('/admin/dashboard')}>控制台</Button>
					</Box>
					{/* 财务分页放在右侧头部 */}
					<Pagination count={totalFinancePages} page={financePage} onChange={(_, p)=>setFinancePage(p)} size="small" color="primary" />
					<Box sx={{ display: 'flex', alignItems: 'center', gap: 2, ml: 2 }}>
						<Typography variant="body2" color="text.secondary">欢迎，{user.username} ({user.role})</Typography>
						<Person />
					</Box>
				</Toolbar>
			</AppBar>

			<Container maxWidth="lg" sx={{ py: 4 }}>
				<Grid container spacing={3} sx={{ mb: 2 }}>
					<Grid item xs={12} sm={6} md={3}>
						<Card>
							<CardContent sx={{ textAlign: 'center' }}>
								<Typography variant="body2" color="text.secondary">总收入</Typography>
								<Typography variant="h5" sx={{ fontWeight: 700, color: 'success.main' }}>{financeSummary.income.toLocaleString()} 缅币</Typography>
							</CardContent>
						</Card>
					</Grid>
					<Grid item xs={12} sm={6} md={3}>
						<Card>
							<CardContent sx={{ textAlign: 'center' }}>
								<Typography variant="body2" color="text.secondary">总支出</Typography>
								<Typography variant="h5" sx={{ fontWeight: 700, color: 'error.main' }}>{financeSummary.expense.toLocaleString()} 缅币</Typography>
							</CardContent>
						</Card>
					</Grid>
					<Grid item xs={12} sm={6} md={3}>
						<Card>
							<CardContent sx={{ textAlign: 'center' }}>
								<Typography variant="body2" color="text.secondary">净收益</Typography>
								<Typography variant="h5" sx={{ fontWeight: 700 }}>{(financeSummary.income - financeSummary.expense).toLocaleString()} 缅币</Typography>
							</CardContent>
						</Card>
					</Grid>
					<Grid item xs={12} sm={6} md={3}>
						<Box sx={{ display: 'flex', gap: 1 }}>
							{canEditFinance && <Button fullWidth variant="contained" onClick={() => setOpenFinanceDialog(true)}>新增记录</Button>}
							{['accountant','manager','master'].includes(user.role) && (
								<Button fullWidth variant="outlined" onClick={handleReconcile}>对齐包裹收入</Button>
							)}
                {['accountant','manager','master'].includes(user.role) && (
                  <Button fullWidth variant="outlined" onClick={handleCheckDiff}>检查差异</Button>
                )}
						</Box>
					</Grid>
				</Grid>

				<Paper sx={{ p: 2, mb: 2 }}>
					<Grid container spacing={2} alignItems="center">
						<Grid item xs={12} md={3}>
							<TextField fullWidth label="开始日期" type="date" value={startDate} onChange={(e)=>setStartDate(e.target.value)} InputLabelProps={{ shrink: true }} />
						</Grid>
						<Grid item xs={12} md={3}>
							<TextField fullWidth label="结束日期" type="date" value={endDate} onChange={(e)=>setEndDate(e.target.value)} InputLabelProps={{ shrink: true }} />
						</Grid>
						<Grid item xs={12} md={3}>
							<TextField select fullWidth label="类型" value={typeFilter} onChange={(e)=>setTypeFilter(e.target.value as any)}>
								<MenuItem value="all">全部</MenuItem>
								<MenuItem value="收入">收入</MenuItem>
								<MenuItem value="支出">支出</MenuItem>
							</TextField>
						</Grid>
						<Grid item xs={12} md={3} sx={{ display: 'flex', gap: 1 }}>
							<Button variant="outlined" onClick={()=>{ const t=new Date().toISOString().slice(0,10); setStartDate(t); setEndDate(t); }}>今天</Button>
							<Button variant="outlined" onClick={()=>{ const now=new Date(); const t=now.toISOString().slice(0,10); const first=new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0,10); setStartDate(first); setEndDate(t); }}>本月</Button>
							<Button variant="text" onClick={()=>{ setStartDate(''); setEndDate(''); setTypeFilter('all'); }}>重置</Button>
						</Grid>
					</Grid>
				</Paper>

				<Paper>
					<TableContainer>
						<Table>
							<TableHead>
								<TableRow sx={{ backgroundColor: 'grey.50' }}>
									<TableCell>类型</TableCell>
									<TableCell>分类</TableCell>
									<TableCell>金额</TableCell>
									<TableCell>单号</TableCell>
									<TableCell>目的地</TableCell>
									<TableCell>备注</TableCell>
									<TableCell>日期</TableCell>
									<TableCell>状态</TableCell>
									<TableCell align="right">操作</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{financePageData.map(txn => (
									<TableRow key={txn.id} hover>
										<TableCell>
											<Chip size="small" color={txn.type === '收入' ? 'success' : 'error'} label={txn.type} />
										</TableCell>
										<TableCell>{txn.category || '—'}</TableCell>
										<TableCell>
											<Typography variant="body2" sx={{ fontWeight: 600, color: txn.type === '收入' ? 'success.main' : 'error.main' }}>
												{txn.type === '收入' ? '+' : '-'}{txn.amount.toLocaleString()} 缅币
											</Typography>
										</TableCell>
										<TableCell>
											{txn.tracking_no ? (
												<Chip size="small" label={txn.tracking_no} variant="outlined" />
											) : (
												<Typography variant="body2" color="text.secondary">—</Typography>
											)}
										</TableCell>
										<TableCell>
											{txn.destination ? (
												<Typography variant="body2">{txn.destination}</Typography>
											) : (
												<Typography variant="body2" color="text.secondary">—</Typography>
											)}
										</TableCell>
										<TableCell>{txn.note}</TableCell>
										<TableCell>{txn.date}</TableCell>
										<TableCell>
											<Chip size="small" 
												color={txn.status === '已入账' ? 'success' : txn.status === '待签收' ? 'warning' : txn.status === '运输中' ? 'info' : 'default'} 
												label={txn.status || '已入账'} 
											/>
										</TableCell>
										<TableCell align="right">
											{canEditFinance && <Button size="small" onClick={()=>setEditTxn({ ...txn })}>编辑</Button>}
											{canEditFinance && <IconButton size="small" color="error" onClick={() => handleDelete(txn.id)}><Delete fontSize="small" /></IconButton>}
										</TableCell>
									</TableRow>
								))}
							</TableBody>
						</Table>
					</TableContainer>
				</Paper>

				{/* 差异检查弹窗 */}
				<Dialog open={diffOpen} onClose={()=>setDiffOpen(false)} maxWidth="sm" fullWidth>
					<DialogTitle>财务与包裹差异</DialogTitle>
					<DialogContent>
						{diffLoading ? (
							<Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', py: 4 }}>
								<CircularProgress size={24} />
							</Box>
						) : (
							<>
								<Typography variant="subtitle2" sx={{ mb: 1 }}>缺失的收入（有包裹但无财务）：{diffMissing.length} 条</Typography>
								{diffMissing.length === 0 ? (
									<Typography variant="body2" color="text.secondary">无</Typography>
								) : (
									<Box sx={{ display: 'flex', flexWrap: 'wrap', gap: .5, mb: 2 }}>
										{diffMissing.map((t, i) => (<Chip key={t + i} size="small" label={t} />))}
									</Box>
								)}
								<Divider sx={{ my: 1 }} />
								<Typography variant="subtitle2" sx={{ mb: 1 }}>多余的财务（有财务但无包裹）：{diffExtra.length} 条</Typography>
								{diffExtra.length === 0 ? (
									<Typography variant="body2" color="text.secondary">无</Typography>
								) : (
									<Box sx={{ display: 'flex', flexWrap: 'wrap', gap: .5 }}>
										{diffExtra.map((t, i) => (<Chip key={t + i} size="small" label={t} color="warning" />))}
									</Box>
								)}
							</>
						)}
					</DialogContent>
					<DialogActions>
						<Button onClick={()=>setDiffOpen(false)}>关闭</Button>
					</DialogActions>
				</Dialog>

				<Typography variant="subtitle1" sx={{ mt: 3, mb: 1, fontWeight: 600 }}>按日汇总</Typography>
				<Paper>
					<TableContainer>
						<Table>
							<TableHead>
								<TableRow sx={{ backgroundColor: 'grey.50' }}>
									<TableCell>日期</TableCell>
									<TableCell>当日收入</TableCell>
									<TableCell>当日支出</TableCell>
									<TableCell>当日净额</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{Object.entries(filteredFinance.reduce<Record<string, { i:number; e:number }>>((acc, t)=>{ const k=t.date; acc[k] ||= { i:0, e:0 }; if ((t.status||'已入账')==='已入账') { if (t.type==='收入') acc[k].i+=t.amount; else acc[k].e+=t.amount; } return acc; }, {})).sort((a,b)=>a[0]<b[0]?1:-1).map(([date, v])=> (
									<TableRow key={date}>
										<TableCell>{date}</TableCell>
										<TableCell sx={{ color: 'success.main' }}>{v.i.toLocaleString()}</TableCell>
										<TableCell sx={{ color: 'error.main' }}>{v.e.toLocaleString()}</TableCell>
										<TableCell>{(v.i - v.e).toLocaleString()}</TableCell>
									</TableRow>
								))}
							</TableBody>
						</Table>
					</TableContainer>
				</Paper>
			</Container>

			<Dialog open={openFinanceDialog} onClose={() => setOpenFinanceDialog(false)} maxWidth="sm" fullWidth>
				<DialogTitle>新增财务记录</DialogTitle>
				<DialogContent>
					<Grid container spacing={2} sx={{ mt: 1 }}>
						<Grid item xs={12} sm={6}>
							<TextField select fullWidth label="类型" value={newTxn.type} onChange={(e) => setNewTxn({ ...newTxn, type: e.target.value as any })}>
								<MenuItem value="收入">收入</MenuItem>
								<MenuItem value="支出">支出</MenuItem>
							</TextField>
						</Grid>
						<Grid item xs={12} sm={6}>
							<TextField
								fullWidth
								label="金额"
								placeholder="请输入金额"
								value={amountInput}
								onChange={(e) => {
									let v = e.target.value.replace(/[^0-9]/g, '');
									v = v.replace(/^0+(?=\d)/, '');
									setAmountInput(v);
								}}
								onFocus={() => { if (amountInput === '0') setAmountInput(''); }}
								inputMode="numeric"
							/>
						</Grid>
						<Grid item xs={12}>
							<TextField select fullWidth label="类别" value={newTxn.category} onChange={(e)=> setNewTxn({ ...newTxn, category: e.target.value })}>
								{(newTxn.type === '收入' ? ['运费','快递服务','上门取件费','附加费','其他收入'] : ['油费','包装材料','工资','房租','维修保养','罚款','其他支出']).map(c => (
									<MenuItem key={c} value={c}>{c}</MenuItem>
								))}
							</TextField>
						</Grid>
						<Grid item xs={12} sm={6}>
							<TextField fullWidth label="日期" type="date" value={newTxn.date} onChange={(e) => setNewTxn({ ...newTxn, date: e.target.value })} InputLabelProps={{ shrink: true }} />
						</Grid>
						<Grid item xs={12}>
							<TextField fullWidth label="备注" value={newTxn.note} onChange={(e) => setNewTxn({ ...newTxn, note: e.target.value })} />
						</Grid>
					</Grid>
				</DialogContent>
				<DialogActions>
					<Button onClick={() => setOpenFinanceDialog(false)}>取消</Button>
					<Button variant="contained" onClick={handleAddTxn}>保存</Button>
				</DialogActions>
			</Dialog>

				{/* 编辑记录 */}
				<Dialog open={Boolean(editTxn)} onClose={() => setEditTxn(null)} maxWidth="sm" fullWidth>
					<DialogTitle>编辑财务记录</DialogTitle>
					<DialogContent>
						<Grid container spacing={2} sx={{ mt: 1 }}>
							<Grid item xs={12} sm={6}>
								<TextField select fullWidth label="类型" value={editTxn?.type || '收入'} onChange={(e)=>setEditTxn(prev=> prev ? ({ ...prev, type: e.target.value as any }) : prev)}>
									<MenuItem value="收入">收入</MenuItem>
									<MenuItem value="支出">支出</MenuItem>
								</TextField>
							</Grid>
							<Grid item xs={12} sm={6}>
								<TextField select fullWidth label="状态" value={editTxn?.status || '已入账'} onChange={(e)=>setEditTxn(prev=> prev ? ({ ...prev, status: e.target.value as any }) : prev)}>
									<MenuItem value="已入账">已入账</MenuItem>
									<MenuItem value="待签收">待签收</MenuItem>
									<MenuItem value="作废">作废</MenuItem>
								</TextField>
							</Grid>
							<Grid item xs={12}>
								<TextField select fullWidth label="类别" value={editTxn?.category || ''} onChange={(e)=>setEditTxn(prev=> prev ? ({ ...prev, category: e.target.value }) : prev)}>
									{((editTxn?.type || '收入') === '收入' ? ['运费','快递服务','上门取件费','附加费','其他收入'] : ['油费','包装材料','工资','房租','维修保养','罚款','其他支出']).map(c => (
										<MenuItem key={c} value={c}>{c}</MenuItem>
									))}
								</TextField>
							</Grid>
							<Grid item xs={12} sm={6}>
								<TextField fullWidth label="金额" type="number" value={editTxn?.amount ?? ''} onChange={(e)=> setEditTxn(prev=> prev ? ({ ...prev, amount: Number(e.target.value) }) : prev)} />
							</Grid>
							<Grid item xs={12} sm={6}>
								<TextField fullWidth label="日期" type="date" value={editTxn?.date || ''} onChange={(e)=> setEditTxn(prev=> prev ? ({ ...prev, date: e.target.value }) : prev)} InputLabelProps={{ shrink: true }} />
							</Grid>
							<Grid item xs={12}>
								<TextField fullWidth label="备注" value={editTxn?.note || ''} onChange={(e)=> setEditTxn(prev=> prev ? ({ ...prev, note: e.target.value }) : prev)} />
							</Grid>
						</Grid>
					</DialogContent>
					<DialogActions>
						<Button onClick={()=>setEditTxn(null)}>取消</Button>
						<Button variant="contained" onClick={async ()=>{
							if (!editTxn) return;
							await fetchWithRetry('/.netlify/functions/finances-manage', {
								method: 'PATCH',
								headers: { 'Content-Type': 'application/json', 'x-ml-actor': user!.username, 'x-ml-role': user!.role },
								body: JSON.stringify({ id: editTxn.id, type: editTxn.type, category: editTxn.category, amount: editTxn.amount, note: editTxn.note, date: editTxn.date, status: editTxn.status || '已入账' })
							});
							// 重新加载列表
							const qs = new URLSearchParams({ page: String(financePage), pageSize: String(financePageSize), start: startDate || '', end: endDate || '', type: (typeFilter==='all'?'':typeFilter) });
							const res = await fetchWithRetry('/.netlify/functions/finances-manage?' + qs.toString(), { headers: { 'x-ml-actor': user!.username, 'x-ml-role': user!.role } });
							const j = await res.json();
							setFinance(j.items || []);
							setFinanceTotal(j.total || 0);
							if (j.summaryAll) setSummaryAll(j.summaryAll);
							if (j.summaryFiltered) setSummaryFiltered(j.summaryFiltered);
							setEditTxn(null);
						}}>保存</Button>
					</DialogActions>
				</Dialog>
		</Box>
	);
};

export default AdminFinance;


