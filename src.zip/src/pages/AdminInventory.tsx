import React, { useEffect, useMemo, useState } from 'react';
import { AppBar, Toolbar, Typography, Box, Container, Button, Table, TableHead, TableRow, TableCell, TableBody, TableContainer, Paper, Chip, Dialog, DialogTitle, DialogContent, DialogActions, Grid, TextField, MenuItem, IconButton, Snackbar, Alert, Card, CardContent, Pagination, Autocomplete, Skeleton, Drawer, Divider } from '@mui/material';
import SwipeableItem from '../components/SwipeableItem';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import { LocalShipping, Person, Edit, Delete } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { getAdminSession } from '../utils/auth';
import { fetchWithRetry } from '../utils/backend';

interface User { username: string; role: string; loginTime: string }

type PackageStatus = '已下单' | '已入库' | '运输中' | '已签收' | '已取消';

type PackageItem = {
  id: string;
  trackingNumber: string;
  sender: string;
  receiver: string;
  origin?: string;
  destination?: string;
  packageType: string;
  weightKg: number;
  dimensions: { lengthCm: number; widthCm: number; heightCm: number };
  fee: number;
  status: PackageStatus;
  createdAt: string; // YYYY-MM-DD
  note?: string;
  inboundBy?: string | null;
  inboundAt?: string | null;
};

const AdminInventory: React.FC = () => {
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [user, setUser] = useState<User | null>(null);
  const [packages, setPackages] = useState<PackageItem[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | PackageStatus>('all');
  const [openDialog, setOpenDialog] = useState(false);
  const [draft, setDraft] = useState<PackageItem | null>(null);
  const [toast, setToast] = useState<{ open: boolean; text: string; severity: 'success' | 'error' | 'info' | 'warning' }>({ open: false, text: '', severity: 'success' });
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [pkgPage, setPkgPage] = useState<number>(1);
  const [pkgPageSize] = useState<number>(20);
  const [pkgTotal, setPkgTotal] = useState<number>(0);
  const [pkgTotalAll, setPkgTotalAll] = useState<number>(0);
  const [mobileFilterOpen, setMobileFilterOpen] = useState<boolean>(false);
  // 历史输入联想（仅本机）
  const [histSender, setHistSender] = useState<string[]>([]);
  const [histReceiver, setHistReceiver] = useState<string[]>([]);
  const [histOrigin, setHistOrigin] = useState<string[]>([]);
  const [histDestination, setHistDestination] = useState<string[]>([]);
  const [histPkgType, setHistPkgType] = useState<string[]>([]);
  type PackageTemplate = {
    sender?: string;
    receiver?: string;
    origin?: string;
    destination?: string;
    packageType?: string;
    weightKg?: number;
    dimensions?: { lengthCm: number; widthCm: number; heightCm: number };
    fee?: number;
    status?: PackageStatus;
  };
  const [histTemplates, setHistTemplates] = useState<PackageTemplate[]>([]);
  // 出库对话框：输入货运号并完成装车
  const [outboundOpen, setOutboundOpen] = useState(false);
  const [outboundFreight, setOutboundFreight] = useState('');
  const [outboundPkg, setOutboundPkg] = useState<PackageItem | null>(null);
  const [outboundBusy, setOutboundBusy] = useState(false);
  // 出库对话框：货运号历史（本机）
  const OUTBOUND_FREIGHT_KEY = 'ml_hist_outbound_freight';
  const OUTBOUND_FREIGHT_TTL_DAYS = 7; // 可改为 1 或 2 天
  const [outboundFreightOptions, setOutboundFreightOptions] = useState<string[]>([]);
  // 签收证明弹窗状态
  const [signProofOpen, setSignProofOpen] = useState(false);
  const [signProofItem, setSignProofItem] = useState<PackageItem | null>(null);
  const [signPhotos, setSignPhotos] = useState<string[]>([]);
  const [signSignature, setSignSignature] = useState('');
  const [courierName, setCourierName] = useState('');
  const [courierPhone, setCourierPhone] = useState('');
  const [courierId, setCourierId] = useState('');
  const [signNote, setSignNote] = useState('');
  const [signBusy, setSignBusy] = useState(false);
  // 财务一致性检查
  const [reconcileBusy, setReconcileBusy] = useState(false);
  const [reconcileHint, setReconcileHint] = useState<{ missing: number; extra: number } | null>(null);

  // 展示层英文化映射（不改数据库）。对 staff 账号默认显示英文；其他角色按本地偏好（默认中文）。
  const getLangPref = (): 'zh' | 'en' => {
    try {
      const saved = (localStorage.getItem('__ML_LANG__') || 'zh') as 'zh' | 'en';
      const role = (user?.role || '').trim().toLowerCase();
      if (role === 'staff') return 'en';
      return saved === 'en' ? 'en' : 'zh';
    } catch {
      return 'zh';
    }
  };
  const tr = (zh: string, en: string) => (getLangPref() === 'en' ? en : zh);
  const statusTextMap: Record<PackageStatus, string> = {
    '已下单': 'Ordered',
    '已入库': 'Inbound',
    '运输中': 'In transit',
    '已签收': 'Delivered',
    '已取消': 'Canceled',
  };
  const statusLabel = (s: PackageStatus) => (getLangPref() === 'en' ? statusTextMap[s] : s);

  const loadOutboundFreightHistory = () => {
    try {
      const raw = localStorage.getItem(OUTBOUND_FREIGHT_KEY);
      const parsed = raw ? JSON.parse(raw) : [];
      const now = Date.now();
      const ttlMs = OUTBOUND_FREIGHT_TTL_DAYS * 24 * 60 * 60 * 1000;
      const arr: Array<{ value: string; ts: number }> = Array.isArray(parsed)
        ? parsed.map((x: any) => typeof x === 'string' ? { value: x, ts: now } : { value: String(x?.value || ''), ts: Number(x?.ts || now) })
        : [];
      const filtered = arr
        .filter(r => !!r.value && (now - r.ts) <= ttlMs)
        .sort((a,b)=> b.ts - a.ts);
      const opts = Array.from(new Set(filtered.map(r => r.value)));
      setOutboundFreightOptions(opts);
    } catch {}
  };

  const pushOutboundFreightHistory = (value: string) => {
    const v = (value || '').trim(); if (!v) return;
    try {
      const now = Date.now();
      const raw = localStorage.getItem(OUTBOUND_FREIGHT_KEY);
      const parsed: Array<{ value: string; ts: number }> = raw ? JSON.parse(raw) : [];
      const arr = Array.isArray(parsed) ? parsed : [];
      const merged = [{ value: v, ts: now }, ...arr.filter((r: any) => r?.value !== v)].slice(0, 50);
      localStorage.setItem(OUTBOUND_FREIGHT_KEY, JSON.stringify(merged));
    } catch {}
  };

  useEffect(() => {
    if (outboundOpen) loadOutboundFreightHistory();
  }, [outboundOpen]);

  useEffect(() => {
    const sess = getAdminSession();
    if (!sess) { navigate('/admin/login'); return; }
    const u = { username: sess.username, role: sess.role, loginTime: sess.loginTime };
    setUser(u);
    (async () => {
      setLoading(true);
      try {
        const qs = new URLSearchParams({
          page: String(pkgPage),
          pageSize: String(pkgPageSize),
          status: statusFilter === 'all' ? '' : String(statusFilter),
          search: search.trim(),
        });
        const res = await fetchWithRetry('/.netlify/functions/packages-manage?' + qs.toString(), { headers: { 'x-ml-actor': u.username, 'x-ml-role': u.role } as any });
        if (!res.ok) throw new Error('packages api failed');
        const j = await res.json();
        setPackages(j.items || []);
        setPkgTotal(j.total || 0);
        // 获取全量总数（不受搜索/状态影响）
        try {
          const resAll = await fetchWithRetry('/.netlify/functions/packages-manage?page=1&pageSize=1', { headers: { 'x-ml-actor': u.username, 'x-ml-role': u.role } as any });
          const jAll = await resAll.json();
          setPkgTotalAll(jAll.total || 0);
        } catch {}
      } catch {
        try {
          const rp = localStorage.getItem('packages');
          const local = rp ? JSON.parse(rp) : [];
          setPackages(local);
          setPkgTotal(Array.isArray(local) ? local.length : 0);
          setPkgTotalAll(Array.isArray(local) ? local.length : 0);
          setToast({ open: true, text: '后端暂时不可用，已切换为本地数据', severity: 'warning' });
        } catch {
          // 保留会话，不跳回登录
        }
      } finally { setLoading(false); }
    })();
  }, [navigate, pkgPage, pkgPageSize, statusFilter, search]);

  // 加载财务一致性提示（仅 manager/master/accountant 可见）
  useEffect(() => {
    (async ()=>{
      try {
        const sess = getAdminSession();
        if (!sess) return;
        const role = (sess.role || '').trim().toLowerCase();
        if (!['manager','master','accountant'].includes(role)) { setReconcileHint(null); return; }
        const r = await fetchWithRetry('/.netlify/functions/reconcile', { headers: { 'x-ml-actor': sess.username } });
        const j = await r.json();
        const missing = Array.isArray(j.missingFinance) ? j.missingFinance.length : 0;
        const extra = Array.isArray(j.extraFinance) ? j.extraFinance.length : 0;
        setReconcileHint({ missing, extra });
      } catch { setReconcileHint(null); }
    })();
  }, [pkgTotalAll]);

  useEffect(() => {
    try { localStorage.setItem('packages', JSON.stringify(packages)); } catch {}
  }, [packages]);
  const canModify = !!(user && ['manager','master','staff'].includes(user.role));

  // 读取历史
  useEffect(() => {
    try {
      setHistSender(JSON.parse(localStorage.getItem('ml_hist_sender') || '[]'));
      setHistReceiver(JSON.parse(localStorage.getItem('ml_hist_receiver') || '[]'));
      setHistOrigin(JSON.parse(localStorage.getItem('ml_hist_origin') || '[]'));
      setHistDestination(JSON.parse(localStorage.getItem('ml_hist_destination') || '[]'));
      setHistPkgType(JSON.parse(localStorage.getItem('ml_hist_pkgtype') || '[]'));
      const rawTpl = localStorage.getItem('ml_pkg_templates') || '[]';
      const tpl: PackageTemplate[] = Array.isArray(JSON.parse(rawTpl)) ? JSON.parse(rawTpl) : [];
      setHistTemplates(tpl);
    } catch {}
  }, []);

  const pushHistory = (key: 'sender' | 'receiver' | 'origin' | 'destination' | 'pkgtype', value?: string) => {
    const v = (value || '').trim();
    if (!v) return;
    const cap = 30;
    if (key === 'sender') {
      const next = [v, ...histSender.filter(x => x !== v)].slice(0, cap);
      setHistSender(next); try { localStorage.setItem('ml_hist_sender', JSON.stringify(next)); } catch {}
    } else if (key === 'receiver') {
      const next = [v, ...histReceiver.filter(x => x !== v)].slice(0, cap);
      setHistReceiver(next); try { localStorage.setItem('ml_hist_receiver', JSON.stringify(next)); } catch {}
    } else if (key === 'origin') {
      const next = [v, ...histOrigin.filter(x => x !== v)].slice(0, cap);
      setHistOrigin(next); try { localStorage.setItem('ml_hist_origin', JSON.stringify(next)); } catch {}
    } else if (key === 'destination') {
      const next = [v, ...histDestination.filter(x => x !== v)].slice(0, cap);
      setHistDestination(next); try { localStorage.setItem('ml_hist_destination', JSON.stringify(next)); } catch {}
    } else if (key === 'pkgtype') {
      const next = [v, ...histPkgType.filter(x => x !== v)].slice(0, cap);
      setHistPkgType(next); try { localStorage.setItem('ml_hist_pkgtype', JSON.stringify(next)); } catch {}
    }
  };

  const pushTemplate = (tpl: PackageTemplate) => {
    try {
      const cap = 30;
      const raw = localStorage.getItem('ml_pkg_templates') || '[]';
      const arr: PackageTemplate[] = Array.isArray(JSON.parse(raw)) ? JSON.parse(raw) : [];
      // 用组合键去重（寄件人+收件人+目的地+类型+重量+尺寸+费用+状态）
      const key = (t: PackageTemplate) => [t.sender||'', t.receiver||'', t.destination||'', t.packageType||'', t.weightKg||0, t.dimensions?.lengthCm||0, t.dimensions?.widthCm||0, t.dimensions?.heightCm||0, t.fee||0, t.status||''].join('|');
      const curKey = key(tpl);
      const merged = [tpl, ...arr.filter(x => key(x) !== curKey)].slice(0, cap);
      localStorage.setItem('ml_pkg_templates', JSON.stringify(merged));
      setHistTemplates(merged);
    } catch {}
  };


  const volumeM3 = (p: PackageItem) => {
    const v = (p.dimensions.lengthCm || 0) * (p.dimensions.widthCm || 0) * (p.dimensions.heightCm || 0);
    return v / 1_000_000; // m^3
  };

  const filtered = useMemo(() => {
    // 服务端已处理 search/status，这里仅做日期范围的前端过滤
    return packages.filter(p => {
      const d = (p.createdAt || '').slice(0,10);
      const matchStart = !startDate || d >= startDate;
      const matchEnd = !endDate || d <= endDate;
      return matchStart && matchEnd;
    });
  }, [packages, startDate, endDate]);

  const totalCount = pkgTotalAll;
  const todayStr = new Date().toISOString().slice(0,10);
  const todayCount = packages.filter(p => (p.createdAt || '').slice(0,10) === todayStr).length;
  const outboundTodayCount = packages.filter(p => (p.createdAt || '').slice(0,10) === todayStr && p.status === '运输中').length;
  const signedTotalCount = packages.filter(p => p.status === '已签收').length;
  const dailySummary = useMemo(() => {
    const map: Record<string, number> = {};
    for (const p of filtered) {
      const d = (p.createdAt || '').slice(0,10);
      if (!d) continue;
      map[d] = (map[d] || 0) + 1;
    }
    return Object.entries(map).sort((a,b)=> a[0] < b[0] ? 1 : -1);
  }, [filtered]);

  const createEmpty = (): PackageItem => {
    const today = new Date();
    const yyyyMmDd = today.toISOString().slice(0,10);
    return {
      id: '',
      trackingNumber: '',
      sender: '',
      receiver: '',
      origin: '',
      destination: '',
      packageType: '',
      weightKg: 0,
      dimensions: { lengthCm: 0, widthCm: 0, heightCm: 0 },
      fee: 0,
      status: '已下单',
      createdAt: yyyyMmDd,
      note: ''
    };
  };

  // 出库/签收时间未单独存库，“当天出库”按创建日期为今日且状态为“运输中”近似统计；若需更精准，可在库里增加 outbound_at 字段。

  const reload = async () => {
    try {
      const qs = new URLSearchParams({
        page: String(pkgPage),
        pageSize: String(pkgPageSize),
        status: statusFilter === 'all' ? '' : String(statusFilter),
        search: search.trim(),
      });
      const r = await fetchWithRetry('/.netlify/functions/packages-manage?' + qs.toString(), { headers: user ? ({ 'x-ml-actor': user.username, 'x-ml-role': user.role } as any) : undefined });
      const j = await r.json();
      setPackages(j.items || []);
      setPkgTotal(j.total || 0);
      try {
        const rAll = await fetchWithRetry('/.netlify/functions/packages-manage?page=1&pageSize=1', { headers: user ? ({ 'x-ml-actor': user.username, 'x-ml-role': user.role } as any) : undefined });
        const jAll = await rAll.json();
        setPkgTotalAll(jAll.total || 0);
      } catch {}
    } catch {}
  };

  const handleSave = async () => {
    if (!draft || !user) return;
    if (!draft.trackingNumber.trim() || !draft.sender.trim() || !draft.receiver.trim()) return;
    const isNew = !draft.id;
    const withId: PackageItem = isNew ? { ...draft, id: Date.now().toString() } : draft;
    try {
      if (isNew) {
        const res = await fetchWithRetry('/.netlify/functions/packages-manage', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username, 'x-ml-role': user.role }, body: JSON.stringify(withId) });
        if (!res.ok) {
          const j = await res.json().catch(()=>({}));
          if (res.status === 409) {
            setToast({ open: true, text: j.message || '单号已存在，请更换单号', severity: 'error' });
            return; // 不做本地新增
          }
          throw new Error('api failed');
        }
      } else {
        const mappedStatus: PackageStatus = (String(withId.status) === '入库') ? '已入库' : withId.status;
        const normalized = { ...withId, status: mappedStatus };
        const res = await fetchWithRetry('/.netlify/functions/packages-manage', { method: 'PATCH', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username, 'x-ml-role': user.role }, body: JSON.stringify(normalized) });
        if (!res.ok) {
          const j = await res.json().catch(()=>({}));
          if (res.status === 409) { setToast({ open: true, text: j.message || '单号已存在，请更换单号', severity: 'error' }); return; }
          throw new Error('api failed');
        }
      }
      await reload();
      setToast({ open: true, text: '已保存至服务器', severity: 'success' });
    } catch {
      if (isNew) setPackages([withId, ...packages]); else setPackages(packages.map(p => p.id === withId.id ? withId : p));
      setToast({ open: true, text: '服务器不可用，已临时保存到本地', severity: 'warning' });
    }
    // 保存模板（无论在线/离线都记录）
    pushTemplate({
      sender: withId.sender,
      receiver: withId.receiver,
      origin: withId.origin,
      destination: withId.destination,
      packageType: withId.packageType,
      weightKg: withId.weightKg,
      dimensions: withId.dimensions,
      fee: withId.fee,
      status: withId.status,
    });
    // 写入历史（即便离线也记录）
    pushHistory('sender', withId.sender);
    pushHistory('receiver', withId.receiver);
    pushHistory('origin', withId.origin);
    pushHistory('destination', withId.destination);
    pushHistory('pkgtype', withId.packageType);
    setOpenDialog(false);
    setDraft(null);
    setSearch('');
    setStatusFilter('all');
  };

  const handleInbound = async (id: string) => {
    if (!user) return;
    try {
      const res = await fetchWithRetry('/.netlify/functions/packages-manage', { method: 'PATCH', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username, 'x-ml-role': user.role }, body: JSON.stringify({ id, status: '已入库' }) });
      if (!res.ok) {
        if (res.status === 403) { setToast({ open: true, text: '无权限执行入库操作', severity: 'error' }); return; }
        throw new Error('api failed');
      }
      await reload();
    } catch {
      if (canModify) {
      setPackages(prev => prev.map(p => p.id === id ? { ...p, status: '已入库' } : p));
      setToast({ open: true, text: '服务器不可用，状态已本地更新', severity: 'warning' });
      }
    }
  };

  const handleOutbound = (pkg: PackageItem) => {
    if (!user) return;
    setOutboundPkg(pkg);
    setOutboundFreight('');
    setOutboundOpen(true);
  };

  // 确认出库：创建/复用运单，并把包裹加入运单（后端会把状态置为“运输中”）
  const confirmOutbound = async () => {
    if (!user || !outboundPkg) return;
    const freightNo = outboundFreight.trim();
    if (!freightNo) { setToast({ open: true, text: '请输入货运号', severity: 'warning' }); return; }
    setOutboundBusy(true);
    try {
      // 1) 查询是否已存在该货运号
      let shipmentId: string | null = null;
      try {
        const qs = new URLSearchParams({ page: '1', pageSize: '1', search: freightNo });
        const r = await fetchWithRetry('/.netlify/functions/transport-manage?' + qs.toString());
      const j = await r.json();
        const hit = (j.items || []).find((s: any) => String(s.freightNo) === freightNo);
        if (hit) shipmentId = hit.id;
      } catch {}

      // 2) 不存在则创建
      if (!shipmentId) {
        const rCreate = await fetchWithRetry('/.netlify/functions/transport-manage', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username, 'x-ml-role': user.role },
          body: JSON.stringify({ op: 'create', freightNo })
        });
        const jc = await rCreate.json().catch(()=>({}));
        if (!rCreate.ok && !jc?.item?.id) {
          throw new Error(jc?.message || '创建运单失败');
        }
        shipmentId = jc?.item?.id || null;
      }

      if (!shipmentId) throw new Error('无法获取运单ID');

      // 3) 绑定包裹到运单，同时把包裹设为运输中
      const rBind = await fetchWithRetry('/.netlify/functions/transport-manage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username, 'x-ml-role': user.role },
        body: JSON.stringify({ op: 'addPackages', shipmentId, trackingNumbers: [outboundPkg.trackingNumber] })
      });
      if (!rBind.ok) {
        const jb = await rBind.json().catch(()=>({}));
        throw new Error(jb?.message || '装车失败');
      }

      await reload();
      setToast({ open: true, text: '已出库并加入运输系统', severity: 'success' });
      setOutboundOpen(false);
      setOutboundPkg(null);
      pushOutboundFreightHistory(freightNo);
      setOutboundFreight('');
    } catch (e: any) {
      setToast({ open: true, text: e?.message || '出库失败', severity: 'error' });
    } finally {
      setOutboundBusy(false);
    }
  };

  const handleMarkInTransit = async (id: string) => {
    const pkg = packages.find(p => p.id === id);
    if (pkg) handleOutbound(pkg);
  };

  const handleMarkDelivered = async (id: string) => {
    const pkg = packages.find(p => p.id === id);
    if (pkg) {
      openSignProofDialog(pkg);
    }
  };

  const handleEdit = (item: PackageItem) => {
    setDraft(item);
    setOpenDialog(true);
  };

  const openSignProofDialog = (item: PackageItem) => {
    setSignProofItem(item);
    setSignPhotos([]);
    setSignSignature('');
    setCourierName('');
    setCourierPhone('');
    setCourierId('');
    setSignNote('');
    setSignProofOpen(true);
  };

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      const newPhotos: string[] = [];
      Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onload = (e) => {
          if (e.target?.result) {
            newPhotos.push(e.target.result as string);
            setSignPhotos(prev => [...prev, ...newPhotos]);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removePhoto = (index: number) => {
    setSignPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const confirmSignProof = async () => {
    if (!user || !signProofItem) return;
    if (signPhotos.length === 0) { alert('请至少上传一张签收证明照片'); return; }
    
    setSignBusy(true);
    try {
      const r = await fetchWithRetry('/.netlify/functions/packages-manage', { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username }, 
        body: JSON.stringify({ 
          op: 'sign',
          packageId: signProofItem.id,
          photos: signPhotos,
          signature: signSignature || null,
          courierInfo: {
            name: courierName.trim() || null,
            phone: courierPhone.trim() || null,
            id: courierId.trim() || null
          },
          note: signNote.trim() || null,
          destination: signProofItem.destination || null
        }) 
      });
      
      if (!r.ok) { 
        try { const j = await r.json(); alert(j.message || '签收失败'); } catch {} 
        return; 
      }
      
      alert('签收证明已保存，包裹状态已更新为"已签收"');
      setSignProofOpen(false);
      setSignProofItem(null);
      // 刷新列表
      await reload();
    } catch {
      alert('签收失败');
    } finally {
      setSignBusy(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!user) return;
    const pkg = packages.find(p => p.id === id);
    // 确认删除，避免误操作
    if (!(window as any).confirm(`确定要删除该包裹${pkg?.trackingNumber ? `（单号：${pkg.trackingNumber}）` : ''}吗？\n此操作会同时删除关联的财务记录，且不可恢复。`)) return;
    try {
      const res = await fetchWithRetry('/.netlify/functions/packages-manage', { method: 'DELETE', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username, 'x-ml-role': user.role }, body: JSON.stringify({ id, trackingNumber: pkg?.trackingNumber }) });
      if (!res.ok) {
        if (res.status === 403) { setToast({ open: true, text: '无权限删除包裹', severity: 'error' }); return; }
        throw new Error('api failed');
      }
      // 保障：删除成功后再强制刷新财务（以便管理端页签打开时能看到减少）
      try { await fetchWithRetry('/.netlify/functions/finances-manage?search=' + encodeURIComponent(pkg?.trackingNumber || '')); } catch {}
      await reload();
      setToast({ open: true, text: '包裹已删除', severity: 'success' });
    } catch {
      if (canModify) {
      setPackages(prev => prev.filter(p => p.id !== id));
      setToast({ open: true, text: '服务器不可用，已本地删除', severity: 'warning' });
      }
    }
  };

  const totalPages = Math.max(1, Math.ceil((pkgTotal || 0) / pkgPageSize));
  useEffect(() => { setPkgPage(1); }, [search, statusFilter]);

  if (!user) return null;
  const role = (user.role || '').trim().toLowerCase();

  return (
    <Box sx={{ minHeight: '100vh', backgroundColor: 'grey.50' }}>
      <AppBar position="static" sx={{ backgroundColor: 'white', color: 'text.primary' }}>
        <Toolbar>
          <Box sx={{ flexGrow: 1 }} />
          <Box sx={{ display: 'flex', gap: 1, mr: 2 }}>
            <Button size="small" variant="contained" onClick={() => navigate('/admin/inventory')}>包裹管理</Button>
            {['accountant','manager','master'].includes(role) && <Button size="small" onClick={() => navigate('/admin/finance')}>财务系统</Button>}
            <Button size="small" onClick={() => navigate('/admin/dashboard')}>控制台</Button>
            <Button size="small" onClick={() => navigate('/admin/transport')}>运输系统</Button>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, ml: 2 }}>
            <Typography variant="body2" color="text.secondary">欢迎，{user.username} ({user.role})</Typography>
            <Person />
          </Box>
        </Toolbar>
      </AppBar>

      <Container maxWidth="lg" sx={{ py: 4, pb: { xs: 10, md: 4 } }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
          <Typography variant="h6" sx={{ fontWeight: 600 }}>包裹管理</Typography>
          <Box sx={{ display: 'flex', gap: 1 }}>
            {!isMobile && (
              <>
                <Button variant="contained" onClick={()=>{ setDraft(createEmpty()); setOpenDialog(true); }}>新增包裹</Button>
                <Button variant="outlined" onClick={()=> navigate('/admin/scan')}>扫码流转</Button>
              </>
            )}
            {isMobile && (
              <Button variant="outlined" onClick={()=> setMobileFilterOpen(true)}>筛选</Button>
            )}
          </Box>
        </Box>

        <Grid container spacing={3} sx={{ mb: 2 }}>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <Typography variant="body2" color="text.secondary">包裹总量</Typography>
                <Typography variant="h5" sx={{ fontWeight: 700 }}>{totalCount.toLocaleString()} 件</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <Typography variant="body2" color="text.secondary">今日新增</Typography>
                <Typography variant="h5" sx={{ fontWeight: 700, color: 'primary.main' }}>{todayCount.toLocaleString()} 件</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <Typography variant="body2" color="text.secondary">今日出库</Typography>
                <Typography variant="h5" sx={{ fontWeight: 700, color: 'warning.main' }}>{outboundTodayCount.toLocaleString()} 件</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <Typography variant="body2" color="text.secondary">签收</Typography>
                <Typography variant="h5" sx={{ fontWeight: 700, color: 'success.main' }}>{signedTotalCount.toLocaleString()} 件</Typography>
              </CardContent>
            </Card>
          </Grid>
          {/* 财务一致性提示 */}
          {reconcileHint && (reconcileHint.missing > 0 || reconcileHint.extra > 0) && (
            <Grid item xs={12}>
              <Card sx={{ borderLeft: '4px solid', borderLeftColor: 'warning.main' }}>
                <CardContent sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2 }}>
                  <Box>
                    <Typography variant="subtitle2" sx={{ mb: 0.5 }}>财务一致性提醒</Typography>
                    <Typography variant="body2" color="text.secondary">缺失收入 {reconcileHint.missing} 条，疑似多余 {reconcileHint.extra} 条</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', gap: 1 }}>
                    <Button size="small" variant="outlined" disabled={reconcileBusy} onClick={async ()=>{
                      if (!user) return;
                      setReconcileBusy(true);
                      try {
                        const r = await fetchWithRetry('/.netlify/functions/reconcile', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username }, body: JSON.stringify({ markTransit: true, fixAmounts: true }) });
                        if (!r.ok) { const j = await r.json().catch(()=>({})); throw new Error(j?.message || '对齐失败'); }
                        setToast({ open: true, text: '已对齐财务（状态与金额）', severity: 'success' });
                        // 刷新提示
                        try {
                          const r2 = await fetchWithRetry('/.netlify/functions/reconcile', { headers: { 'x-ml-actor': user.username } });
                          const j2 = await r2.json();
                          const missing = Array.isArray(j2.missingFinance) ? j2.missingFinance.length : 0;
                          const extra = Array.isArray(j2.extraFinance) ? j2.extraFinance.length : 0;
                          setReconcileHint({ missing, extra });
                        } catch {}
                      } catch (e:any) {
                        setToast({ open: true, text: e?.message || '对齐失败', severity: 'error' });
                      } finally { setReconcileBusy(false); }
                    }}>对齐财务</Button>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          )}
        </Grid>

        {!isMobile && (
          <Paper sx={{ p: 2, mb: 2 }}>
            <Grid container spacing={2} alignItems="center">
              <Grid item xs={12} md={3}>
                <TextField fullWidth size="small" placeholder="搜索单号/寄件人/收件人" value={search} onChange={(e)=>setSearch(e.target.value)} />
              </Grid>
              <Grid item xs={12} md={3}>
                <TextField fullWidth size="small" select label="状态" value={statusFilter} onChange={(e)=>setStatusFilter(e.target.value as any)}>
                  <MenuItem value="all">全部</MenuItem>
                  <MenuItem value="已下单">已下单</MenuItem>
                  <MenuItem value="已入库">已入库</MenuItem>
                  <MenuItem value="运输中">运输</MenuItem>
                  <MenuItem value="已签收">签收</MenuItem>
                  <MenuItem value="已取消">已取消</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12} md={3}>
                <TextField fullWidth size="small" type="date" label="开始日期" InputLabelProps={{ shrink: true }} value={startDate} onChange={(e)=>setStartDate(e.target.value)} />
              </Grid>
              <Grid item xs={12} md={3}>
                <TextField fullWidth size="small" type="date" label="结束日期" InputLabelProps={{ shrink: true }} value={endDate} onChange={(e)=>setEndDate(e.target.value)} />
              </Grid>
              <Grid item xs={12} md={3}>
                <Button variant="text" onClick={()=>{ setStartDate(''); setEndDate(''); setStatusFilter('all'); setSearch(''); }}>重置</Button>
              </Grid>
            </Grid>
          </Paper>
        )}

        {isMobile ? (
          <Box>
            {loading && (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, mb: 2 }}>
                {Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} variant="rounded" height={88} />
                ))}
              </Box>
            )}
            {!loading && filtered.length === 0 && (
              <Paper sx={{ p: 3, textAlign: 'center', color: 'text.secondary' }}>暂无包裹</Paper>
            )}
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              {filtered.map((p) => (
                <SwipeableItem key={p.id || p.trackingNumber} onLeftAction={()=>handleDelete(p.id)} leftLabel="删除" leftColor="error" onRightAction={()=>{ setDraft({ ...p }); setOpenDialog(true); }} rightLabel="编辑" rightColor="primary" height={96}>
                <Card sx={{ p: 1.5 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <Typography sx={{ fontWeight: 700 }}>{p.trackingNumber}</Typography>
                    <Chip size="small" label={p.status} color={p.status==='已签收' ? 'success' : p.status==='运输中' ? 'warning' : p.status==='已入库' ? 'info' : 'default'} />
                  </Box>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: .5 }}>{p.sender} → {p.destination || p.receiver || '—'}</Typography>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 1 }}>
                    <Typography variant="body2" sx={{ color: 'text.secondary' }}>重量 {Number(p.weightKg||0).toFixed(1)}kg · 费用 <Box component="span" sx={{ fontWeight: 700, color: 'text.primary' }}>{Number(p.fee||0).toLocaleString()}</Box> 缅币</Typography>
                    <Box sx={{ display: 'flex', gap: .5 }}>
                      <Button size="small" onClick={()=>handleInbound(p.id)} disabled={!canModify}>入库</Button>
                      <Button size="small" onClick={()=>handleOutbound(p)} disabled={!canModify}>出库</Button>
                      <Button size="small" onClick={()=>handleMarkDelivered(p.id)} disabled={!canModify}>签收</Button>
                      <IconButton size="small" onClick={()=>{ setDraft({ ...p }); setOpenDialog(true); }} disabled={!canModify}><Edit fontSize="small" /></IconButton>
                      <IconButton size="small" color="error" onClick={()=>handleDelete(p.id)} disabled={!canModify}><Delete fontSize="small" /></IconButton>
                    </Box>
                  </Box>
                </Card>
                </SwipeableItem>
              ))}
            </Box>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', p: 2 }}>
              <Pagination count={totalPages} page={pkgPage} onChange={(_, p)=>setPkgPage(p)} size="small" color="primary" />
            </Box>
          </Box>
        ) : (
          <Paper>
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow sx={{ backgroundColor: 'grey.50' }}>
                    <TableCell width={60} align="center">序号</TableCell>
                    <TableCell>单号</TableCell>
                    <TableCell>寄件人</TableCell>
                    <TableCell>收件人</TableCell>
                    <TableCell>目的地</TableCell>
                    <TableCell>状态</TableCell>
                    <TableCell align="right">重量(kg)</TableCell>
                    <TableCell align="right">体积(m³)</TableCell>
                    <TableCell align="right">费用(缅币)</TableCell>
                    <TableCell>操作</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filtered.map((p, idx) => (
                    <TableRow key={p.id || p.trackingNumber} hover>
                      <TableCell align="center">{idx + 1}</TableCell>
                      <TableCell>{p.trackingNumber}</TableCell>
                      <TableCell>{p.sender}</TableCell>
                      <TableCell>{p.receiver}</TableCell>
                      <TableCell>{p.destination || '—'}</TableCell>
                      <TableCell>
                        <Chip size="small" label={p.status} color={p.status==='已签收' ? 'success' : p.status==='运输中' ? 'warning' : p.status==='已入库' ? 'info' : 'default'} />
                      </TableCell>
                      <TableCell align="right">{Number(p.weightKg || 0).toFixed(2)}</TableCell>
                      <TableCell align="right">{volumeM3(p).toFixed(3)}</TableCell>
                      <TableCell align="right">{Number(p.fee || 0).toLocaleString()}</TableCell>
                      <TableCell>
                        <Button size="small" onClick={()=>handleInbound(p.id)} disabled={!canModify}>入库</Button>
                        <Button size="small" onClick={()=>handleOutbound(p)} disabled={!canModify}>出库</Button>
                        <Button size="small" onClick={()=>handleMarkDelivered(p.id)} disabled={!canModify}>签收</Button>
                        <IconButton size="small" onClick={()=>{ setDraft({ ...p }); setOpenDialog(true); }} disabled={!canModify}><Edit fontSize="small" /></IconButton>
                        <IconButton size="small" color="error" onClick={()=>handleDelete(p.id)} disabled={!canModify}><Delete fontSize="small" /></IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', p: 2 }}>
              <Pagination count={totalPages} page={pkgPage} onChange={(_, p)=>setPkgPage(p)} size="small" color="primary" />
            </Box>
          </Paper>
        )}

        <Typography variant="subtitle1" sx={{ mt: 3, mb: 1, fontWeight: 600 }}>按日汇总</Typography>
        <Paper>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow sx={{ backgroundColor: 'grey.50' }}>
                  <TableCell>日期</TableCell>
                  <TableCell align="right">当日包裹数</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {dailySummary.map(([date, count]) => (
                  <TableRow key={date}>
                    <TableCell>{date}</TableCell>
                    <TableCell align="right">{count.toLocaleString()}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      </Container>

      {/* 移动端筛选抽屉 */}
      <Drawer anchor="bottom" open={mobileFilterOpen} onClose={()=>setMobileFilterOpen(false)} sx={{ display: { xs: 'block', md: 'none' }}}>
        <Box sx={{ p: 2 }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>筛选</Typography>
          <Divider sx={{ mb: 2 }} />
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            <TextField fullWidth size="small" placeholder="搜索单号/寄件人/收件人" value={search} onChange={(e)=>setSearch(e.target.value)} />
            <TextField fullWidth size="small" select label="状态" value={statusFilter} onChange={(e)=>setStatusFilter(e.target.value as any)}>
              <MenuItem value="all">全部</MenuItem>
              <MenuItem value="已下单">已下单</MenuItem>
              <MenuItem value="已入库">已入库</MenuItem>
              <MenuItem value="运输中">运输</MenuItem>
              <MenuItem value="已签收">签收</MenuItem>
              <MenuItem value="已取消">已取消</MenuItem>
            </TextField>
            <TextField fullWidth size="small" type="date" label="开始日期" InputLabelProps={{ shrink: true }} value={startDate} onChange={(e)=>setStartDate(e.target.value)} />
            <TextField fullWidth size="small" type="date" label="结束日期" InputLabelProps={{ shrink: true }} value={endDate} onChange={(e)=>setEndDate(e.target.value)} />
            <Box sx={{ display: 'flex', gap: 1, mt: .5 }}>
              <Button fullWidth variant="text" onClick={()=>{ setStartDate(''); setEndDate(''); setStatusFilter('all'); setSearch(''); }}>重置</Button>
              <Button fullWidth variant="contained" onClick={()=>setMobileFilterOpen(false)}>完成</Button>
            </Box>
          </Box>
        </Box>
      </Drawer>

      {/* 移动端底部主操作条 */}
      <Paper sx={{ position: 'fixed', bottom: 0, left: 0, right: 0, display: { xs: 'flex', md: 'none' }, gap: 1, p: 1, borderTopLeftRadius: 12, borderTopRightRadius: 12 }} elevation={10}>
        <Button fullWidth variant="outlined" onClick={()=>setMobileFilterOpen(true)}>筛选</Button>
        <Button fullWidth variant="outlined" onClick={()=> navigate('/admin/scan')}>扫码</Button>
        <Button fullWidth variant="contained" onClick={()=>{ setDraft(createEmpty()); setOpenDialog(true); }} disabled={!canModify}>新增</Button>
      </Paper>

      <Dialog open={openDialog} onClose={()=>setOpenDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle>{draft?.id ? '编辑包裹' : '新增包裹'}</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            {/* 历史模板：一键套用 */}
            <Grid item xs={12}>
              <Autocomplete
                options={histTemplates}
                getOptionLabel={(t)=>{
                  const a = t.sender || '';
                  const b = t.receiver || '';
                  const d = t.destination || '';
                  const pt = t.packageType || '';
                  return `${a ? '寄: '+a : ''}${a && b ? ' → ' : ''}${b ? '收: '+b : ''}${d ? ' ・目的地: '+d : ''}${pt ? ' ・类型: '+pt : ''}`.trim() || '模板';
                }}
                onChange={(_, value)=>{
                  if (!draft || !value) return;
                  setDraft({
                    ...draft,
                    sender: value.sender || '',
                    receiver: value.receiver || '',
                    origin: value.origin || '',
                    destination: value.destination || '',
                    packageType: value.packageType || '',
                    weightKg: Number(value.weightKg || 0),
                    dimensions: {
                      lengthCm: Number(value.dimensions?.lengthCm || 0),
                      widthCm: Number(value.dimensions?.widthCm || 0),
                      heightCm: Number(value.dimensions?.heightCm || 0),
                    },
                    fee: Number(value.fee || 0),
                    status: (value.status || draft.status) as PackageStatus,
                  });
                }}
                renderInput={(params)=>(<TextField {...params} fullWidth label="历史模板（选择后自动填充）" placeholder="从历史记录一键套用寄件人/收件人/目的地等" />)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField fullWidth label="运单号" value={draft?.trackingNumber || ''} onChange={(e)=>draft && setDraft({ ...draft, trackingNumber: e.target.value })} />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Autocomplete freeSolo options={histPkgType}
                inputValue={draft?.packageType || ''}
                onInputChange={(_, v)=> draft && setDraft({ ...draft, packageType: v })}
                renderInput={(params)=>(<TextField {...params} fullWidth label="包裹类型" />)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Autocomplete freeSolo options={histSender}
                inputValue={draft?.sender || ''}
                onInputChange={(_, v)=> draft && setDraft({ ...draft, sender: v })}
                renderInput={(params)=>(<TextField {...params} fullWidth label="寄件人" />)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Autocomplete freeSolo options={histReceiver}
                inputValue={draft?.receiver || ''}
                onInputChange={(_, v)=> draft && setDraft({ ...draft, receiver: v })}
                renderInput={(params)=>(<TextField {...params} fullWidth label="收件人" />)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Autocomplete freeSolo options={histOrigin}
                inputValue={draft?.origin || ''}
                onInputChange={(_, v)=> draft && setDraft({ ...draft, origin: v })}
                renderInput={(params)=>(<TextField {...params} fullWidth label="始发地" />)}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Autocomplete freeSolo options={histDestination}
                inputValue={draft?.destination || ''}
                onInputChange={(_, v)=> draft && setDraft({ ...draft, destination: v })}
                renderInput={(params)=>(<TextField {...params} fullWidth label="目的地" />)}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField fullWidth label="重量(kg)" type="number" value={draft?.weightKg ?? 0} onChange={(e)=>draft && setDraft({ ...draft, weightKg: Number(e.target.value) })} />
            </Grid>
            <Grid item xs={12} sm={8}>
              <Grid container spacing={2}>
                <Grid item xs={4}>
                  <TextField fullWidth label="长(cm)" type="number" value={draft?.dimensions.lengthCm ?? 0} onChange={(e)=>draft && setDraft({ ...draft, dimensions: { ...draft.dimensions, lengthCm: Number(e.target.value) } })} />
                </Grid>
                <Grid item xs={4}>
                  <TextField fullWidth label="宽(cm)" type="number" value={draft?.dimensions.widthCm ?? 0} onChange={(e)=>draft && setDraft({ ...draft, dimensions: { ...draft.dimensions, widthCm: Number(e.target.value) } })} />
                </Grid>
                <Grid item xs={4}>
                  <TextField fullWidth label="高(cm)" type="number" value={draft?.dimensions.heightCm ?? 0} onChange={(e)=>draft && setDraft({ ...draft, dimensions: { ...draft.dimensions, heightCm: Number(e.target.value) } })} />
                </Grid>
              </Grid>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField fullWidth label="费用(缅币)" type="number" value={draft?.fee ?? 0} onChange={(e)=>draft && setDraft({ ...draft, fee: Number(e.target.value) })} />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField select fullWidth label="状态" value={draft?.status || '已下单'} onChange={(e)=>draft && setDraft({ ...draft, status: e.target.value as PackageStatus })}>
                {(['已下单','已入库','运输中','已签收','已取消'] as PackageStatus[]).map(s => (
                  <MenuItem key={s} value={s}>{s}</MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                type="date"
                label="创建日期"
                InputLabelProps={{ shrink: true }}
                value={draft?.createdAt || ''}
                onChange={(e)=>{
                  if (!draft) return;
                  const raw = e.target.value;
                  let v = raw;
                  // 允许输入 08/13/2025 或 2025/08/13，并自动转换为 YYYY-MM-DD
                  const mmddyyyy = raw.match(/^\s*(\d{1,2})\/(\d{1,2})\/(\d{4})\s*$/);
                  const yyyymmdd2 = raw.match(/^\s*(\d{4})\/(\d{1,2})\/(\d{1,2})\s*$/);
                  const pad = (n: string) => n.padStart(2, '0');
                  if (mmddyyyy) v = `${mmddyyyy[3]}-${pad(mmddyyyy[1])}-${pad(mmddyyyy[2])}`;
                  else if (yyyymmdd2) v = `${yyyymmdd2[1]}-${pad(yyyymmdd2[2])}-${pad(yyyymmdd2[3])}`;
                  setDraft({ ...draft, createdAt: v });
                }}
                placeholder="YYYY-MM-DD"
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField fullWidth label="备注" value={draft?.note || ''} onChange={(e)=>draft && setDraft({ ...draft, note: e.target.value })} />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={()=>{ setOpenDialog(false); setDraft(null); }}>取消</Button>
          <Button variant="contained" onClick={handleSave}>保存</Button>
        </DialogActions>
      </Dialog>

      {/* 出库 -> 询问货运号 */}
      <Dialog open={outboundOpen} onClose={()=>!outboundBusy && setOutboundOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle>出库并加入运输系统</DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Autocomplete freeSolo options={outboundFreightOptions}
              inputValue={outboundFreight}
              onInputChange={(_, v)=>setOutboundFreight(v)}
              renderInput={(params)=>(<TextField {...params} label="货运号" placeholder="例如: ML-2024-0001" fullWidth />)}
            />
            <Typography variant="body2" color="text.secondary">包裹：{outboundPkg?.trackingNumber || ''}</Typography>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button disabled={outboundBusy} onClick={()=>setOutboundOpen(false)}>取消</Button>
          <Button variant="contained" disabled={outboundBusy} onClick={confirmOutbound}>{outboundBusy ? '处理中...' : '确认出库'}</Button>
        </DialogActions>
      </Dialog>

      {/* 签收证明弹窗 */}
      <Dialog open={signProofOpen} onClose={()=>!signBusy && setSignProofOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>签收证明 - {signProofItem?.trackingNumber}</DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 1, display: 'flex', flexDirection: 'column', gap: 3 }}>
            {/* 照片上传区域 */}
            <Box>
              <Typography variant="h6" gutterBottom>📸 签收证明照片 *</Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <Button variant="outlined" component="label" startIcon={<Edit />}>
                  上传照片
                  <input type="file" multiple accept="image/*" onChange={handlePhotoUpload} style={{ display: 'none' }} />
                </Button>
                {signPhotos.length > 0 && (
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                    {signPhotos.map((photo, index) => (
                      <Box key={index} sx={{ position: 'relative' }}>
                        <img src={photo} alt={`证明照片${index + 1}`} style={{ width: 120, height: 120, objectFit: 'cover', borderRadius: 8 }} />
                        <IconButton 
                          size="small" 
                          sx={{ position: 'absolute', top: -8, right: -8, backgroundColor: 'error.main', color: 'white' }}
                          onClick={() => removePhoto(index)}
                        >
                          <Delete fontSize="small" />
                        </IconButton>
                      </Box>
                    ))}
                  </Box>
                )}
                <Typography variant="body2" color="text.secondary">
                  请上传包裹签收时的照片，至少1张，建议包含包裹、收件人、签收环境等
                </Typography>
              </Box>
            </Box>

            {/* 快递员信息 */}
            <Box>
              <Typography variant="h6" gutterBottom>🚚 快递员信息</Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={4}>
                  <TextField 
                    fullWidth 
                    label="快递员姓名" 
                    placeholder="可选"
                    value={courierName}
                    onChange={(e) => setCourierName(e.target.value)}
                  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <TextField 
                    fullWidth 
                    label="联系电话" 
                    placeholder="可选"
                    value={courierPhone}
                    onChange={(e) => setCourierPhone(e.target.value)}
                  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <TextField 
                    fullWidth 
                    label="工号/ID" 
                    placeholder="可选"
                    value={courierId}
                    onChange={(e) => setCourierId(e.target.value)}
                  />
                </Grid>
              </Grid>
            </Box>

            {/* 签收备注 */}
            <Box>
              <Typography variant="h6" gutterBottom>📝 签收备注</Typography>
              <TextField 
                fullWidth 
                label="备注" 
                placeholder="签收相关说明，如签收时间、特殊要求等"
                value={signNote}
                onChange={(e) => setSignNote(e.target.value)}
                multiline
                minRows={3}
              />
            </Box>

            <Typography variant="body2" color="text.secondary" sx={{ p: 2, backgroundColor: 'grey.50', borderRadius: 1 }}>
              💡 签收证明将保存到系统，包裹状态将自动更新为"已签收"。照片将作为签收凭证永久保存。
            </Typography>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button disabled={signBusy} onClick={() => setSignProofOpen(false)}>取消</Button>
          <Button variant="contained" disabled={signBusy} onClick={confirmSignProof}>
            {signBusy ? '保存中...' : '确认签收'}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar open={toast.open} autoHideDuration={3000} onClose={()=>setToast({ ...toast, open: false })} anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}>
        <Alert onClose={()=>setToast({ ...toast, open: false })} severity={toast.severity} sx={{ width: '100%' }}>
          {toast.text}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default AdminInventory;


