import React, { useEffect, useMemo, useState } from 'react';
import { AppBar, Toolbar, Typography, Box, Container, Button, Table, TableHead, TableRow, TableCell, TableBody, TableContainer, Paper, Dialog, DialogTitle, DialogContent, DialogActions, Grid, TextField, IconButton, Chip, Pagination, CircularProgress, Autocomplete, Skeleton, Card, Drawer, Divider } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import SwipeableItem from '../components/SwipeableItem';
import { LocalShipping, Person, Edit, Delete, Add } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { getAdminSession } from '../utils/auth';
import { fetchWithRetry } from '../utils/backend';

type ShipmentItem = {
  id: string;
  freightNo: string;
  vehicleNo?: string | null;
  departDate?: string | null; // YYYY-MM-DD
  destination?: string | null;
  note?: string | null;
  createdBy?: string;
  packageCount: number;
};

const AdminTransport: React.FC = () => {
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [user, setUser] = useState<{ username: string; role: string; loginTime: string } | null>(null);
  const [items, setItems] = useState<ShipmentItem[]>([]);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [openEdit, setOpenEdit] = useState(false);
  const [draft, setDraft] = useState<ShipmentItem | null>(null);
  const [openAddPkgs, setOpenAddPkgs] = useState(false);
  const [trackingInput, setTrackingInput] = useState('');
  // 运单历史联想
  const [histFreight, setHistFreight] = useState<string[]>([]);
  const [histVehicle, setHistVehicle] = useState<string[]>([]);
  // 查看某运单下的包裹
  const [openPkgList, setOpenPkgList] = useState(false);
  const [pkgLoading, setPkgLoading] = useState(false);
  const [pkgShipmentTitle, setPkgShipmentTitle] = useState('');
  const [pkgItems, setPkgItems] = useState<Array<{ tracking_no: string; sender?: string; receiver?: string }>>([]);
  const [pkgShipmentId, setPkgShipmentId] = useState<string>('');
  const [pkgAddInput, setPkgAddInput] = useState('');
  const [pkgFilter, setPkgFilter] = useState('');
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);
  // 异常核对（运输中但未装车）
  const [diagOpen, setDiagOpen] = useState(false);
  const [diagLoading, setDiagLoading] = useState(false);
  const [diagMissing, setDiagMissing] = useState<string[]>([]);
  const [diagFreightNo, setDiagFreightNo] = useState('');
  const [diagBusy, setDiagBusy] = useState(false);
  // 中转相关
  const [transitShipment, setTransitShipment] = useState<ShipmentItem | null>(null);
  const [transitLocation, setTransitLocation] = useState('');
  const [nextFreightNo, setNextFreightNo] = useState('');
  const [transitNote, setTransitNote] = useState('');
  const [transitOpen, setTransitOpen] = useState(false);
  const [transitBusy, setTransitBusy] = useState(false);

  const filteredPkgItems = useMemo(() => {
    const keyword = (pkgFilter || '').trim().toLowerCase();
    if (!keyword) return pkgItems;
    return pkgItems.filter(p => (p.tracking_no || '').toLowerCase().includes(keyword));
  }, [pkgItems, pkgFilter]);

  const copyAllTracking = async () => {
    try {
      const text = filteredPkgItems.map(p => p.tracking_no).join('\n');
      await navigator.clipboard.writeText(text);
    } catch {}
  };

  const reloadShipmentsList = async () => {
    if (!user) return;
    setLoading(true);
    const qs = new URLSearchParams({ page: String(page), pageSize: String(pageSize), search });
    const r2 = await fetchWithRetry('/.netlify/functions/transport-manage?' + qs.toString(), { headers: { 'x-ml-actor': user.username } });
    const j2 = await r2.json();
    setItems(j2.items || []);
    setTotal(j2.total || 0);
    setLoading(false);
  };

  useEffect(() => {
    const sess = getAdminSession();
    if (!sess) { navigate('/admin/login'); return; }
    const u = { username: sess.username, role: sess.role, loginTime: sess.loginTime };
    setUser(u);
    (async () => {
      setLoading(true);
      try {
        const qs = new URLSearchParams({ page: String(page), pageSize: String(pageSize), search });
        const r = await fetchWithRetry('/.netlify/functions/transport-manage?' + qs.toString(), { headers: { 'x-ml-actor': u.username } });
        const j = await r.json();
        setItems(j.items || []);
        setTotal(j.total || 0);
      } catch {
        // 保持会话不跳走，显示为空列表
        setItems([]);
        setTotal(0);
      } finally {
        setLoading(false);
      }
    })();
    try {
      setHistFreight(JSON.parse(localStorage.getItem('ml_hist_freight') || '[]'));
      setHistVehicle(JSON.parse(localStorage.getItem('ml_hist_vehicle') || '[]'));
    } catch {}
  }, [navigate, page, pageSize, search]);

  const totalPages = Math.max(1, Math.ceil((total || 0) / pageSize));

  const canManage = !!(user && ['manager','master'].includes(user.role));

  const createEmpty = (): ShipmentItem => ({ id: '', freightNo: '', vehicleNo: '', departDate: new Date().toISOString().slice(0,10), destination: '', note: '', createdBy: user?.username, packageCount: 0 });

  const saveShipment = async () => {
    if (!draft || !user) return;
    if (!draft.freightNo.trim()) return;
    const isNew = !draft.id;
    if (isNew) {
      const r = await fetchWithRetry('/.netlify/functions/transport-manage', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username }, body: JSON.stringify({ op: 'create', freightNo: draft.freightNo, vehicleNo: draft.vehicleNo, departDate: draft.departDate, note: draft.note, destination: draft.destination }) });
      if (!r.ok) { try { const j = await r.json(); alert(j.message || '创建失败'); } catch {} return; }
    } else {
      const r = await fetchWithRetry('/.netlify/functions/transport-manage', { method: 'PATCH', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username }, body: JSON.stringify({ shipmentId: draft.id, changes: { freightNo: draft.freightNo, vehicleNo: draft.vehicleNo, departDate: draft.departDate, note: draft.note, destination: draft.destination } }) });
      if (!r.ok) { try { const j = await r.json(); alert(j.message || '保存失败'); } catch {} return; }
    }
    const qs = new URLSearchParams({ page: String(page), pageSize: String(pageSize), search });
    const r2 = await fetchWithRetry('/.netlify/functions/transport-manage?' + qs.toString(), { headers: { 'x-ml-actor': user.username } });
    const j2 = await r2.json();
    setItems(j2.items || []);
    setTotal(j2.total || 0);
    // 写入历史
    try {
      if (draft?.freightNo) {
        const next = [draft.freightNo, ...histFreight.filter(x=>x!==draft.freightNo)].slice(0, 30);
        setHistFreight(next); localStorage.setItem('ml_hist_freight', JSON.stringify(next));
      }
      if (draft?.vehicleNo) {
        const next = [draft.vehicleNo, ...histVehicle.filter(x=>x!==draft.vehicleNo)].slice(0, 30);
        setHistVehicle(next); localStorage.setItem('ml_hist_vehicle', JSON.stringify(next));
      }
    } catch {}
    setOpenEdit(false);
    setDraft(null);
  };

  const addPackages = async () => {
    if (!draft || !user) return;
    const lines = trackingInput.split(/\s|,|;|\n/).map(s => s.trim()).filter(Boolean);
    if (!lines.length) return;
    const r = await fetchWithRetry('/.netlify/functions/transport-manage', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username }, body: JSON.stringify({ op: 'addPackages', shipmentId: draft.id, trackingNumbers: lines }) });
    if (!r.ok) { try { const j = await r.json(); alert(j.message || '添加失败'); } catch {} return; }
    setOpenAddPkgs(false);
    setTrackingInput('');
  };

  const viewPackagesOfShipment = async (shipment: ShipmentItem) => {
    if (!user) return;
    setPkgShipmentTitle(`${shipment.freightNo}（共 ${shipment.packageCount} 件）`);
    setPkgShipmentId(shipment.id);
    setPkgItems([]);
    setOpenPkgList(true);
    setPkgLoading(true);
    try {
      const qs = new URLSearchParams({ shipmentId: shipment.id });
      const r = await fetchWithRetry('/.netlify/functions/transport-manage?' + qs.toString(), { headers: { 'x-ml-actor': user.username } });
      const j = await r.json();
      const list = Array.isArray(j.packages) ? j.packages : [];
      let mapped = list.map((p: any) => ({
        tracking_no: p.tracking_no || p.trackingNo || p.tracking_number || '',
        sender: p.sender,
        receiver: p.receiver,
      })).filter((p: any) => p.tracking_no);
      if (!mapped.length && Array.isArray(j.trackingNumbers)) {
        mapped = j.trackingNumbers.map((t: any) => ({ tracking_no: String(t || '') })).filter((p: any) => p.tracking_no);
      }
      setPkgItems(mapped);
    } catch {}
    setPkgLoading(false);
  };

  const notifyArrival = async (shipment: ShipmentItem) => {
    if (!user) return;
    if (!(window as any).confirm('确定标记该运单到货并通知财务置为"待签收"？')) return;
    try {
      const r = await fetchWithRetry('/.netlify/functions/transport-manage', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username }, body: JSON.stringify({ op: 'arrive', shipmentId: shipment.id }) });
      if (!r.ok) { try { const j = await r.json(); alert(j.message || '到货通知失败'); } catch {} return; }
      // 刷新财务页签缓存：触发一次查询
      try { await fetchWithRetry('/.netlify/functions/finances-manage?status=' + encodeURIComponent('待签收')); } catch {}
      alert('到货已通知，相关财务记录已置为"待签收"。');
    } catch {
      alert('到货通知失败');
    }
  };

  const openTransitDialog = (shipment: ShipmentItem) => {
    setTransitShipment(shipment);
    setTransitLocation('');
    setNextFreightNo('');
    setTransitNote('');
    setTransitOpen(true);
  };

  const confirmTransit = async () => {
    if (!user || !transitShipment) return;
    const location = transitLocation.trim();
    if (!location) { alert('请输入中转地点'); return; }
    
    setTransitBusy(true);
    try {
      const r = await fetchWithRetry('/.netlify/functions/transport-manage', { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username }, 
        body: JSON.stringify({ 
          op: 'transit', 
          shipmentId: transitShipment.id,
          transitLocation: location,
          nextFreightNo: nextFreightNo.trim() || null,
          note: transitNote.trim() || null
        }) 
      });
      
      if (!r.ok) { 
        try { const j = await r.json(); alert(j.message || '中转操作失败'); } catch {} 
        return; 
      }
      
      alert('中转信息已记录，包裹继续运输中。');
      setTransitOpen(false);
      setTransitShipment(null);
      // 刷新列表
      await reloadShipmentsList();
    } catch {
      alert('中转操作失败');
    } finally {
      setTransitBusy(false);
    }
  };

  const addPackagesInModal = async () => {
    if (!user || !pkgShipmentId) return;
    const lines = pkgAddInput.split(/\s|,|;|\n/).map(s => s.trim()).filter(Boolean);
    if (!lines.length) return;
    const r = await fetchWithRetry('/.netlify/functions/transport-manage', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username }, body: JSON.stringify({ op: 'addPackages', shipmentId: pkgShipmentId, trackingNumbers: lines }) });
    if (!r.ok) { try { const j = await r.json(); alert(j.message || '添加失败'); } catch {} return; }
    // 刷新弹窗与列表数量
    setPkgItems(prev => [...prev, ...lines.map(t => ({ tracking_no: t }))]);
    setItems(prev => prev.map(i => i.id === pkgShipmentId ? { ...i, packageCount: i.packageCount + lines.length } : i));
    setPkgAddInput('');
  };

  const removePackageFromShipment = async (trackingNo: string) => {
    if (!user || !pkgShipmentId) return;
    const r = await fetchWithRetry('/.netlify/functions/transport-manage', { method: 'DELETE', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username }, body: JSON.stringify({ shipmentId: pkgShipmentId, trackingNumber: trackingNo }) });
    if (!r.ok) { try { const j = await r.json(); alert(j.message || '移除失败'); } catch {} return; }
    setPkgItems(prev => prev.filter(p => p.tracking_no !== trackingNo));
    setItems(prev => prev.map(i => i.id === pkgShipmentId ? { ...i, packageCount: Math.max(0, i.packageCount - 1) } : i));
  };

  const removeShipment = async (id: string) => {
    if (!user) return;
    if (!(window as any).confirm('确定删除该运单及关联包裹关系吗？')) return;
    const r = await fetchWithRetry('/.netlify/functions/transport-manage', { method: 'DELETE', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username }, body: JSON.stringify({ shipmentId: id }) });
    if (!r.ok) { try { const j = await r.json(); alert(j.message || '删除失败'); } catch {} return; }
    setItems(prev => prev.filter(i => i.id !== id));
  };

  if (!user) return null;
  const role = (user.role || '').trim().toLowerCase();

  return (
    <Box sx={{ minHeight: '100vh', backgroundColor: 'grey.50' }}>
      <AppBar position="static" sx={{ backgroundColor: 'white', color: 'text.primary' }}>
        <Toolbar>
          <Box sx={{ flexGrow: 1 }} />
          <Box sx={{ display: 'flex', gap: 1, mr: 2 }}>
            <Button size="small" onClick={() => navigate('/admin/inventory')}>包裹管理</Button>
            {['accountant','manager','master'].includes(role) && <Button size="small" onClick={() => navigate('/admin/finance')}>财务系统</Button>}
            <Button size="small" variant="contained" onClick={() => navigate('/admin/transport')}>运输系统</Button>
            <Button size="small" onClick={() => navigate('/admin/dashboard')}>控制台</Button>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, ml: 2 }}>
            <Typography variant="body2" color="text.secondary">欢迎，{user.username} ({user.role})</Typography>
            <Person />
          </Box>
        </Toolbar>
      </AppBar>

      <Container maxWidth="lg" sx={{ py: 4, pb: { xs: 10, md: 4 } }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
          <Typography variant="h6" sx={{ fontWeight: 600 }}>运输系统</Typography>
          <Box sx={{ display: 'flex', gap: 1 }}>
            {!isMobile && (
              <>
                <TextField size="small" placeholder="搜索货运号" value={search} onChange={(e)=>setSearch(e.target.value)} />
                <Button variant="outlined" onClick={async ()=>{
                  if (!user) return;
                  setDiagOpen(true);
                  setDiagLoading(true);
                  try {
                    const r = await fetchWithRetry('/.netlify/functions/transport-consistency', { headers: { 'x-ml-actor': user.username } });
                    const j = await r.json();
                    setDiagMissing(Array.isArray(j.missing) ? j.missing : []);
                  } catch {
                    setDiagMissing([]);
                    alert('加载异常列表失败');
                  } finally {
                    setDiagLoading(false);
                  }
                }}>异常核对</Button>
                {canManage && <Button variant="contained" onClick={()=>{ setDraft(createEmpty()); setOpenEdit(true); }}>新建运单</Button>}
              </>
            )}
            {isMobile && (
              <Button variant="outlined" onClick={()=> setMobileFilterOpen(true)}>筛选</Button>
            )}
          </Box>
        </Box>

        {isMobile ? (
          <Box>
            {loading && (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, mb: 2 }}>
                {Array.from({ length: 6 }).map((_, i) => (<Skeleton key={i} variant="rounded" height={88} />))}
              </Box>
            )}
            {!loading && items.length === 0 && (
              <Paper sx={{ p: 3, textAlign: 'center', color: 'text.secondary' }}>暂无运单</Paper>
            )}
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              {items.map(s => (
                <SwipeableItem key={s.id} onLeftAction={()=>removeShipment(s.id)} leftLabel="删除" leftColor="error" onRightAction={()=>{ setDraft(s); setOpenEdit(true); }} rightLabel="编辑" rightColor="primary" height={96}>
                <Card sx={{ p: 1.5 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography sx={{ fontWeight: 700 }}>{s.freightNo}</Typography>
                    <Chip size="small" label={`${s.packageCount} 件`} color={s.packageCount>0 ? 'primary' : 'default'} onClick={()=>viewPackagesOfShipment(s)} clickable={s.packageCount>0} />
                  </Box>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: .5 }}>车牌 {s.vehicleNo || '—'} · 发车 {s.departDate || '—'} · 目的地 {s.destination || '—'}</Typography>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
                    <Typography variant="body2" color="text.secondary">{s.note || ' '}</Typography>
                    <Box sx={{ display: 'flex', gap: .5 }}>
                      <Button size="small" onClick={()=>{ setDraft(s); setOpenEdit(true); }}>编辑</Button>
                      <Button size="small" onClick={()=>{ setDraft(s); setOpenAddPkgs(true); }}>加包裹</Button>
                      <Button size="small" color="warning" onClick={()=>openTransitDialog(s)}>中转</Button>
                      <Button size="small" color="success" onClick={()=>notifyArrival(s)}>到货</Button>
                      <IconButton size="small" color="error" onClick={()=>removeShipment(s.id)}><Delete fontSize="small" /></IconButton>
                    </Box>
                  </Box>
                </Card>
                </SwipeableItem>
              ))}
            </Box>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', p: 2 }}>
              <Pagination count={totalPages} page={page} onChange={(_, p)=>setPage(p)} size="small" color="primary" />
            </Box>
          </Box>
        ) : (
          <Paper>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow sx={{ backgroundColor: 'grey.50' }}>
                    <TableCell>货运号</TableCell>
                    <TableCell>车牌</TableCell>
                    <TableCell>发车日期</TableCell>
                    <TableCell>目的地</TableCell>
                    <TableCell>包裹数</TableCell>
                    <TableCell>备注</TableCell>
                    <TableCell align="right">操作</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {items.map(s => (
                    <TableRow key={s.id} hover>
                      <TableCell><Chip size="small" label={s.freightNo} /></TableCell>
                      <TableCell>{s.vehicleNo || '—'}</TableCell>
                      <TableCell>{s.departDate || '—'}</TableCell>
                      <TableCell>{s.destination || '—'}</TableCell>
                      <TableCell>
                        <Chip size="small" color={s.packageCount > 0 ? 'primary' : undefined} variant={s.packageCount > 0 ? 'outlined' : undefined} label={s.packageCount} onClick={()=>viewPackagesOfShipment(s)} clickable={s.packageCount > 0} />
                      </TableCell>
                      <TableCell>{s.note || ''}</TableCell>
                      <TableCell align="right">
                        <Button size="small" onClick={()=>{ setDraft(s); setOpenEdit(true); }}>编辑</Button>
                        <Button size="small" onClick={()=>{ setDraft(s); setOpenAddPkgs(true); }}>添加包裹</Button>
                        <Button size="small" color="warning" onClick={()=>openTransitDialog(s)}>中转</Button>
                        <Button size="small" color="success" onClick={()=>notifyArrival(s)}>到货通知</Button>
                        <IconButton size="small" color="error" onClick={()=>removeShipment(s.id)}><Delete fontSize="small" /></IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', p: 2 }}>
              <Pagination count={totalPages} page={page} onChange={(_, p)=>setPage(p)} size="small" color="primary" />
            </Box>
          </Paper>
        )}

        {/* 新建/编辑运单 */}
        <Dialog open={openEdit} onClose={()=>{ setOpenEdit(false); setDraft(null); }} maxWidth="sm" fullWidth>
          <DialogTitle>{draft?.id ? '编辑运单' : '新建运单'}</DialogTitle>
          <DialogContent>
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12} sm={6}>
                <Autocomplete freeSolo options={histFreight}
                  inputValue={draft?.freightNo || ''}
                  onInputChange={(_, v)=>draft && setDraft({ ...draft, freightNo: v })}
                  renderInput={(params)=>(<TextField {...params} fullWidth label="货运号" />)}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Autocomplete freeSolo options={histVehicle}
                  inputValue={draft?.vehicleNo || ''}
                  onInputChange={(_, v)=>draft && setDraft({ ...draft, vehicleNo: v })}
                  renderInput={(params)=>(<TextField {...params} fullWidth label="车牌" />)}
                />
              </Grid>
              <Grid item xs={12} sm={6}><TextField fullWidth type="date" label="发车日期" value={draft?.departDate || ''} onChange={(e)=>draft && setDraft({ ...draft, departDate: e.target.value })} InputLabelProps={{ shrink: true }} /></Grid>
              <Grid item xs={12} sm={6}><TextField fullWidth label="目的地" placeholder="例如：仰光、曼德勒等" value={draft?.destination || ''} onChange={(e)=>draft && setDraft({ ...draft, destination: e.target.value })} /></Grid>
              <Grid item xs={12}><TextField fullWidth label="备注" value={draft?.note || ''} onChange={(e)=>draft && setDraft({ ...draft, note: e.target.value })} /></Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={()=>{ setOpenEdit(false); setDraft(null); }}>取消</Button>
            {canManage && <Button variant="contained" onClick={saveShipment}>保存</Button>}
          </DialogActions>
        </Dialog>

        {/* 添加包裹 */}
        <Dialog open={openAddPkgs} onClose={()=>{ setOpenAddPkgs(false); setTrackingInput(''); }} maxWidth="sm" fullWidth>
          <DialogTitle>添加包裹至运单 - {draft?.freightNo}</DialogTitle>
          <DialogContent>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>可一次粘贴多个单号，支持空格/换行/逗号分隔</Typography>
            <TextField fullWidth multiline minRows={4} placeholder="如：
ML123456789
ML987654321
..." value={trackingInput} onChange={(e)=>setTrackingInput(e.target.value)} />
          </DialogContent>
          <DialogActions>
            <Button onClick={()=>{ setOpenAddPkgs(false); setTrackingInput(''); }}>取消</Button>
            {canManage && <Button variant="contained" onClick={addPackages}>添加</Button>}
          </DialogActions>
        </Dialog>
      </Container>

      {/* 移动端筛选抽屉 */}
      <Drawer anchor="bottom" open={mobileFilterOpen} onClose={()=>setMobileFilterOpen(false)} sx={{ display: { xs: 'block', md: 'none' }}}>
        <Box sx={{ p: 2 }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>筛选</Typography>
          <Divider sx={{ mb: 2 }} />
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            <TextField fullWidth size="small" placeholder="搜索货运号" value={search} onChange={(e)=>setSearch(e.target.value)} />
            <Box sx={{ display: 'flex', gap: 1, mt: .5 }}>
              <Button fullWidth variant="text" onClick={()=>{ setSearch(''); }}>重置</Button>
              <Button fullWidth variant="contained" onClick={()=>setMobileFilterOpen(false)}>完成</Button>
            </Box>
          </Box>
        </Box>
      </Drawer>

      {/* 移动端底部主操作条 */}
      <Paper sx={{ position: 'fixed', bottom: 0, left: 0, right: 0, display: { xs: 'flex', md: 'none' }, gap: 1, p: 1, borderTopLeftRadius: 12, borderTopRightRadius: 12 }} elevation={10}>
        <Button fullWidth variant="outlined" onClick={()=>setMobileFilterOpen(true)}>筛选</Button>
        <Button fullWidth variant="outlined" onClick={()=>{ setSearch(''); }}>清空</Button>
        {canManage && <Button fullWidth variant="contained" onClick={()=>{ setDraft(createEmpty()); setOpenEdit(true); }}>新建</Button>}
      </Paper>
      {/* 运单包裹列表 */}
      <Dialog open={openPkgList} onClose={()=>setOpenPkgList(false)} maxWidth="xs" PaperProps={{ sx: { width: 320 } }}>
        <DialogTitle>运单包裹 - {pkgShipmentTitle}</DialogTitle>
        <DialogContent>
          {pkgLoading ? (
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', py: 4 }}>
              <CircularProgress size={24} />
            </Box>
          ) : (
            <>
              {/* 筛选输入 */}
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.5 }}>
                <TextField size="small" fullWidth placeholder="筛选单号" value={pkgFilter} onChange={(e)=>setPkgFilter(e.target.value)} />
                {pkgFilter && <Button size="small" onClick={()=>setPkgFilter('')}>清空</Button>}
              </Box>

              {filteredPkgItems.length === 0 ? (
                <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>暂无包裹</Typography>
              ) : (
                <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 1, maxHeight: 260, overflowY: 'auto', pr: 0.5 }}>
                  {filteredPkgItems.map((p, i) => (
                    <Chip key={p.tracking_no + i} size="small" label={p.tracking_no} />
                  ))}
                </Box>
              )}
            </>
          )}
        </DialogContent>
        <DialogActions>
          {filteredPkgItems.length > 0 && <Button onClick={copyAllTracking}>复制筛选结果</Button>}
          <Button onClick={()=>setOpenPkgList(false)}>关闭</Button>
        </DialogActions>
      </Dialog>

      {/* 运输异常核对 */}
      <Dialog open={diagOpen} onClose={()=>!diagBusy && setDiagOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>运输异常核对</DialogTitle>
        <DialogContent>
          {diagLoading ? (
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', py: 4 }}>
              <CircularProgress size={24} />
            </Box>
          ) : (
            <>
              <Typography variant="body2" color="text.secondary">以下为“运输中”但未加入任何运单的单号：</Typography>
              {diagMissing.length === 0 ? (
                <Paper sx={{ p: 2, textAlign: 'center', color: 'text.secondary', mt: 1 }}>暂无异常</Paper>
              ) : (
                <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 1, maxHeight: 240, overflowY: 'auto' }}>
                  {diagMissing.map((t, i) => (<Chip key={t + i} size="small" label={t} />))}
                </Box>
              )}
              <Divider sx={{ my: 2 }} />
              <Typography variant="subtitle2" sx={{ mb: 1 }}>批量加入运单</Typography>
              <TextField fullWidth size="small" label="货运号" placeholder="例如：ML-2024-0001" value={diagFreightNo} onChange={(e)=>setDiagFreightNo(e.target.value)} />
              <Typography variant="caption" color="text.secondary">将上方全部异常单号加入该运单，并自动把状态置为“运输中”。</Typography>
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button disabled={diagBusy} onClick={()=>setDiagOpen(false)}>关闭</Button>
          <Button variant="contained" disabled={diagBusy || diagMissing.length===0 || !diagFreightNo.trim()} onClick={async ()=>{
            if (!user) return; const freightNo = diagFreightNo.trim(); if (!freightNo) return;
            setDiagBusy(true);
            try {
              // 查找或创建运单
              let shipmentId: string | null = null;
              try {
                const qs = new URLSearchParams({ page: '1', pageSize: '1', search: freightNo });
                const r = await fetchWithRetry('/.netlify/functions/transport-manage?' + qs.toString(), { headers: { 'x-ml-actor': user.username } });
                const j = await r.json();
                const hit = (j.items || []).find((s: any) => String(s.freightNo) === freightNo);
                if (hit) shipmentId = hit.id;
              } catch {}
              if (!shipmentId) {
                const rc = await fetchWithRetry('/.netlify/functions/transport-manage', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username }, body: JSON.stringify({ op: 'create', freightNo }) });
                const jc = await rc.json().catch(()=>({}));
                if (!rc.ok && !jc?.item?.id) throw new Error(jc?.message || '创建运单失败');
                shipmentId = jc?.item?.id || null;
              }
              if (!shipmentId) throw new Error('无法获取运单ID');
              // 加入全部异常单号
              const arr = Array.from(new Set(diagMissing.filter(Boolean)));
              if (arr.length) {
                const rb = await fetchWithRetry('/.netlify/functions/transport-manage', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-ml-actor': user.username }, body: JSON.stringify({ op: 'addPackages', shipmentId, trackingNumbers: arr }) });
                if (!rb.ok) { const jb = await rb.json().catch(()=>({})); throw new Error(jb?.message || '加入失败'); }
              }
              alert('已将异常单号加入运单');
              setDiagOpen(false);
              setDiagFreightNo('');
              setDiagMissing([]);
              await reloadShipmentsList();
            } catch (e: any) {
              alert(e?.message || '批量加入失败');
            } finally {
              setDiagBusy(false);
            }
          }}>加入该运单</Button>
        </DialogActions>
      </Dialog>

      {/* 中转弹窗 */}
      <Dialog open={transitOpen} onClose={()=>!transitBusy && setTransitOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>中转操作 - {transitShipment?.freightNo}</DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <TextField 
              fullWidth 
              label="中转地点 *" 
              placeholder="例如：曼德勒、仰光等"
              value={transitLocation}
              onChange={(e)=>setTransitLocation(e.target.value)}
              required
            />
            <TextField 
              fullWidth 
              label="下一程货运号" 
              placeholder="可选：下一程的货运号"
              value={nextFreightNo}
              onChange={(e)=>setNextFreightNo(e.target.value)}
            />
            <TextField 
              fullWidth 
              label="备注" 
              placeholder="中转相关备注信息"
              value={transitNote}
              onChange={(e)=>setTransitNote(e.target.value)}
              multiline
              minRows={2}
            />
            <Typography variant="body2" color="text.secondary">
              中转后包裹状态保持"运输中"，财务状态不变。只有到货通知后才会变为"待签收"。
            </Typography>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button disabled={transitBusy} onClick={()=>setTransitOpen(false)}>取消</Button>
          <Button variant="contained" disabled={transitBusy} onClick={confirmTransit}>
            {transitBusy ? '处理中...' : '确认中转'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default AdminTransport;


