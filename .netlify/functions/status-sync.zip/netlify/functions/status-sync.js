"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/status-sync.ts
var status_sync_exports = {};
__export(status_sync_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(status_sync_exports);
var riderStatuses = /* @__PURE__ */ new Map();
var handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, x-ml-actor, x-ml-role",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  const httpMethod = event.httpMethod;
  try {
    if (httpMethod === "POST" || httpMethod === "PUT") {
      const body = JSON.parse(event.body || "{}");
      const { riderId, status, currentTask, source = "unknown" } = body;
      if (!riderId) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ success: false, message: "\u7F3A\u5C11\u9A91\u624BID" })
        };
      }
      const statusUpdate = {
        riderId,
        status: status || "offline",
        currentTask: currentTask || null,
        lastUpdate: (/* @__PURE__ */ new Date()).toISOString(),
        source
      };
      riderStatuses.set(riderId, statusUpdate);
      console.log(`\u{1F504} \u72B6\u6001\u540C\u6B65\u66F4\u65B0: ${riderId} -> ${status} (\u6765\u6E90: ${source})`);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          message: "\u72B6\u6001\u540C\u6B65\u6210\u529F",
          data: statusUpdate
        })
      };
    }
    if (httpMethod === "GET") {
      const queryParams = new URLSearchParams(event.queryString || "");
      const riderId = queryParams.get("riderId");
      const source = queryParams.get("source");
      if (riderId) {
        const status = riderStatuses.get(riderId);
        if (!status) {
          return {
            statusCode: 404,
            headers,
            body: JSON.stringify({ success: false, message: "\u9A91\u624B\u72B6\u6001\u4E0D\u5B58\u5728" })
          };
        }
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ success: true, data: status })
        };
      }
      const allStatuses = Array.from(riderStatuses.values());
      const filteredStatuses = source ? allStatuses.filter((status) => status.source !== source) : allStatuses;
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          data: filteredStatuses,
          count: filteredStatuses.length
        })
      };
    }
    if (httpMethod === "DELETE") {
      const queryParams = new URLSearchParams(event.queryString || "");
      const riderId = queryParams.get("riderId");
      if (!riderId) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ success: false, message: "\u7F3A\u5C11\u9A91\u624BID" })
        };
      }
      const deleted = riderStatuses.delete(riderId);
      if (!deleted) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ success: false, message: "\u9A91\u624B\u72B6\u6001\u4E0D\u5B58\u5728" })
        };
      }
      console.log(`\u{1F5D1}\uFE0F \u9A91\u624B\u72B6\u6001\u5DF2\u5220\u9664: ${riderId}`);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true, message: "\u9A91\u624B\u72B6\u6001\u5DF2\u5220\u9664" })
      };
    }
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ success: false, message: "\u4E0D\u652F\u6301\u7684HTTP\u65B9\u6CD5" })
    };
  } catch (error) {
    console.error("\u72B6\u6001\u540C\u6B65API\u9519\u8BEF:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        message: "\u670D\u52A1\u5668\u5185\u90E8\u9519\u8BEF",
        error: error instanceof Error ? error.message : "\u672A\u77E5\u9519\u8BEF"
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
