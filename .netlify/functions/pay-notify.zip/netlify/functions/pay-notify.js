"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/pay-notify.ts
var pay_notify_exports = {};
__export(pay_notify_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(pay_notify_exports);
var sendSMS = async (phone, message) => {
  const webhook = process.env.SMS_WEBHOOK_URL;
  const webhookKey = process.env.SMS_WEBHOOK_KEY || "";
  if (webhook) {
    const r2 = await fetch(webhook, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...webhookKey ? { "x-webhook-key": webhookKey } : {} },
      body: JSON.stringify({ phone, message })
    });
    if (!r2.ok) {
      const text = await r2.text().catch(() => "");
      throw new Error(`SMS webhook error: ${r2.status} ${text}`);
    }
    return await r2.json().catch(() => ({ ok: true }));
  }
  const r = await fetch("https://textbelt.com/text", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ phone, message, key: process.env.TEXTBELT_KEY || "textbelt" })
  });
  return await r.json();
};
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "content-type" } };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  try {
    const data = JSON.parse(event.body || "{}");
    const phone = String(data.phone || "").trim();
    const tracking = String(data.trackingNumber || "").trim();
    if (!phone || !tracking) {
      return { statusCode: 400, body: JSON.stringify({ ok: false, message: "phone/trackingNumber required" }) };
    }
    const message = data.message || `\u60A8\u7684\u8BA2\u5355\u5DF2\u63D0\u4EA4\u5E76\u5B8C\u6210\u9884\u5B9A\u8D39\u652F\u4ED8\uFF0C\u5355\u53F7\uFF1A${tracking}\u3002\u6211\u4EEC\u5C06\u5C3D\u5FEB\u4E3A\u60A8\u5B89\u6392\u53D6\u4EF6\u4E0E\u914D\u9001\u3002\u611F\u8C22\u652F\u6301\uFF01`;
    const smsRes = await sendSMS(phone, message);
    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ ok: true, sms: smsRes })
    };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ ok: false, message: e?.message || "Server error" }) };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
