"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/order-assignment.ts
var order_assignment_exports = {};
__export(order_assignment_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(order_assignment_exports);
var pendingAssignments = /* @__PURE__ */ new Map();
var handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, x-ml-actor, x-ml-role",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  const httpMethod = event.httpMethod;
  const path = event.path;
  try {
    if (httpMethod === "POST") {
      const body = JSON.parse(event.body || "{}");
      const {
        riderId,
        riderName,
        taskType,
        trackingNumber,
        destination,
        estimatedTime = 30,
        assignedBy
      } = body;
      if (!riderId || !taskType || !trackingNumber) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ success: false, message: "\u7F3A\u5C11\u5FC5\u8981\u53C2\u6570" })
        };
      }
      const taskId = `task_${Date.now()}_${riderId}`;
      const assignment = {
        riderId,
        riderName: riderName || riderId,
        taskId,
        taskType,
        trackingNumber,
        destination: destination || "\u672A\u77E5",
        estimatedTime,
        assignedAt: (/* @__PURE__ */ new Date()).toISOString(),
        status: "pending",
        assignedBy: assignedBy || "system"
      };
      pendingAssignments.set(taskId, assignment);
      console.log(`\u{1F4F1} \u65B0\u4EFB\u52A1\u5206\u914D\u7ED9\u9A91\u624B ${riderName} (${riderId}): ${trackingNumber}`);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          message: "\u4EFB\u52A1\u5206\u914D\u6210\u529F",
          taskId,
          assignment
        })
      };
    }
    if (httpMethod === "GET") {
      const queryParams = new URLSearchParams(event.queryString || "");
      const riderId = queryParams.get("riderId");
      const taskId = queryParams.get("taskId");
      if (taskId) {
        const assignment = pendingAssignments.get(taskId);
        if (!assignment) {
          return {
            statusCode: 404,
            headers,
            body: JSON.stringify({ success: false, message: "\u4EFB\u52A1\u4E0D\u5B58\u5728" })
          };
        }
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ success: true, data: assignment })
        };
      }
      if (riderId) {
        const riderAssignments = Array.from(pendingAssignments.values()).filter((assignment) => assignment.riderId === riderId).sort((a, b) => new Date(b.assignedAt).getTime() - new Date(a.assignedAt).getTime());
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            success: true,
            data: riderAssignments,
            count: riderAssignments.length
          })
        };
      }
      const allAssignments = Array.from(pendingAssignments.values()).sort((a, b) => new Date(b.assignedAt).getTime() - new Date(a.assignedAt).getTime());
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          data: allAssignments,
          count: allAssignments.length
        })
      };
    }
    if (httpMethod === "PUT") {
      const body = JSON.parse(event.body || "{}");
      const { taskId, status, riderId } = body;
      if (!taskId || !status) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ success: false, message: "\u7F3A\u5C11\u4EFB\u52A1ID\u6216\u72B6\u6001" })
        };
      }
      const assignment = pendingAssignments.get(taskId);
      if (!assignment) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ success: false, message: "\u4EFB\u52A1\u4E0D\u5B58\u5728" })
        };
      }
      if (riderId && assignment.riderId !== riderId) {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ success: false, message: "\u65E0\u6743\u9650\u64CD\u4F5C\u6B64\u4EFB\u52A1" })
        };
      }
      assignment.status = status;
      if (status === "accepted") {
        console.log(`\u2705 \u9A91\u624B ${assignment.riderName} \u63A5\u53D7\u4E86\u4EFB\u52A1 ${assignment.trackingNumber}`);
      } else if (status === "rejected") {
        console.log(`\u274C \u9A91\u624B ${assignment.riderName} \u62D2\u7EDD\u4E86\u4EFB\u52A1 ${assignment.trackingNumber}`);
      } else if (status === "completed") {
        console.log(`\u{1F389} \u9A91\u624B ${assignment.riderName} \u5B8C\u6210\u4E86\u4EFB\u52A1 ${assignment.trackingNumber}`);
        pendingAssignments.delete(taskId);
      }
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          message: "\u4EFB\u52A1\u72B6\u6001\u66F4\u65B0\u6210\u529F",
          assignment
        })
      };
    }
    if (httpMethod === "DELETE") {
      const queryParams = new URLSearchParams(event.queryString || "");
      const taskId = queryParams.get("taskId");
      if (!taskId) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ success: false, message: "\u7F3A\u5C11\u4EFB\u52A1ID" })
        };
      }
      const deleted = pendingAssignments.delete(taskId);
      if (!deleted) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ success: false, message: "\u4EFB\u52A1\u4E0D\u5B58\u5728" })
        };
      }
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true, message: "\u4EFB\u52A1\u5DF2\u53D6\u6D88" })
      };
    }
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ success: false, message: "\u4E0D\u652F\u6301\u7684HTTP\u65B9\u6CD5" })
    };
  } catch (error) {
    console.error("\u8BA2\u5355\u5206\u914DAPI\u9519\u8BEF:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        message: "\u670D\u52A1\u5668\u5185\u90E8\u9519\u8BEF",
        error: error instanceof Error ? error.message : "\u672A\u77E5\u9519\u8BEF"
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
