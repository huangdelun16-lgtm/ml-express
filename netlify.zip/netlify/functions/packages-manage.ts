
// import type { Handler } from '@netlify/functions';
import { getAuthFromEvent, hasDbRole } from './_auth';
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.SUPABASE_URL as string;
const SERVICE_ROLE = process.env.SUPABASE_SERVICE_ROLE as string;

const client = SUPABASE_URL && SERVICE_ROLE
  ? createClient(SUPABASE_URL, SERVICE_ROLE, { auth: { persistSession: false } })
  : null;

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, x-ml-actor, x-ml-role, Authorization',
  'Access-Control-Allow-Credentials': 'true',
};

function json(statusCode: number, body: any, cache?: { maxAge?: number; swr?: number }) {
  const cc = cache && statusCode === 200
    ? `public, max-age=${Math.max(0, cache.maxAge ?? 30)}, stale-while-revalidate=${Math.max(0, cache.swr ?? 120)}`
    : undefined;
  const headers: Record<string,string> = { 'Content-Type': 'application/json', 'X-Function-Rev': 'pkg-guard-v3-secure', ...cors };
  if (cc) {
    headers['Cache-Control'] = cc;
    headers['Vary'] = 'Authorization, x-ml-actor, x-ml-role';
  }
  return { statusCode, headers, body: JSON.stringify(body) };
}

async function hasRequiredRole(username: string, roles: string[]): Promise<boolean> {
  if (!username) return false;
  try {
    const { data, error } = await client!.from('users').select('role').eq('username', username).limit(1);
    if (error) return false;
    const role = data && data[0]?.role;
    return role ? roles.includes(role) : false;
  } catch {
    return false;
  }
}

export const handler = async (event: any) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: cors, body: '' } as any;
  if (!client) return json(500, { message: 'backend not configured: missing SUPABASE_URL or SUPABASE_SERVICE_ROLE' });

  const session = getAuthFromEvent(event);
  const actor = session?.username || (event.headers['x-ml-actor'] || event.headers['X-ML-Actor'] || '').toString();

  try {
    const qs = event.queryStringParameters || {};
    if (qs.debug === '1') {
      try {
        const probe = await client.from('packages').select('id', { count: 'exact', head: true });
        return json(200, {
          env: {
            SUPABASE_URL: !!process.env.SUPABASE_URL,
            SUPABASE_SERVICE_ROLE: !!process.env.SUPABASE_SERVICE_ROLE,
          },
          status: 'ok',
          count: (probe as any)?.count ?? null,
          error: (probe as any)?.error?.message || null,
        });
      } catch (e: any) {
        return json(500, { status: 'error', message: e?.message || 'probe failed' });
      }
    }
    if (event.httpMethod === 'GET') {
      // RBAC: staff 只可查看自己创建的包裹
      let isStaff = false;
      try { isStaff = await hasDbRole(client!, actor, ['staff']); } catch {}
      let hasCreatedByCol = true;
      try {
        const probe = await client.from('packages').select('created_by').limit(1);
        if ((probe as any)?.error) hasCreatedByCol = false;
      } catch { hasCreatedByCol = false; }
      const status = (qs.status || '') as string;
      const search = (qs.search || '') as string;
      const page = Math.max(1, parseInt((qs.page as string) || '1', 10));
      const pageSize = Math.min(100, Math.max(5, parseInt((qs.pageSize as string) || '20', 10)));

      // 统计总数
      let countQuery = client.from('packages').select('id', { count: 'exact', head: true });
      if (status) countQuery = countQuery.eq('status', status);
      if (isStaff && hasCreatedByCol && actor) {
        try { countQuery = (countQuery as any).eq('created_by', actor); } catch {}
      }
      if (search) {
        countQuery = (countQuery as any).or(
          `tracking_no.ilike.%${search}%,sender.ilike.%${search}%,receiver.ilike.%${search}%`
        );
      }
      const { count: total = 0 } = (await countQuery) as any;

      // 分页查询
      let listQuery = client
        .from('packages')
        .select('*')
        .order('created_at', { ascending: false })
        .range((page - 1) * pageSize, page * pageSize - 1);
      if (status) listQuery = listQuery.eq('status', status);
      if (isStaff && hasCreatedByCol && actor) {
        try { listQuery = (listQuery as any).eq('created_by', actor); } catch {}
      }
      if (search) {
        listQuery = (listQuery as any).or(
          `tracking_no.ilike.%${search}%,sender.ilike.%${search}%,receiver.ilike.%${search}%`
        );
      }
      const { data, error } = await listQuery;
      if (error) return json(500, { message: error.message });
      const items = (data || []).map((r: any) => ({
        id: r.id,
        trackingNumber: r.tracking_number ?? r.tracking_no ?? r.tracking,
        sender: r.sender,
        receiver: r.receiver,
        origin: r.origin,
        destination: r.destination,
        packageType: r.package_type ?? r.packageType,
        weightKg: Number(r.weight_kg || 0),
        dimensions: { lengthCm: Number(r.length_cm || 0), widthCm: Number(r.width_cm || 0), heightCm: Number(r.height_cm || 0) },
        fee: Number(r.fee || 0),
        status: r.status,
        createdAt: r.created_at ?? r.created_date,
        estimatedDelivery: r.estimated_delivery ?? r.eta,
        note: r.note,
        inboundBy: r.inbound_by || null,
        inboundAt: r.inbound_at || null,
      }));
      return json(200, { items, page, pageSize, total }, { maxAge: 30, swr: 120 });
    }

    if (event.httpMethod === 'POST') {
      const body = event.body ? JSON.parse(event.body) : {};
      
      if (body.op === 'sign') {
        // 签收证明：上传照片、签名等
        const allowed = await hasDbRole(client!, actor, ['manager', 'master', 'staff']);
        if (!allowed) return json(403, { message: 'Forbidden' });
        const { packageId, photos, signature, courierInfo, note, destination } = body || {};
        if (!packageId) return json(400, { message: '缺少包裹ID' });
        if (!photos || !Array.isArray(photos) || photos.length === 0) return json(400, { message: '请上传签收证明照片' });
        // RBAC: staff 仅可签收自己创建的包裹
        try {
          const isStaff = await hasDbRole(client!, actor, ['staff']);
          if (isStaff) {
            let hasCreatedByCol = true;
            try {
              const probe = await client.from('packages').select('created_by').limit(1);
              if ((probe as any)?.error) hasCreatedByCol = false;
            } catch { hasCreatedByCol = false; }
            if (hasCreatedByCol) {
              const { data: ownerRow } = await client.from('packages').select('created_by').eq('id', packageId).single();
              const owner = ownerRow?.created_by || null;
              if (owner && actor && owner !== actor) return json(403, { message: '仅可操作自己创建的包裹' });
            }
          }
        } catch {}
        
        try {
          // 更新包裹状态为已签收
          await client.from('packages').update({
            status: '已签收',
            signed_at: new Date().toISOString(),
            signed_by: actor,
            destination: destination || null
          }).eq('id', packageId);
          
          // 创建签收证明记录
          const proofData = {
            package_id: packageId,
            photos: photos,
            signature: signature || null,
            courier_name: courierInfo?.name || null,
            courier_phone: courierInfo?.phone || null,
            courier_id: courierInfo?.id || null,
            note: note || null,
            created_by: actor,
            created_at: new Date().toISOString()
          };
          
          await client.from('delivery_proofs').insert([proofData]);
          
          // 审计日志
          try {
            let trackingNo: string | null = null;
            try { const { data: row } = await client.from('packages').select('tracking_no').eq('id', packageId).single(); trackingNo = row?.tracking_no || null; } catch {}
            await client.from('audit_logs').insert([{ actor, action: 'package.sign', detail: { packageId, tracking_no: trackingNo, proofData } }]);
          } catch {}
          
          return json(200, { ok: true, message: '签收证明已保存' });
        } catch (e: any) {
          return json(500, { message: e?.message || '签收失败' });
        }
      }
      
      // 创建新包裹
      const pkg = body || {};
      // 友好错误：重复单号
      try {
        const { data: dup } = await client.from('packages').select('id').eq('tracking_no', pkg.trackingNumber).limit(1);
        if (dup && dup.length > 0) {
          return json(409, { message: '单号已存在，请更换一个新的单号' });
        }
      } catch (e: any) {
        // 忽略检测错误，走正常流程
      }

      const row = {
        tracking_no: pkg.trackingNumber,
        sender: pkg.sender,
        receiver: pkg.receiver,
        origin: pkg.origin,
        destination: pkg.destination,
        package_type: pkg.packageType,
        weight_kg: pkg.weightKg,
        length_cm: pkg.dimensions?.lengthCm,
        width_cm: pkg.dimensions?.widthCm,
        height_cm: pkg.dimensions?.heightCm,
        fee: pkg.fee,
        status: pkg.status,
        
        created_at: pkg.createdAt || new Date().toISOString().slice(0,10),
        estimated_delivery: pkg.estimatedDelivery,
        note: pkg.note,
        created_by: actor,
      };
      const { data, error } = await client.from('packages').insert([row]).select('*').single();
      if (error) return json(500, { message: error.message });
      try { await client.from('audit_logs').insert([{ actor, action: 'packages.create', detail: { ...pkg, tracking_no: pkg.trackingNumber } }]); } catch {}
      return json(200, { item: data });
    }

    if (event.httpMethod === 'PATCH') {
      const allowed = await hasDbRole(client!, actor, ['manager','master','staff']);
      if (!allowed) return json(403, { message: 'Forbidden' });
      const body = event.body ? JSON.parse(event.body) : {};
      const { id, ...changes } = body || {};
      if (!id) return json(400, { message: '缺少ID' });
      // RBAC: staff 仅可修改自己创建的包裹
      try {
        const isStaff = await hasDbRole(client!, actor, ['staff']);
        if (isStaff) {
          let hasCreatedByCol = true;
          try {
            const probe = await client.from('packages').select('created_by').limit(1);
            if ((probe as any)?.error) hasCreatedByCol = false;
          } catch { hasCreatedByCol = false; }
          if (hasCreatedByCol) {
            const { data: ownerRow } = await client.from('packages').select('created_by').eq('id', id).single();
            const owner = ownerRow?.created_by || null;
            if (owner && actor && owner !== actor) return json(403, { message: '仅可操作自己创建的包裹' });
          }
        }
      } catch {}
      // 如果修改了 trackingNumber，先检测重复
      if (changes.trackingNumber) {
        try {
          const { data: dup } = await client
            .from('packages')
            .select('id')
            .eq('tracking_no', changes.trackingNumber)
            .neq('id', id)
            .limit(1);
          if (dup && dup.length > 0) {
            return json(409, { message: '单号已存在，请更换一个新的单号' });
          }
        } catch {}
      }

      // 检测是否存在 inbound_by / inbound_at 列，避免未知列导致 500
      let hasInboundCols = true;
      try {
        const probe = await client.from('packages').select('inbound_by,inbound_at').limit(1);
        if ((probe as any)?.error) hasInboundCols = false;
      } catch { hasInboundCols = false; }

      const update: any = {};
      // 规范化与校验状态
      if (typeof changes.status !== 'undefined') {
        const statusMap: Record<string, string> = { '入库': '已入库', '出库': '运输中' };
        const normalized = statusMap[changes.status] || changes.status;
        const allowed = ['已下单','已入库','运输中','已签收','已取消'];
        if (!allowed.includes(normalized)) {
          return json(400, { message: '无效的状态值' });
        }
        update.status = normalized;
      }
      if (changes.trackingNumber) update.tracking_no = changes.trackingNumber;
      if (changes.sender) update.sender = changes.sender;
      if (changes.receiver) update.receiver = changes.receiver;
      if (changes.origin) update.origin = changes.origin;
      if (changes.destination) update.destination = changes.destination;
      if (changes.packageType) update.package_type = changes.packageType;
      if (typeof changes.weightKg !== 'undefined') update.weight_kg = changes.weightKg;
      if (changes.dimensions) {
        if (typeof changes.dimensions.lengthCm !== 'undefined') update.length_cm = changes.dimensions.lengthCm;
        if (typeof changes.dimensions.widthCm !== 'undefined') update.width_cm = changes.dimensions.widthCm;
        if (typeof changes.dimensions.heightCm !== 'undefined') update.height_cm = changes.dimensions.heightCm;
      }
      if (typeof changes.fee !== 'undefined') update.fee = changes.fee;
      // 为避免因不同库结构导致的 created_at 更新错误，这里忽略前端传入的 createdAt 字段
      if (changes.estimatedDelivery) update.estimated_delivery = changes.estimatedDelivery;
      if (typeof changes.note !== 'undefined') update.note = changes.note;
      // 当状态改为"已入库"时记录入库账号与时间
      if (update.status === '已入库' && hasInboundCols) {
        update.inbound_by = actor || null;
        update.inbound_at = new Date().toISOString();
      }
      // 当状态改为"已签收"时记录签收账号与时间
      if (update.status === '已签收') {
        update.signed_by = actor || null;
        update.signed_at = new Date().toISOString();
      }

      // 尝试更新，若因不存在的列失败，做一次降级重试
      let errMsg: string | null = null;
      let r1 = await client.from('packages').update(update).eq('id', id);
      if (r1.error) {
        errMsg = r1.error.message || '';
        const downgrade: any = { ...update };
        if (/inbound_by/i.test(errMsg)) delete downgrade.inbound_by;
        if (/inbound_at/i.test(errMsg)) delete downgrade.inbound_at;
        if (JSON.stringify(downgrade) !== JSON.stringify(update)) {
          r1 = await client.from('packages').update(downgrade).eq('id', id);
        }
      }
      if (r1.error) {
        const msg = r1.error.message || '更新失败';
        return json(500, { message: msg, hint: 'packages.patch' });
      }
      // 若费用发生变更，则同步更新财务记录中的金额，保持与包裹费用一致
      try {
        if (typeof changes.fee !== 'undefined') {
          let trackingNo: string | null = null;
          try {
            const { data: row } = await client.from('packages').select('tracking_no,fee').eq('id', id).single();
            trackingNo = row?.tracking_no ? String(row.tracking_no) : null;
          } catch {}
          if (trackingNo) {
            const feeNum = Number(changes.fee);
            // 按 tracking_no 更新财务记录
            try { await client.from('finances').update({ amount: feeNum }).eq('tracking_no', trackingNo); } catch {}
          }
        }
      } catch {}
      // 若将包裹作废（已取消），则删除对应财务记录
      try {
        const setToCanceled = (update.status === '已取消') || (changes.status === '已取消');
        if (setToCanceled) {
          let trackingNo: string | null = null;
          try {
            const { data: row } = await client.from('packages').select('tracking_no').eq('id', id).single();
            trackingNo = row?.tracking_no ? String(row.tracking_no) : null;
          } catch {}
          if (trackingNo) {
            const noteNew = `新包裹入库 - 单号 ${trackingNo}`;
            const noteSigned = `包裹签收 - 单号 ${trackingNo}`;
            const noteArrived = `包裹已到站 - 单号 ${trackingNo}`;
            try { await client.from('finances').delete().eq('tracking_no', trackingNo); } catch {}
            try { await client.from('finances').delete().eq('note', noteNew); } catch {}
            try { await client.from('finances').delete().eq('note', noteSigned); } catch {}
            try { await client.from('finances').delete().eq('note', noteArrived); } catch {}
          }
        }
      } catch {}
      try {
        let trackingNo: string | null = null;
        try { const { data: row } = await client.from('packages').select('tracking_no').eq('id', id).single(); trackingNo = row?.tracking_no || null; } catch {}
        await client.from('audit_logs').insert([{ actor, action: 'packages.update', detail: { id, tracking_no: trackingNo, before: undefined, after: undefined, changes } }]);
      } catch {}
      return json(200, { ok: true });
    }



    if (event.httpMethod === 'DELETE') {
      const allowed = await hasDbRole(client!, actor, ['manager','master','staff']);
      if (!allowed) return json(403, { message: 'Forbidden' });
      const body = event.body ? JSON.parse(event.body) : {};
      const { id, trackingNumber } = body || {};
      if (!id && !trackingNumber) return json(400, { message: '缺少ID或trackingNumber' });
      let error: any = null;
      if (id) {
        // RBAC: staff 仅可删除自己创建的包裹
        try {
          const isStaff = await hasDbRole(client!, actor, ['staff']);
          if (isStaff) {
            let hasCreatedByCol = true;
            try {
              const probe = await client.from('packages').select('created_by').limit(1);
              if ((probe as any)?.error) hasCreatedByCol = false;
            } catch { hasCreatedByCol = false; }
            if (hasCreatedByCol) {
              const { data: ownerRow } = await client.from('packages').select('created_by').eq('id', id).single();
              const owner = ownerRow?.created_by || null;
              if (owner && actor && owner !== actor) return json(403, { message: '仅可操作自己创建的包裹' });
            }
          }
        } catch {}
        // 读取包裹以拿到单号，随后删除财务
        const { data: p } = await client.from('packages').select('tracking_no').eq('id', id).single();
        const t = p?.tracking_no;
        ({ error } = await client.from('packages').delete().eq('id', id));
        if (!error && t) {
          try { await client.from('finances').delete().eq('tracking_no', t); } catch {}
          try { await client.from('finances').delete().eq('note', `新包裹入库 - 单号 ${t}`); } catch {}
          try { await client.from('finances').delete().eq('note', `包裹签收 - 单号 ${t}`); } catch {}
          try { await client.from('finances').delete().eq('note', `包裹已到站 - 单号 ${t}`); } catch {}
        }
      } else if (trackingNumber) {
        ({ error } = await client.from('packages').delete().eq('tracking_no', trackingNumber));
        try {
          await client.from('finances').delete().eq('tracking_no', trackingNumber);
          await client.from('finances').delete().eq('note', `新包裹入库 - 单号 ${trackingNumber}`);
          await client.from('finances').delete().eq('note', `包裹签收 - 单号 ${trackingNumber}`);
          await client.from('finances').delete().eq('note', `包裹已到站 - 单号 ${trackingNumber}`);
        } catch {}
      }
      if (error) return json(500, { message: error.message });
      try { await client.from('audit_logs').insert([{ actor, action: 'packages.delete', detail: { id, trackingNumber } }]); } catch {}
      return json(200, { ok: true });
    }

    return json(405, { message: 'Method Not Allowed' });
  } catch (e: any) {
    const msg = e?.message || 'Server Error';
    return json(500, { message: msg });
  }
};


