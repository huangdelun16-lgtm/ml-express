import type { Handler } from '@netlify/functions';
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.SUPABASE_URL as string;
const SERVICE_ROLE = process.env.SUPABASE_SERVICE_ROLE as string;

const client = SUPABASE_URL && SERVICE_ROLE
  ? createClient(SUPABASE_URL, SERVICE_ROLE, { auth: { persistSession: false } })
  : null;

const cors = {
  'Access-Control-Allow-Origin': 'https://market-link-express.com',
  'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, x-ml-actor, x-ml-role',
  'Access-Control-Allow-Credentials': 'true',
};

function json(statusCode: number, body: any) {
  return { statusCode, headers: { 'Content-Type': 'application/json', ...cors }, body: JSON.stringify(body) };
}

export const handler: Handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: cors, body: '' } as any;
  if (!client) return json(500, { message: 'backend not configured: missing SUPABASE_URL or SUPABASE_SERVICE_ROLE' });

  try {
    const actor = (event.headers['x-ml-actor'] || event.headers['X-ML-Actor'] || '').toString();
    async function requireManagerOrMaster() {
      if (!actor) return json(403, { message: 'Forbidden' });
      try {
        const { data } = await client.from('users').select('role').eq('username', actor).limit(1);
        const r = data && data[0]?.role;
        if (!['manager','master'].includes(r)) return json(403, { message: 'Forbidden' });
      } catch {
        return json(403, { message: 'Forbidden' });
      }
      return null;
    }
    if (event.httpMethod === 'GET') {
      const { data, error } = await client.from('users').select('username, role').order('username');
      if (error) return json(500, { message: error.message });
      return json(200, { users: data });
    }

    const body = event.body ? JSON.parse(event.body) : {};

    if (event.httpMethod === 'POST') {
      const deny = await requireManagerOrMaster(); if (deny) return deny;
      const { username, passwordHash, role } = body || {};
      if (!username || !passwordHash || !role) return json(400, { message: '缺少必要字段' });
      const { error } = await client.from('users').insert([{ username, password_hash: passwordHash, role }], { upsert: true });
      if (error) return json(500, { message: error.message });
      return json(200, { ok: true });
    }

    if (event.httpMethod === 'PATCH') {
      const deny = await requireManagerOrMaster(); if (deny) return deny;
      const { username, role, passwordHash } = body || {};
      if (!username) return json(400, { message: '缺少用户名' });
      const update: any = {};
      if (role) update.role = role;
      if (passwordHash) update.password_hash = passwordHash;
      if (Object.keys(update).length === 0) return json(400, { message: '无可更新字段' });
      const { error } = await client.from('users').update(update).eq('username', username);
      if (error) return json(500, { message: error.message });
      return json(200, { ok: true });
    }

    if (event.httpMethod === 'DELETE') {
      const deny = await requireManagerOrMaster(); if (deny) return deny;
      const { username } = body || {};
      if (!username) return json(400, { message: '缺少用户名' });
      if (username === 'master') return json(400, { message: '禁止删除 master' });
      const { error } = await client.from('users').delete().eq('username', username);
      if (error) return json(500, { message: error.message });
      return json(200, { ok: true });
    }

    return json(405, { message: 'Method Not Allowed' });
  } catch (e: any) {
    return json(500, { message: e?.message || 'Server Error' });
  }
};


