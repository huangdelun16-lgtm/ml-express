 
import { createClient } from '@supabase/supabase-js';
import { getAuthFromEvent, hasDbRole } from './_auth';

const SUPABASE_URL = process.env.SUPABASE_URL as string;
const SERVICE_ROLE = process.env.SUPABASE_SERVICE_ROLE as string;

const client = SUPABASE_URL && SERVICE_ROLE
  ? createClient(SUPABASE_URL, SERVICE_ROLE, { auth: { persistSession: false } })
  : null;

const cors = {
  'Access-Control-Allow-Origin': 'https://market-link-express.com',
  'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, x-ml-actor, x-ml-role',
  'Access-Control-Allow-Credentials': 'true',
};

function json(statusCode: number, body: any, cache?: { maxAge?: number; swr?: number }) {
  const cc = cache && statusCode === 200
    ? `public, max-age=${Math.max(0, cache.maxAge ?? 20)}, stale-while-revalidate=${Math.max(0, cache.swr ?? 60)}`
    : undefined;
  const headers: Record<string,string> = { 'Content-Type': 'application/json', ...cors };
  if (cc) {
    headers['Cache-Control'] = cc;
    headers['Vary'] = 'Authorization, x-ml-actor, x-ml-role';
  }
  return { statusCode, headers, body: JSON.stringify(body) };
}

function deny(msg = 'Forbidden') { return json(403, { message: msg }); }

// 从备注文本中解析单号（兼容多种格式）
function parseTrackingNoFromNote(note?: string): string | undefined {
  const text = String(note || '');
  const patterns = [
    /新包裹入库\s*[-—–]?\s*单号[:：]?\s*([^\s，,]+)/,
    /包裹签收\s*[-—–]?\s*单号[:：]?\s*([^\s，,]+)/,
    /单号[:：]?\s*([^\s，,]+)/,
  ];
  for (const re of patterns) {
    const m = text.match(re);
    if (m) return String(m[1]).replace(/[，,。.;；]$/, '');
  }
  return undefined;
}

export const handler = async (event: any) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: cors, body: '' } as any;
  if (!client) return json(500, { message: 'backend not configured: missing SUPABASE_URL or SUPABASE_SERVICE_ROLE' });

  const session = getAuthFromEvent(event);
  const actor = session?.username || (event.headers['x-ml-actor'] || event.headers['X-ML-Actor'] || '').toString();

  async function hasRequiredRole(required: string[]): Promise<boolean> {
    if (!actor) return false;
    try {
      const { data, error } = await client!.from('users').select('role').eq('username', actor).limit(1);
      if (error) return false;
      const r = data && data[0]?.role;
      return r ? required.includes(r) : false;
    } catch {
      return false;
    }
  }

  try {
    // 简单限速：按 IP + 路径计数（1 分钟内超过阈值则拒绝）
    const ip = (event.headers['x-forwarded-for'] || event.headers['client-ip'] || '').toString().split(',')[0].trim();
    const key = `ratelimit:${ip}:${event.path}`;
    try {
      await client!.from('rate_limits').insert([{ key, ts: new Date().toISOString() }]);
    } catch {}
    try {
      const oneMinAgo = new Date(Date.now() - 60_000).toISOString();
      const { count } = (await client!.from('rate_limits').select('id', { count: 'exact', head: true }).gte('ts', oneMinAgo).eq('key', key)) as any;
      const limit = event.httpMethod === 'GET' ? 120 : 30;
      if ((count || 0) > limit) return json(429, { message: 'Too Many Requests' });
    } catch {}
    if (event.httpMethod === 'GET') {
      // 允许 accountant/manager/master 读取财务
      const canRead = await hasRequiredRole(['accountant','manager','master']);
      if (!canRead) return deny();
      const qs = event.queryStringParameters || {};
      const start = (qs.start || '') as string;
      const end = (qs.end || '') as string;
      const type = (qs.type || '') as string;
      const search = (qs.search || '').toString();
      const page = Math.max(1, parseInt((qs.page as string) || '1', 10));
      const pageSize = Math.min(100, Math.max(5, parseInt((qs.pageSize as string) || '20', 10)));
      const status = (qs.status || '') as string; // 可选：已入账、作废、运输中、待签收 等

      // 统计总数
      let countQ = client.from('finances').select('id', { count: 'exact', head: true });
      if (start) countQ = countQ.gte('date', start);
      if (end) countQ = countQ.lte('date', end);
      if (type === '收入' || type === '支出') countQ = countQ.eq('type', type);
      if (search) countQ = countQ.ilike('note', `%${search}%`);
      if (status) countQ = countQ.eq('status', status);
      const { count: total = 0 } = (await countQ) as any;

      // 列表
      let listQ = client.from('finances').select('*').order('date', { ascending: false }).range((page-1)*pageSize, page*pageSize-1);
      if (start) listQ = listQ.gte('date', start);
      if (end) listQ = listQ.lte('date', end);
      if (type === '收入' || type === '支出') listQ = listQ.eq('type', type);
      if (search) listQ = listQ.ilike('note', `%${search}%`);
      if (status) listQ = listQ.eq('status', status);
      const { data, error } = await listQ;
      if (error) return json(500, { message: error.message });
      // 目的地兜底：若 finances.destination 为空且有 tracking_no，则批量查询 packages.destination
      const baseItems = (data || []).map((r: any) => ({
        raw: r,
        trackingNo: r.tracking_no || parseTrackingNoFromNote(r.note),
      }));
      const needDest = baseItems.filter(x => x.trackingNo && !(x.raw?.destination));
      let destMap: Record<string,string> = {};
      if (needDest.length) {
        try {
          const arr = Array.from(new Set(needDest.map(x => String(x.trackingNo))));
          const { data: pkRows } = await client.from('packages').select('tracking_no,destination').in('tracking_no', arr);
          for (const r of (pkRows || [])) { if (r?.tracking_no && r?.destination) destMap[String(r.tracking_no)] = String(r.destination); }
        } catch {}
      }
      const items = baseItems.map(({ raw, trackingNo }) => ({
        id: raw.id,
        type: raw.type,
        category: raw.category,
        amount: Number(raw.amount||0),
        note: raw.note,
        date: raw.date || raw.occurred_on,
        status: raw.status || '已入账',
        tracking_no: trackingNo,
        destination: raw.destination || (trackingNo ? destMap[trackingNo] || null : null),
      }));
      // 过滤汇总（仅统计已入账；兼容老库无 status 列或 status 为空）
      let fIncome = 0, fExpense = 0;
      try {
        let sumQ = client.from('finances').select('amount,type,status');
        if (start) sumQ = sumQ.gte('date', start);
        if (end) sumQ = sumQ.lte('date', end);
        if (type === '收入' || type === '支出') sumQ = sumQ.eq('type', type);
        if (search) sumQ = sumQ.ilike('note', `%${search}%`);
        let { data: srows, error: serr } = await sumQ as any;
        if (serr) {
          // 老库缺 status 列，降级忽略 status 字段
          let sumQ2 = client.from('finances').select('amount,type');
          if (start) sumQ2 = sumQ2.gte('date', start);
          if (end) sumQ2 = sumQ2.lte('date', end);
          if (type === '收入' || type === '支出') sumQ2 = sumQ2.eq('type', type);
          if (search) sumQ2 = sumQ2.ilike('note', `%${search}%`);
          const r2 = await sumQ2 as any;
          srows = r2.data || [];
          serr = r2.error;
        }
        for (const r of (srows || [])) {
          const st = (r as any).status;
          const isPosted = (st === '已入账' || st === null || typeof st === 'undefined');
          if (!isPosted) continue;
          const t = String((r as any).type || '').trim();
          if (t === '收入') fIncome += Number((r as any).amount||0); else if (t === '支出') fExpense += Number((r as any).amount||0);
        }
      } catch {}
      // 全量汇总（仅统计已入账；兼容老库无 status 列或 status 为空）
      let aIncome = 0, aExpense = 0;
      try {
        let allQ = client.from('finances').select('amount,type,status');
        let { data: arows, error: aerr } = await allQ as any;
        if (aerr) {
          const r2 = await client.from('finances').select('amount,type') as any;
          arows = r2.data || [];
        }
        for (const r of (arows || [])) {
          const st = (r as any).status;
          const isPosted = (st === '已入账' || st === null || typeof st === 'undefined');
          if (!isPosted) continue;
          const t = String((r as any).type || '').trim();
          if (t === '收入') aIncome += Number((r as any).amount||0); else if (t === '支出') aExpense += Number((r as any).amount||0);
        }
      } catch {}
      return json(200, { items, page, pageSize, total, summaryFiltered: { income: fIncome, expense: fExpense, net: fIncome - fExpense }, summaryAll: { income: aIncome, expense: aExpense, net: aIncome - aExpense } }, { maxAge: 20, swr: 60 });
    }

    if (event.httpMethod === 'POST') {
      const allowed = await hasDbRole(client!, actor, ['accountant', 'master']);
      if (!allowed) return deny();
      const body = event.body ? JSON.parse(event.body) : {};
      const { type, category, amount, note, date, status } = body || {};
      const trackingNo: string | undefined = (body.tracking_no || body.trackingNo || body.trackingNumber) ? String(body.tracking_no || body.trackingNo || body.trackingNumber) : undefined;
      if (!['收入','支出'].includes(type)) return json(400, { message: '类型错误' });
      if (!(amount>0)) return json(400, { message: '金额需>0' });
      if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date||''))) return json(400, { message: '日期格式应为YYYY-MM-DD' });
      if (note && String(note).length>200) return json(400, { message: '备注过长' });
      const allowedStatus = ['已入账','作废','待签收','运输中'];
      const finalStatus = status && allowedStatus.includes(status) ? status : '已入账';
      
      // 获取包裹目的地信息
      let destination: string | null = null;
      if (trackingNo) {
        try {
          const { data: packageData } = await client.from('packages').select('destination').eq('tracking_no', trackingNo).single();
          if (packageData?.destination) {
            destination = packageData.destination;
          }
        } catch {}
      }
      
      const record: any = { type, category, amount, note, date, status: finalStatus, created_by: actor, destination };
      if (trackingNo) {
        record.tracking_no = trackingNo;
      } else {
        const parsed = parseTrackingNoFromNote(note);
        if (parsed) {
          record.tracking_no = parsed;
          // 如果从备注中解析出单号，也尝试获取目的地
          try {
            const { data: packageData } = await client.from('packages').select('destination').eq('tracking_no', parsed).single();
            if (packageData?.destination) {
              record.destination = packageData.destination;
            }
          } catch {}
        }
      }
      let { data, error } = await client.from('finances').insert([record]).select('*').single();
      if (error) {
        // 无条件降级：移除 destination / status / tracking_no，保证老库也可写入
        const fallback: any = { type, category, amount, note, date, created_by: actor };
        const r2 = await client.from('finances').insert([fallback]).select('*').single();
        data = (r2 as any)?.data;
        error = (r2 as any)?.error;
      }
      if (error) return json(500, { message: error.message });
      try { await client.from('audit_logs').insert([{ actor, action: 'finances.create', detail: { ...record, tracking_no: record.tracking_no || parseTrackingNoFromNote(record.note) } }]); } catch {}
      return json(200, { item: data });
    }

    if (event.httpMethod === 'PATCH') {
      const allowed = await hasDbRole(client!, actor, ['accountant', 'master']);
      if (!allowed) return deny();
      const body = event.body ? JSON.parse(event.body) : {};
      const { id, ...changes } = body || {};
      // 兼容：允许用 trackingNumber 字段更新
      if ((changes as any).trackingNumber && !(changes as any).tracking_no) {
        (changes as any).tracking_no = (changes as any).trackingNumber;
        delete (changes as any).trackingNumber;
      }
      if (!id) return json(400, { message: '缺少ID' });
      if (changes.type && !['收入','支出'].includes(changes.type)) return json(400, { message: '类型错误' });
      if (typeof changes.amount!=='undefined' && !(Number(changes.amount)>0)) return json(400, { message: '金额需>0' });
      if (changes.date && !/^\d{4}-\d{2}-\d{2}$/.test(String(changes.date))) return json(400, { message: '日期格式错误' });
      if (changes.note && String(changes.note).length>200) return json(400, { message: '备注过长' });
      if (typeof changes.status !== 'undefined') {
        const allowedStatus = ['已入账','作废','待签收','运输中'];
        if (!allowedStatus.includes(changes.status)) return json(400, { message: '状态错误' });
      }
      const updatePayload: any = { ...changes, updated_by: actor };
      
      // 如果更新了tracking_no，自动同步目的地
      if (updatePayload.tracking_no) {
        try {
          const { data: packageData } = await client.from('packages').select('destination').eq('tracking_no', updatePayload.tracking_no).single();
          if (packageData?.destination) {
            updatePayload.destination = packageData.destination;
          }
        } catch {}
      }
      
      // 后端兜底：若未显式传入 tracking_no，则尽量保留或回填
      if (typeof updatePayload.tracking_no === 'undefined') {
        try {
          const { data: prev } = await client.from('finances').select('tracking_no,note').eq('id', id).single();
          if (prev) {
            if (prev.tracking_no) {
              // 保留原 tracking_no
              updatePayload.tracking_no = prev.tracking_no;
            } else {
              // 从"旧备注"或"新备注"中解析并回填
              const parsed = parseTrackingNoFromNote(prev.note) || parseTrackingNoFromNote(updatePayload.note);
              if (parsed) updatePayload.tracking_no = parsed;
            }
          }
        } catch {}
      }
      let updErr = (await client.from('finances').update(updatePayload).eq('id', id)).error as any;
      if (updErr) {
        const { status: _omitS, tracking_no: _omitT, destination: _omitD, ...rest } = updatePayload as any;
        updErr = (await client.from('finances').update({ ...rest, updated_by: actor }).eq('id', id)).error as any;
      }
      if (updErr) return json(500, { message: updErr.message });
      try { await client.from('audit_logs').insert([{ actor, action: 'finances.update', detail: { id, tracking_no: (changes.tracking_no || undefined), before: undefined, after: undefined, changes } }]); } catch {}
      return json(200, { ok: true });
    }

    if (event.httpMethod === 'DELETE') {
      const allowed = await hasDbRole(client!, actor, ['accountant', 'master']);
      if (!allowed) return deny();
      const body = event.body ? JSON.parse(event.body) : {};
      const { id, trackingNumber } = body || {};
      if (!id && !trackingNumber) return json(400, { message: '缺少删除条件' });
      let error: any = null;
      if (id) {
        ({ error } = await client.from('finances').delete().eq('id', id));
      } else if (trackingNumber) {
        // 兼容两种字段：优先 tracking_no，兼容旧数据的 note 文本（此处或条件使用字符串，不再额外括号）
        const noteEq = `新包裹入库 - 单号 ${trackingNumber}`;
        ({ error } = await (client as any)
          .from('finances')
          .delete()
          .or(`tracking_no.eq.${trackingNumber},note.eq.${noteEq}`));
      }
      if (error) return json(500, { message: error.message });
      try { await client.from('audit_logs').insert([{ actor, action: 'finances.delete', detail: { id, trackingNumber } }]); } catch {}
      return json(200, { ok: true });
    }

    return json(405, { message: 'Method Not Allowed' });
  } catch (e: any) {
    return json(500, { message: e?.message || 'Server Error' });
  }
};


